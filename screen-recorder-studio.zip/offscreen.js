(function() {
  "use strict";
  var _documentCurrentScript = typeof document !== "undefined" ? document.currentScript : null;
  (function() {
    const log = (...args) => {
      try {
        console.log("[OffscreenEngine]", ...args);
      } catch {
      }
    };
    log("🎬 Offscreen recording engine loaded");
    let currentStream = null;
    let mediaRecorder = null;
    let recordedChunks = [];
    let isRecording = false;
    let isPaused = false;
    let recordingStartTime = null;
    let wcWorker = null;
    let wcReader = null;
    let wcFrameLoopActive = false;
    const OPFS_WRITER_ENABLED = true;
    let opfsWriter = null;
    let opfsWriterReady = false;
    let opfsSessionId = null;
    let opfsLastMeta = null;
    const opfsPendingChunks = [];
    let opfsEndPending = false;
    function ensureOpfsSessionId() {
      if (!opfsSessionId) opfsSessionId = `${Date.now()}`;
      return opfsSessionId;
    }
    function normalizeMeta(m) {
      if (!m) return {};
      const metaW = typeof m.width === "number" ? m.width : m.codedWidth;
      const metaH = typeof m.height === "number" ? m.height : m.codedHeight;
      return { codec: m.codec || "vp8", width: metaW ?? 1920, height: metaH ?? 1080, fps: m.framerate || m.fps || 30 };
    }
    function initOpfsWriter(meta) {
      if (opfsWriter) return;
      opfsWriterReady = false;
      opfsLastMeta = normalizeMeta(meta || opfsLastMeta);
      try {
        opfsWriter = new Worker(new URL(
          /* @vite-ignore */
          "/assets/opfs-writer-worker-BX1cPBZa.js",
          _documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === "SCRIPT" && _documentCurrentScript.src || new URL("offscreen.js", document.baseURI).href
        ), { type: "module" });
        const id = ensureOpfsSessionId();
        opfsWriter.onmessage = (ev) => {
          const d = ev.data || {};
          if (d.type === "ready") {
            opfsWriterReady = true;
            flushOpfsPendingIfReady();
          } else if (d.type === "progress") {
          } else if (d.type === "finalized") {
            try {
              log("[stop-share] offscreen: sending OPFS_RECORDING_READY");
              chrome.runtime?.sendMessage({ type: "OPFS_RECORDING_READY", id: `rec_${d?.id ?? id}`, meta: opfsLastMeta });
            } catch {
            }
            try {
              opfsWriter?.terminate();
            } catch {
            }
            opfsWriter = null;
            opfsWriterReady = false;
            opfsSessionId = null;
          }
        };
        opfsWriter.postMessage({ type: "init", id, meta: opfsLastMeta });
      } catch (e) {
        log("[Offscreen][OPFS] failed to start writer", e);
        opfsWriter = null;
        opfsWriterReady = false;
      }
    }
    function flushOpfsPendingIfReady() {
      if (!opfsWriter || !opfsWriterReady) return;
      while (opfsPendingChunks.length) {
        const c = opfsPendingChunks.shift();
        appendToOpfsChunk(c);
      }
      if (opfsEndPending) {
        opfsEndPending = false;
        void finalizeOpfsWriter();
      }
    }
    function appendToOpfsChunk(d) {
      if (!opfsWriter || !opfsWriterReady) {
        opfsPendingChunks.push(d);
        return;
      }
      try {
        const raw = d.data;
        let u8 = null;
        if (raw instanceof ArrayBuffer) u8 = new Uint8Array(raw);
        else if (raw && ArrayBuffer.isView(raw) && typeof raw.byteLength === "number") {
          const view = raw;
          u8 = new Uint8Array(view.buffer, view.byteOffset || 0, view.byteLength);
        } else if (raw && typeof raw.copyTo === "function" && typeof raw.byteLength === "number") {
          const tmp = new Uint8Array(raw.byteLength);
          try {
            raw.copyTo(tmp);
          } catch {
          }
          ;
          u8 = tmp;
        } else if (raw instanceof Blob) {
          raw.arrayBuffer().then((ab) => appendToOpfsChunk({ ...d, data: ab })).catch(() => {
          });
          return;
        } else if (Array.isArray(raw)) u8 = new Uint8Array(raw);
        else if (raw && typeof raw === "object") {
          const keys = Object.keys(raw);
          const isIndexedObject = keys.length > 0 && keys.every((k) => /^\d+$/.test(k));
          if (isIndexedObject) {
            const maxIndex = Math.max(...keys.map((k) => parseInt(k, 10)));
            const bytes = new Array(maxIndex + 1);
            for (let i = 0; i <= maxIndex; i++) bytes[i] = raw[i] || 0;
            u8 = new Uint8Array(bytes);
          }
        }
        if (!u8) {
          log("[Offscreen][OPFS] Unsupported chunk data");
          return;
        }
        const transferBuf = u8.byteOffset === 0 && u8.byteLength === u8.buffer.byteLength ? u8.buffer : u8.slice().buffer;
        opfsWriter.postMessage({ type: "append", buffer: transferBuf, timestamp: d.timestamp || 0, chunkType: d.type === "key" ? "key" : "delta", codedWidth: d.codedWidth || opfsLastMeta?.width, codedHeight: d.codedHeight || opfsLastMeta?.height, codec: d.codec || opfsLastMeta?.codec, isKeyframe: d.type === "key" }, [transferBuf]);
      } catch (e) {
        log("[Offscreen][OPFS] append failed", e);
      }
    }
    async function finalizeOpfsWriter() {
      if (!opfsWriter) return;
      const w = opfsWriter;
      try {
        await new Promise((resolve) => {
          let settled = false;
          const onMsg = (ev) => {
            const t = (ev.data || {}).type;
            if (t === "finalized" || t === "error") {
              if (!settled) {
                settled = true;
                try {
                  w.removeEventListener("message", onMsg);
                } catch {
                }
                ;
                resolve();
              }
            }
          };
          try {
            w.addEventListener("message", onMsg);
          } catch {
          }
          try {
            w.postMessage({ type: "finalize" });
          } catch {
          }
          setTimeout(() => {
            if (!settled) {
              settled = true;
              try {
                w.removeEventListener("message", onMsg);
              } catch {
              }
              ;
              resolve();
            }
          }, 1500);
        });
      } catch (e) {
        log("[Offscreen][OPFS] finalize failed", e);
      } finally {
        try {
          w.terminate();
        } catch {
        }
        if (opfsWriter === w) {
          opfsWriter = null;
          opfsWriterReady = false;
          opfsSessionId = null;
        }
      }
    }
    async function getDisplayMediaStream(mode = "screen") {
      log("🎥 Requesting display media directly in offscreen document...", { mode });
      try {
        const displayMediaOptions = {
          video: {
            // 根据模式设置默认的显示表面类型
            ...mode === "screen" && {
              displaySurface: "monitor",
              // 优先显示屏幕选项
              monitorTypeSurfaces: "include",
              selfBrowserSurface: "exclude"
            },
            ...mode === "window" && {
              displaySurface: "window",
              selfBrowserSurface: "exclude"
            },
            ...mode === "tab" && {
              displaySurface: "browser",
              // preferCurrentTab: true,
              selfBrowserSurface: "exclude"
            }
          },
          audio: false,
          // 根据模式设置顶级选项
          // ...(mode === 'tab' && { preferCurrentTab: true }),
          ...mode === "screen" && {
            selfBrowserSurface: "exclude",
            monitorTypeSurfaces: "include"
          }
        };
        log("📋 Display media options:", displayMediaOptions);
        const stream = await navigator.mediaDevices.getDisplayMedia(displayMediaOptions);
        if (!stream) {
          throw new Error("getDisplayMedia returned null stream");
        }
        const videoTracks = stream.getVideoTracks();
        const audioTracks = stream.getAudioTracks();
        log("📺 Display media stream obtained successfully:", {
          id: stream.id,
          videoTracks: videoTracks.length,
          audioTracks: audioTracks.length,
          videoLabel: videoTracks[0]?.label,
          videoState: videoTracks[0]?.readyState
        });
        return stream;
      } catch (error) {
        log("❌ Error getting display media:", error);
        if (error instanceof Error) {
          if (error.name === "AbortError") {
            throw new Error(`User cancelled screen sharing: ${error.message}`);
          } else if (error.name === "NotAllowedError") {
            throw new Error(`Permission denied for screen sharing: ${error.message}`);
          } else if (error.name === "NotFoundError") {
            throw new Error(`No display media source found: ${error.message}`);
          } else if (error.name === "NotSupportedError") {
            throw new Error(`getDisplayMedia not supported: ${error.message}`);
          } else {
            throw new Error(`getDisplayMedia failed: ${error.name} - ${error.message}`);
          }
        } else {
          throw new Error(`Unknown error getting display media: ${error}`);
        }
      }
    }
    async function startRecording(options) {
      const timestamp = (/* @__PURE__ */ new Date()).toISOString();
      log(`🎯 [${timestamp}] Starting recording directly in offscreen document...`, { options });
      try {
        if (isRecording) {
          log("🛑 Stopping existing recording before starting new one");
          stopRecordingInternal();
        }
        const mode = options?.mode || "screen";
        log(`📺 Recording mode: ${mode}`);
        const stream = await getDisplayMediaStream(mode);
        currentStream = stream;
        const videoTracks = stream.getVideoTracks() || [];
        const audioTracks = stream.getAudioTracks() || [];
        const videoTrack = videoTracks[0];
        log("📺 MediaStream acquired:", {
          id: stream.id,
          videoTracks: videoTracks.length,
          audioTracks: audioTracks.length,
          videoLabel: videoTrack?.label,
          videoState: videoTrack?.readyState,
          canRequestAudioTrack: options?.canRequestAudioTrack
        });
        if (videoTrack) {
          videoTrack.onended = () => {
            log("[stop-share] offscreen: video track onended fired (user stop share)");
            log("📺 Video track ended - user stopped sharing");
            stopRecordingInternal();
          };
        }
        if (typeof window.VideoEncoder === "undefined" || typeof window.MediaStreamTrackProcessor === "undefined") {
          throw new Error("WebCodecs APIs not supported in this environment");
        }
        const settings = videoTrack?.getSettings?.() || {};
        const width = settings.width || 1920;
        const height = settings.height || 1080;
        const framerate = Math.round(settings.frameRate || 30);
        const bitrate = options?.bitrate || 8e6;
        const ProcessorCtor = window.MediaStreamTrackProcessor;
        const processor = new ProcessorCtor({ track: videoTrack });
        const reader = processor.readable.getReader();
        wcReader = reader;
        wcWorker = new Worker(new URL(
          /* @vite-ignore */
          "/assets/webcodecs-worker-Cu67pF_r.js",
          _documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === "SCRIPT" && _documentCurrentScript.src || new URL("offscreen.js", document.baseURI).href
        ), { type: "module" });
        let configured = false;
        let resolveConfigured = null;
        const waitForConfigured = new Promise((res) => {
          resolveConfigured = res;
        });
        recordedChunks = [];
        recordingStartTime = Date.now();
        wcWorker.onmessage = (evt) => {
          const { type, data, config } = evt.data || {};
          switch (type) {
            case "initialized":
              log("👷 WebCodecs worker initialized");
              break;
            case "configured":
              configured = true;
              try {
                resolveConfigured?.();
                resolveConfigured = null;
              } catch {
              }
              log("✅ WebCodecs worker configured:", config);
              try {
                if (OPFS_WRITER_ENABLED) initOpfsWriter({ codec: config?.codec, width: config?.width, height: config?.height, framerate });
              } catch {
              }
              break;
            case "chunk": {
              if (data) {
                recordedChunks.push({ size: data.size, ts: data.timestamp, type: data.type });
                try {
                  chrome.runtime.sendMessage({
                    type: "STREAM_CHUNK_INFO",
                    meta: { index: recordedChunks.length, size: data.size, ts: data.timestamp, type: data.type }
                  });
                } catch {
                }
                try {
                  appendToOpfsChunk({
                    data: data.data,
                    timestamp: data.timestamp,
                    type: data.type,
                    codedWidth: data.codedWidth,
                    codedHeight: data.codedHeight,
                    codec: data.codec
                  });
                } catch {
                }
              }
              break;
            }
            case "error":
              log("❌ [WebCodecs Worker] error:", data);
              try {
                chrome.runtime.sendMessage({ type: "STREAM_ERROR", error: String(data) });
              } catch {
              }
              break;
            case "complete":
              try {
                const finalU8 = data;
                log("🎞️ WebCodecs final data received:", { bytes: finalU8?.byteLength });
                const _copy = new Uint8Array(finalU8.byteLength);
                _copy.set(finalU8);
                const finalBlob = new Blob([_copy], { type: "video/webm" });
                const stopTs = (/* @__PURE__ */ new Date()).toISOString();
                const duration = recordingStartTime ? Date.now() - recordingStartTime : 0;
                try {
                  if (OPFS_WRITER_ENABLED) {
                    if (!opfsWriterReady || opfsPendingChunks.length > 0) {
                      opfsEndPending = true;
                    } else {
                      void finalizeOpfsWriter();
                    }
                  }
                } catch {
                }
                const readerFR = new FileReader();
                readerFR.onloadend = () => {
                  try {
                    log("[stop-share] offscreen: sending RECORDING_COMPLETE");
                    chrome.runtime.sendMessage({
                      type: "RECORDING_COMPLETE",
                      target: "service-worker",
                      data: {
                        videoBlob: readerFR.result,
                        // Base64 encoded
                        metadata: {
                          size: finalBlob.size,
                          type: finalBlob.type,
                          duration,
                          chunks: recordedChunks.length,
                          timestamp: stopTs,
                          engine: "webcodecs",
                          width,
                          height,
                          framerate
                        }
                      }
                    });
                  } catch {
                  }
                };
                readerFR.readAsDataURL(finalBlob);
              } catch (e) {
                log("❌ Failed to process final WebCodecs data:", e);
              }
              break;
          }
        };
        wcWorker.postMessage({ type: "configure", config: { width, height, bitrate, framerate } });
        await waitForConfigured;
        log("🟠 Worker configured confirmed, starting pre-start countdown (5s)");
        const COUNTDOWN_SECONDS = 5;
        for (let n = COUNTDOWN_SECONDS; n >= 1; n--) {
          try {
            chrome.runtime.sendMessage({ type: "STREAM_META", meta: { preparing: true, countdown: n } });
          } catch {
          }
          await new Promise((r) => setTimeout(r, 1e3));
          if (!currentStream) {
            log("⏹️ Pre-start aborted: stream missing");
            return;
          }
        }
        isPaused = false;
        wcFrameLoopActive = true;
        isRecording = true;
        try {
          chrome.runtime.sendMessage({
            type: "STREAM_START",
            mode,
            metadata: { engine: "webcodecs", width, height, framerate, bitrate, startTime: recordingStartTime }
          });
        } catch {
        }
        let frameIndex = 0;
        const keyEvery = Math.max(1, framerate * 2);
        (async () => {
          try {
            while (wcFrameLoopActive) {
              const { value: frame, done } = await reader.read();
              if (done || !frame) break;
              if (isPaused) {
                try {
                  frame.close();
                } catch {
                }
                continue;
              }
              const keyFrame = frameIndex === 0 || frameIndex % keyEvery === 0;
              wcWorker?.postMessage({ type: "encode", frame, keyFrame }, [frame]);
              frameIndex++;
            }
          } catch (err) {
            log("❌ Frame loop error:", err);
          }
        })();
        log(`✅ [${timestamp}] Recording started successfully:`, {
          engine: "webcodecs",
          width,
          height,
          framerate,
          bitrate,
          chunkStrategy: "frame-stream"
        });
      } catch (e) {
        log("❌ Failed to start recording:", e);
        isRecording = false;
        recordingStartTime = null;
        try {
          chrome.runtime.sendMessage({
            type: "STREAM_ERROR",
            error: String(e)
          });
        } catch {
        }
        throw e;
      }
    }
    function stopRecordingInternal() {
      const timestamp = (/* @__PURE__ */ new Date()).toISOString();
      log(`🛑 [${timestamp}] Stopping recording...`);
      log("[stop-share] offscreen: stopRecordingInternal invoked");
      try {
        try {
          wcFrameLoopActive = false;
          wcWorker?.postMessage({ type: "stop" });
        } catch (e) {
          log("❌ Error posting stop to WebCodecs worker:", e);
        }
        wcWorker = null;
        wcReader = null;
        if (mediaRecorder && mediaRecorder.state !== "inactive") {
          log("📹 Stopping MediaRecorder...");
          mediaRecorder.stop();
        }
        if (currentStream) {
          const tracks = currentStream.getTracks();
          tracks.forEach((track, index) => {
            try {
              track.stop();
              log(`🔇 Stopped track ${index + 1}/${tracks.length}: ${track.kind}`);
            } catch (e) {
              log(`❌ Error stopping track ${index + 1}:`, e);
            }
          });
          currentStream = null;
        }
        log(`✅ [${timestamp}] Recording cleanup completed`);
        try {
          log("[stop-share] offscreen: sending STREAM_END");
          chrome.runtime.sendMessage({ type: "STREAM_END" });
        } catch {
          log("[stop-share] offscreen: failed to send STREAM_END");
        }
      } catch (e) {
        log("❌ Error during recording cleanup:", e);
        try {
          log("[stop-share] offscreen: sending STREAM_END (error path)");
          chrome.runtime.sendMessage({ type: "STREAM_END" });
        } catch {
          log("[stop-share] offscreen: failed to send STREAM_END (error path)");
        }
      } finally {
        isRecording = false;
        isPaused = false;
        recordingStartTime = null;
        mediaRecorder = null;
        recordedChunks = [];
      }
    }
    try {
      chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        const type = msg?.type;
        const timestamp = (/* @__PURE__ */ new Date()).toISOString();
        const isForOffscreen = msg?.target === "offscreen-doc" && typeof type === "string" && type.startsWith("OFFSCREEN_");
        if (!isForOffscreen) {
          return false;
        }
        log(`📨 [${timestamp}] Received message:`, {
          type,
          target: msg?.target,
          trigger: msg?.trigger,
          hasPayload: !!msg?.payload,
          sender: sender?.tab?.id ? `tab:${sender.tab.id}` : "extension"
        });
        switch (type) {
          case "OFFSCREEN_PING":
            log("🏓 PING received:", msg);
            try {
              sendResponse?.({
                ok: true,
                pong: Date.now(),
                timestamp,
                status: isRecording ? "recording" : "idle"
              });
            } catch (e) {
              log("❌ Failed to send PING response:", e);
            }
            return true;
          case "OFFSCREEN_START_RECORDING":
          case "start-recording-offscreen": {
            const options = msg?.payload?.options || msg?.payload;
            log(`🎬 [${timestamp}] START_RECORDING request:`, {
              options,
              currentlyRecording: isRecording,
              message: "Will request display media directly in offscreen"
            });
            (async () => {
              try {
                await startRecording(options);
                log(`✅ [${timestamp}] Recording started successfully`);
                try {
                  sendResponse?.({
                    ok: true,
                    message: "Recording started via getDisplayMedia",
                    timestamp
                  });
                } catch (e) {
                  log("❌ Failed to send success response:", e);
                }
              } catch (e) {
                const error = String(e);
                log(`❌ [${timestamp}] Failed to start recording:`, error);
                try {
                  sendResponse?.({
                    ok: false,
                    error,
                    timestamp
                  });
                } catch (err) {
                  log("❌ Failed to send error response:", err);
                }
              }
            })();
            return true;
          }
          case "OFFSCREEN_STOP_RECORDING":
            log(`🛑 [${timestamp}] STOP_RECORDING request`);
            log("[stop-share] offscreen: OFFSCREEN_STOP_RECORDING received");
            try {
              stopRecordingInternal();
              log(`✅ [${timestamp}] Recording stopped successfully`);
              try {
                sendResponse?.({
                  ok: true,
                  message: "Recording stopped",
                  timestamp
                });
              } catch (e) {
                log("❌ Failed to send stop response:", e);
              }
            } catch (e) {
              const error = String(e);
              log(`❌ [${timestamp}] Failed to stop recording:`, error);
              try {
                sendResponse?.({
                  ok: false,
                  error,
                  timestamp
                });
              } catch (err) {
                log("❌ Failed to send error response:", err);
              }
            }
            return true;
          case "OFFSCREEN_TOGGLE_PAUSE": {
            const desired = msg?.payload && typeof msg.payload.paused === "boolean" ? !!msg.payload.paused : !isPaused;
            isPaused = desired;
            try {
              chrome.runtime.sendMessage({ type: "STREAM_META", meta: { paused: isPaused } });
            } catch {
            }
            try {
              sendResponse?.({ ok: true, paused: isPaused });
            } catch {
            }
            return true;
          }
          case "OFFSCREEN_GET_STATUS":
            log(`📊 [${timestamp}] STATUS request`);
            try {
              const status = {
                isRecording,
                recordingStartTime,
                currentStreamId: currentStream?.id,
                recordedChunks: recordedChunks.length,
                timestamp
              };
              sendResponse?.({ ok: true, status });
            } catch (e) {
              log("❌ Failed to send status response:", e);
              try {
                sendResponse?.({ ok: false, error: String(e) });
              } catch (err) {
                log("❌ Failed to send error response:", err);
              }
            }
            return true;
          default:
            log(`❓ [${timestamp}] Unknown message type:`, type);
            return false;
        }
      });
      log("✅ Message listener registered successfully");
    } catch (e) {
      log("❌ Failed to register message listener:", e);
    }
    window.addEventListener("beforeunload", () => {
      log("🧹 Offscreen document unloading, cleaning up...");
      if (isRecording) {
        stopRecordingInternal();
      }
    });
    setInterval(() => {
      if (isRecording && recordingStartTime) {
        const duration = Date.now() - recordingStartTime;
        log(`⏱️ Recording status: ${(duration / 1e3).toFixed(1)}s, ${recordedChunks.length} chunks`);
      }
    }, 1e4);
  })();
})();
