
				{
					__sveltekit_was2qe = {
						base: new URL(".", location).pathname.slice(0, -1)
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("./app/immutable/entry/start.CVurhtAR.js"),
						import("./app/immutable/entry/app.BkSC3a_P.js")
					]).then(([kit, app]) => {
						kit.start(app, element, {
							node_ids: [0, 12],
							data: [null,null],
							form: null,
							error: null
						});
					});
				}
			