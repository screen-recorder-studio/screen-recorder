(function() {
  "use strict";
  let encoder = null;
  let chunks = [];
  let currentEncoderConfig = null;
  self.onmessage = async (event) => {
    const { type, config, frame, keyFrame } = event.data;
    console.log(`📨 [WORKER] Received message from main thread:`, { type, hasConfig: !!config, hasFrame: !!frame, keyFrame: keyFrame === true });
    switch (type) {
      case "configure":
        console.log("⚙️ [WORKER] Configuring encoder...");
        await configureEncoder(config);
        break;
      case "encode":
        if (encoder && frame) {
          await encodeFrame(frame, keyFrame === true);
        } else {
          console.warn("⚠️ [WORKER] Cannot encode: encoder or frame missing");
        }
        break;
      case "stop":
        console.log("🛑 [WORKER] Stopping encoding...");
        await stopEncoding();
        break;
      default:
        console.warn("⚠️ [WORKER] Unknown message type:", type);
    }
  };
  async function configureEncoder(config) {
    try {
      console.log("🔧 [WORKER] Starting encoder configuration...");
      console.log("🔧 [WORKER] Received config:", config);
      console.log("🔍 [WORKER] Checking WebCodecs APIs availability...");
      const hasVideoEncoder = typeof VideoEncoder !== "undefined";
      const hasEncodedVideoChunk = typeof EncodedVideoChunk !== "undefined";
      const hasVideoFrame = typeof VideoFrame !== "undefined";
      console.log("🔍 [WORKER] VideoEncoder available:", hasVideoEncoder);
      console.log("🔍 [WORKER] EncodedVideoChunk available:", hasEncodedVideoChunk);
      console.log("🔍 [WORKER] VideoFrame available:", hasVideoFrame);
      if (!hasVideoEncoder || !hasEncodedVideoChunk || !hasVideoFrame) {
        throw new Error("WebCodecs APIs not fully supported in this worker");
      }
      console.log("✅ [WORKER] All WebCodecs APIs are available");
      console.log("🏗️ [WORKER] Creating VideoEncoder instance...");
      encoder = new VideoEncoder({
        output: handleEncodedChunk,
        error: handleEncodingError
      });
      console.log("✅ [WORKER] VideoEncoder instance created");
      const codecConfigs = [
        // VP8 - 最兼容，简单字符串
        {
          codec: "vp8",
          width: config.width || 1920,
          height: config.height || 1080,
          bitrate: config.bitrate || 8e6,
          framerate: config.framerate || 30
        },
        // H.264 Baseline Profile - 广泛支持
        {
          codec: "avc1.42001E",
          width: config.width || 1920,
          height: config.height || 1080,
          bitrate: config.bitrate || 8e6,
          framerate: config.framerate || 30
        },
        // VP9 - 如果支持的话
        {
          codec: "vp09.00.10.08",
          width: config.width || 1920,
          height: config.height || 1080,
          bitrate: config.bitrate || 8e6,
          framerate: config.framerate || 30
        }
      ];
      let encoderConfig = null;
      let supportedCodec = "";
      console.log("🔍 [WORKER] Testing codec configurations...");
      for (let i = 0; i < codecConfigs.length; i++) {
        const testConfig = codecConfigs[i];
        console.log(`🔍 [WORKER] Testing codec ${i + 1}/${codecConfigs.length}: ${testConfig.codec}`);
        try {
          const supportResult = await VideoEncoder.isConfigSupported(testConfig);
          console.log(`🔍 [WORKER] Support result for ${testConfig.codec}:`, supportResult);
          if (supportResult.supported) {
            encoderConfig = testConfig;
            supportedCodec = testConfig.codec;
            console.log(`✅ [WORKER] Found supported codec: ${supportedCodec}`);
            break;
          } else {
            console.log(`❌ [WORKER] Codec ${testConfig.codec} not supported`);
          }
        } catch (error) {
          console.log(`❌ [WORKER] Error testing codec ${testConfig.codec}:`, error);
          continue;
        }
      }
      if (!encoderConfig) {
        throw new Error("No supported video codec configuration found");
      }
      console.log("⚙️ [WORKER] Using encoder configuration:", encoderConfig);
      console.log("🔧 [WORKER] Applying configuration to encoder...");
      encoder.configure(encoderConfig);
      currentEncoderConfig = encoderConfig;
      console.log("🎉 [WORKER] ✅ WebCodecs encoder configured successfully!");
      self.postMessage({
        type: "configured",
        config: encoderConfig
      });
    } catch (error) {
      console.error("❌ [WORKER] Encoder configuration failed:", error);
      self.postMessage({
        type: "error",
        data: error.message || "Configuration failed"
      });
    }
  }
  async function encodeFrame(frame, forceKey = false) {
    try {
      if (!encoder) {
        throw new Error("Encoder not configured");
      }
      try {
        const fw = frame.displayWidth || frame.codedWidth;
        const fh = frame.displayHeight || frame.codedHeight;
        if (fw && fh && currentEncoderConfig?.width && currentEncoderConfig?.height) {
          const srcAR = fw / fh;
          const encAR = currentEncoderConfig.width / currentEncoderConfig.height;
          const diff = Math.abs(srcAR - encAR);
          if (diff > 0.02) {
            console.warn(`⚠️ [WORKER] Aspect ratio mismatch: src ${fw}x${fh} (${srcAR.toFixed(3)}) vs enc ${currentEncoderConfig.width}x${currentEncoderConfig.height} (${encAR.toFixed(3)})`);
          }
        }
      } catch {
      }
      encoder.encode(frame, { keyFrame: forceKey === true });
      frame.close();
    } catch (error) {
      console.error("❌ [WORKER] Frame encoding failed:", error);
      self.postMessage({
        type: "error",
        data: error.message || "Frame encoding failed"
      });
    }
  }
  function handleEncodedChunk(chunk, metadata) {
    try {
      const data = new Uint8Array(chunk.byteLength);
      chunk.copyTo(data);
      chunks.push(data);
      self.postMessage({
        type: "chunk",
        data: {
          data,
          // 实际的编码数据
          size: chunk.byteLength,
          timestamp: chunk.timestamp,
          type: chunk.type,
          totalChunks: chunks.length,
          // 添加分辨率信息
          codedWidth: currentEncoderConfig?.width || 1920,
          codedHeight: currentEncoderConfig?.height || 1080,
          codec: currentEncoderConfig?.codec || "vp8"
        }
      });
      console.log(`📦 Encoded chunk: ${chunk.byteLength} bytes, type: ${chunk.type}, resolution: ${currentEncoderConfig?.width || 1920}x${currentEncoderConfig?.height || 1080}`);
    } catch (error) {
      console.error("❌ [WORKER] Chunk handling failed:", error);
      self.postMessage({
        type: "error",
        data: error.message || "Chunk handling failed"
      });
    }
  }
  function handleEncodingError(error) {
    console.error("❌ Encoding error:", error);
    self.postMessage({
      type: "error",
      data: error.message
    });
  }
  async function stopEncoding() {
    try {
      if (encoder) {
        await encoder.flush();
        encoder.close();
        encoder = null;
      }
      const totalSize = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
      const finalData = new Uint8Array(totalSize);
      let offset = 0;
      for (const chunk of chunks) {
        finalData.set(chunk, offset);
        offset += chunk.length;
      }
      self.postMessage({
        type: "complete",
        data: finalData
      }, { transfer: [finalData.buffer] });
      console.log("✅ WebCodecs encoding completed");
      chunks = [];
    } catch (error) {
      console.error("❌ [WORKER] Stop encoding failed:", error);
      self.postMessage({
        type: "error",
        data: error.message || "Stop encoding failed"
      });
    }
  }
  self.onerror = (error) => {
    console.error("❌ [WORKER] Worker error:", error);
    self.postMessage({
      type: "error",
      data: typeof error === "string" ? error : "Unknown worker error"
    });
  };
  console.log("🔧 [WORKER] WebCodecs Worker initialized");
  self.postMessage({
    type: "initialized",
    data: "Worker is ready to receive messages"
  });
})();
