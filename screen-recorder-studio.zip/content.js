(function() {
  "use strict";
  (() => {
    if (window.__mcp_injected) return;
    window.__mcp_injected = true;
    const state = {
      mode: "element",
      selecting: false,
      recording: false,
      paused: false,
      selectedElement: null,
      selectionBox: null,
      maskOverlay: null,
      isDragging: false,
      startX: 0,
      startY: 0,
      stream: null,
      track: null,
      root: null,
      preview: null,
      // 容器样式分离相关字段
      elementContainer: null,
      elementRecordingTarget: null,
      regionContainer: null,
      regionRecordingTarget: null,
      // MediaRecorder fallback fields
      mediaRecorder: null,
      recordedChunks: [],
      videoBlob: null,
      // WebCodecs pipeline fields
      usingWebCodecs: false,
      encoder: null,
      processor: null,
      reader: null,
      chunkCount: 0,
      byteCount: 0,
      worker: null,
      workerBlobUrl: null,
      // iframe sink (probe) window for direct ArrayBuffer transfer logging
      sinkWin: null,
      sinkStarted: false,
      // 编码数据收集
      encodedChunks: [],
      recordingMetadata: null,
      // Countdown overlay for delayed start
      countdownOverlay: null,
      countdownTimer: null,
      countdownPending: false
    };
    let selectionTipEl = null;
    let selectionTipTimer = null;
    function showSelectionTip(mode) {
      try {
        hideSelectionTip();
      } catch {
      }
      const el = document.createElement("div");
      el.className = "mcp-selection-tip";
      el.textContent = mode === "element" ? "提示：点击页面中的一个元素完成选择，然后回到扩展弹窗点击“开始录制”。" : "提示：按住鼠标拖拽选择一个区域，然后回到扩展弹窗点击“开始录制”。";
      el.style.cssText = [
        "position:fixed",
        "top:16px",
        "left:50%",
        "transform:translateX(-50%)",
        "z-index:2147483647",
        "background:rgba(17,24,39,0.9)",
        "color:#fff",
        "padding:8px 12px",
        "border-radius:8px",
        "font-size:12px",
        "box-shadow:0 8px 24px rgba(0,0,0,.25)"
      ].join(";");
      document.documentElement.appendChild(el);
      selectionTipEl = el;
      try {
        if (selectionTipTimer) clearTimeout(selectionTipTimer);
      } catch {
      }
      selectionTipTimer = setTimeout(() => {
        try {
          hideSelectionTip();
        } catch {
        }
      }, 3500);
    }
    function hideSelectionTip() {
      try {
        if (selectionTipTimer) clearTimeout(selectionTipTimer);
        selectionTipTimer = null;
      } catch {
      }
      if (selectionTipEl) {
        try {
          selectionTipEl.remove();
        } catch {
        }
        selectionTipEl = null;
      }
    }
    state.controlBar = null;
    state.controlBarVisible = false;
    state.barHideTimer = null;
    function isInputLike(target) {
      if (!(target instanceof Element)) return false;
      const tag = target.tagName?.toLowerCase() || "";
      if (["input", "textarea", "select", "button"].includes(tag)) return true;
      if (target.isContentEditable) return true;
      const editable = (el) => !!el && (el.getAttribute && el.getAttribute("contenteditable") === "true");
      return editable(target) || !!target.closest && !!target.closest('[contenteditable="true"]');
    }
    function ensureControlBar() {
      const existing = document.querySelector(".mcp-control-bar");
      if (existing) {
        state.controlBar = existing;
        return existing;
      }
      if (state.controlBar && document.documentElement.contains(state.controlBar)) return state.controlBar;
      const bar = document.createElement("div");
      bar.className = "mcp-control-bar";
      bar.innerHTML = [
        '<div class="info"><span class="mode">—</span><span class="sp"> · </span><span class="desc">未选择</span></div>',
        '<button class="btn btn-pick-region">选区域</button>',
        '<button class="btn btn-pick-element">选元素</button>',
        '<button class="btn primary btn-start">开始录制</button>',
        '<button class="btn btn-pause" style="display:none">暂停</button>',
        '<button class="btn btn-resume" style="display:none">继续</button>',
        '<button class="btn danger btn-stop" style="display:none">停止</button>',
        '<button class="btn btn-close" style="display:none">关闭</button>'
      ].join("");
      const host = document.body || document.documentElement;
      host.appendChild(bar);
      state.controlBar = bar;
      const onPause = () => {
        try {
          onBarTogglePause();
        } catch {
        }
      };
      const onResume = () => {
        try {
          onBarTogglePause();
        } catch {
        }
      };
      const onStop = () => {
        try {
          onBarStop();
        } catch {
        }
      };
      bar.querySelector(".btn-pick-region")?.addEventListener("click", onBarPickRegion);
      bar.querySelector(".btn-pick-element")?.addEventListener("click", onBarPickElement);
      bar.querySelector(".btn-start")?.addEventListener("click", onBarPrimary);
      bar.querySelector(".btn-pause")?.addEventListener("click", onPause);
      bar.querySelector(".btn-resume")?.addEventListener("click", onResume);
      bar.querySelector(".btn-stop")?.addEventListener("click", onStop);
      bar.querySelector(".btn-close")?.addEventListener("click", onBarClose);
      return bar;
    }
    function updateControlBar() {
      const bar = ensureControlBar();
      try {
        const modeText = state.mode === "region" ? "区域" : "元素";
        const desc = state.mode === "region" && state.selectionBox && state.selectionBox.style.display !== "none" ? `${Math.round(parseFloat(state.selectionBox.style.width || "0"))}×${Math.round(parseFloat(state.selectionBox.style.height || "0"))}` : state.selectedElement ? getElDesc(state.selectedElement) : state.mode === "region" && state.regionContainer ? "已选择区域" : "未选择";
        bar.querySelector(".mode").textContent = modeText;
        bar.querySelector(".desc").textContent = desc || "未选择";
      } catch {
      }
      const btnStart = bar.querySelector(".btn-start");
      const btnPause = bar.querySelector(".btn-pause");
      const btnResume = bar.querySelector(".btn-resume");
      const btnStop = bar.querySelector(".btn-stop");
      const btnPickRegion = bar.querySelector(".btn-pick-region");
      const btnPickElement = bar.querySelector(".btn-pick-element");
      const btnClose = bar.querySelector(".btn-close");
      const hasSelection = !!(state.elementRecordingTarget || state.regionRecordingTarget);
      if (!state.recording) {
        if (btnStart) {
          btnStart.style.display = "inline-flex";
          btnStart.disabled = !hasSelection;
          btnStart.textContent = "开始录制";
        }
        if (btnPause) btnPause.style.display = "none";
        if (btnResume) btnResume.style.display = "none";
        if (btnStop) {
          btnStop.style.display = "none";
        }
        if (btnPickRegion) {
          btnPickRegion.style.display = "inline-flex";
          btnPickRegion.disabled = false;
        }
        if (btnPickElement) {
          btnPickElement.style.display = "inline-flex";
          btnPickElement.disabled = false;
        }
        if (btnClose) {
          btnClose.style.display = "inline-flex";
        }
      } else {
        if (btnStart) {
          btnStart.style.display = "inline-flex";
          btnStart.disabled = false;
          btnStart.textContent = "停止录制";
        }
        if (state.paused) {
          if (btnPause) btnPause.style.display = "none";
          if (btnResume) btnResume.style.display = "inline-flex";
        } else {
          if (btnPause) {
            btnPause.style.display = "inline-flex";
            btnPause.disabled = false;
          }
          if (btnResume) btnResume.style.display = "none";
        }
        if (btnStop) {
          btnStop.style.display = "none";
        }
        if (btnPickRegion) btnPickRegion.style.display = "none";
        if (btnPickElement) btnPickElement.style.display = "none";
        if (btnClose) btnClose.style.display = "none";
      }
    }
    function showControlBar(forceVisible = false) {
      const bar = ensureControlBar();
      if (!state.controlBarVisible || forceVisible) {
        bar.classList.add("visible");
        state.controlBarVisible = true;
        updateControlBar();
      }
    }
    function hideControlBar(immediate = false) {
      const bar = ensureControlBar();
      if (immediate) {
        bar.classList.remove("visible");
        state.controlBarVisible = false;
        return;
      }
      bar.classList.remove("visible");
      state.controlBarVisible = false;
    }
    function onMouseMoveReveal(e) {
      if (!state.recording) return;
      showControlBar(true);
    }
    function onHotkeys(e) {
      if (isInputLike(e.target)) return;
      if ((e.key === "Enter" || e.code === "Enter") && !state.recording) {
        const hasSelection = !!(state.elementRecordingTarget || state.regionRecordingTarget);
        if (!hasSelection) return;
        e.preventDefault();
        onBarStart();
        return;
      }
      if ((e.key === " " || e.code === "Space") && state.recording) {
        e.preventDefault();
        onBarTogglePause();
        return;
      }
      if ((e.key?.toLowerCase?.() === "s" || e.code === "KeyS") && (e.shiftKey || e.altKey) && state.recording) {
        e.preventDefault();
        onBarStop();
        return;
      }
    }
    function onBarPrimary() {
      if (!state.recording) {
        try {
          onBarStart();
        } catch {
        }
      } else {
        try {
          onBarStop();
        } catch {
        }
      }
    }
    function onBarStart() {
      if (!state.recording) {
        try {
          startCapture();
        } catch {
        }
      }
    }
    function onBarTogglePause() {
      if (state.recording) {
        try {
          setPaused(!state.paused);
          updateControlBar();
        } catch {
        }
      }
    }
    function onBarStop() {
      if (state.recording) {
        try {
          stopCapture();
        } catch {
        }
      }
    }
    function onBarPickRegion() {
      if (state.recording) return;
      try {
        clearSelection();
      } catch {
      }
      state.mode = "region";
      try {
        enterSelection();
      } catch {
      }
      try {
        showControlBar(true);
        updateControlBar();
      } catch {
      }
    }
    function onBarPickElement() {
      if (state.recording) return;
      try {
        clearSelection();
      } catch {
      }
      state.mode = "element";
      try {
        enterSelection();
      } catch {
      }
      try {
        showControlBar(true);
        updateControlBar();
      } catch {
      }
    }
    function onBarClose() {
      try {
        hideControlBar(true);
      } catch {
      }
    }
    window.addEventListener("mousemove", onMouseMoveReveal, { passive: true });
    window.addEventListener("keydown", onHotkeys, true);
    window.addEventListener("scroll", () => {
      try {
        syncElementContainer();
      } catch {
      }
    }, true);
    window.addEventListener("resize", () => {
      try {
        syncElementContainer();
      } catch {
      }
    });
    let streamingReady = false;
    const root = document.createElement("div");
    root.className = "mcp-ext-root";
    document.documentElement.appendChild(root);
    state.root = root;
    try {
      const caps = {
        getDisplayMedia: !!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia),
        restrictionTarget: typeof window.RestrictionTarget !== "undefined",
        cropTarget: typeof window.CropTarget !== "undefined"
      };
      chrome.runtime.sendMessage({ type: "CONTENT_REPORT", partial: { capabilities: caps } });
    } catch (e) {
    }
    function report(partial) {
      chrome.runtime.sendMessage({ type: "CONTENT_REPORT", partial });
    }
    function safePortPost(msg) {
      try {
        chrome.runtime.sendMessage(msg);
      } catch (e) {
        console.warn("[Stream][Content] sendMessage failed", e);
      }
    }
    function safeSinkPost(msg, transfer) {
      try {
        if (transfer && transfer.length) ;
        else {
          state.sinkWin?.postMessage(msg, "*");
        }
      } catch (e) {
        console.warn("[Stream][Content] sink post failed", e);
      }
    }
    function setPaused(p) {
      try {
        if (!state.recording) return;
        state.paused = !!p;
        if (!state.usingWebCodecs && state.mediaRecorder) {
          try {
            if (state.paused && state.mediaRecorder.state === "recording") {
              state.mediaRecorder.pause();
            } else if (!state.paused && state.mediaRecorder.state === "paused") {
              state.mediaRecorder.resume();
            }
          } catch {
          }
        }
        try {
          showControlBar(true);
          updateControlBar();
        } catch {
        }
        safePortPost({ type: "STREAM_META", meta: { paused: state.paused } });
      } catch {
      }
    }
    async function ensureSinkIframe() {
      try {
        if (state.sinkWin && typeof state.sinkWin.postMessage === "function") return state.sinkWin;
        const iframe = document.createElement("iframe");
        iframe.style.cssText = "position:fixed; right:0; bottom:0; width:1px; height:1px; opacity:0; border:0; z-index:2147483647;";
        iframe.src = chrome.runtime.getURL("opfs-writer.html?mode=iframe");
        document.documentElement.appendChild(iframe);
        await new Promise((r) => iframe.onload = r);
        const win = iframe.contentWindow;
        if (!win) return null;
        const ok = await new Promise((resolve) => {
          const timer = setTimeout(() => {
            window.removeEventListener("message", onMsg);
            resolve(false);
          }, 4e3);
          function onMsg(ev) {
            if (ev.source === win && ev.data && ev.data.type === "sink-ready") {
              clearTimeout(timer);
              window.removeEventListener("message", onMsg);
              resolve(true);
            }
          }
          window.addEventListener("message", onMsg);
          try {
            win.postMessage({ type: "ping" }, "*");
          } catch {
          }
        });
        if (ok) state.sinkWin = win;
        return ok ? win : null;
      } catch (e) {
        return null;
      }
    }
    function createElementContainer(targetElement) {
      const container = document.createElement("div");
      container.className = "mcp-element-container";
      const recordingTarget = document.createElement("div");
      recordingTarget.className = "mcp-recording-target";
      const rect = targetElement.getBoundingClientRect();
      container.style.cssText = `
      position: fixed;
      left: ${rect.left}px;
      top: ${rect.top}px;
      width: ${rect.width}px;
      height: ${rect.height}px;
      pointer-events: none;
      z-index: 2147483001;
    `;
      recordingTarget.style.cssText = `
      position: absolute;
      left: 5px;
      top: 5px;
      right: 5px;
      bottom: 5px;
      background: transparent;
      border: none;
      outline: none;
      pointer-events: none;
    `;
      container.appendChild(recordingTarget);
      return { container, recordingTarget };
    }
    function createRegionContainer(x, y, width, height) {
      const container = document.createElement("div");
      container.className = "mcp-region-container";
      container.style.cssText = `
      position: fixed;
      left: ${x}px;
      top: ${y}px;
      width: ${width}px;
      height: ${height}px;
      pointer-events: none;
      z-index: 2147483001;
    `;
      const recordingTarget = document.createElement("div");
      recordingTarget.className = "mcp-recording-target";
      recordingTarget.style.cssText = `
      position: absolute;
      left: 2px;
      top: 2px;
      right: 2px;
      bottom: 2px;
      background: transparent;
      border: none;
      outline: none;
      pointer-events: none;
    `;
      container.appendChild(recordingTarget);
      return { container, recordingTarget };
    }
    function syncElementContainer() {
      if (!state.selectedElement || !state.elementContainer) return;
      const rect = state.selectedElement.getBoundingClientRect();
      state.elementContainer.style.left = rect.left + "px";
      state.elementContainer.style.top = rect.top + "px";
      state.elementContainer.style.width = rect.width + "px";
      state.elementContainer.style.height = rect.height + "px";
      try {
        updateMaskRect(rect.left, rect.top, rect.width, rect.height);
      } catch {
      }
    }
    function clearElementSelection() {
      if (state.elementContainer) {
        state.elementContainer.remove();
        state.elementContainer = null;
        state.elementRecordingTarget = null;
      }
      if (state.selectedElement) {
        state.selectedElement.classList.remove("mcp-selected");
        state.selectedElement = null;
      }
    }
    function clearRegionSelection() {
      if (state.regionContainer) {
        state.regionContainer.remove();
        state.regionContainer = null;
        state.regionRecordingTarget = null;
      }
      if (state.selectionBox) {
        state.selectionBox.style.display = "none";
        state.selectionBox = null;
      }
    }
    function ensureSelectionBox() {
      if (!state.selectionBox) {
        state.selectionBox = document.createElement("div");
        state.selectionBox.className = "mcp-selection-box";
        state.selectionBox.style.left = "0px";
        state.selectionBox.style.top = "0px";
        state.selectionBox.style.width = "0px";
        state.selectionBox.style.height = "0px";
        state.selectionBox.style.display = "none";
        root.appendChild(state.selectionBox);
      }
      return state.selectionBox;
    }
    function ensureMaskOverlay() {
      try {
        if (state.maskOverlay && document.documentElement.contains(state.maskOverlay)) return state.maskOverlay;
        const el = document.createElement("div");
        el.className = "mcp-mask-overlay";
        el.style.cssText = [
          "position:fixed",
          "inset:0",
          // Visual dim
          "background:rgba(0,0,0,0.35)",
          // Keep it below selection containers and control bar
          "z-index:2147482998",
          // Visual-only by default; avoid interfering with existing handlers
          "pointer-events:none",
          // -webkit-mask: full-screen minus hole at (--mcp-mask-x, --mcp-mask-y) sized (--mcp-mask-w x --mcp-mask-h)
          "-webkit-mask-image:linear-gradient(#fff 0 0),linear-gradient(#fff 0 0)",
          "-webkit-mask-size:cover,var(--mcp-mask-w,0px) var(--mcp-mask-h,0px)",
          "-webkit-mask-position:0 0,var(--mcp-mask-x,-99999px) var(--mcp-mask-y,-99999px)",
          "-webkit-mask-repeat:no-repeat",
          // Subtract second mask from the first (Chromium)
          "-webkit-mask-composite:xor"
        ].join(";");
        state.root.appendChild(el);
        state.maskOverlay = el;
        return el;
      } catch (_) {
        return null;
      }
    }
    function showMask() {
      try {
        const el = ensureMaskOverlay();
        if (el) el.style.display = "block";
      } catch {
      }
    }
    function hideMask() {
      try {
        if (state.maskOverlay) {
          state.maskOverlay.style.display = "none";
        }
      } catch {
      }
    }
    function updateMaskRect(x, y, w, h) {
      try {
        const el = ensureMaskOverlay();
        if (!el) return;
        el.style.setProperty("--mcp-mask-x", `${Math.max(0, Math.round(x))}px`);
        el.style.setProperty("--mcp-mask-y", `${Math.max(0, Math.round(y))}px`);
        el.style.setProperty("--mcp-mask-w", `${Math.max(0, Math.round(w))}px`);
        el.style.setProperty("--mcp-mask-h", `${Math.max(0, Math.round(h))}px`);
        showMask();
      } catch {
      }
    }
    function updateMaskForElement(el) {
      try {
        if (!el || !(el instanceof Element)) return;
        const r = el.getBoundingClientRect();
        updateMaskRect(r.left, r.top, r.width, r.height);
      } catch {
      }
    }
    function addDragOverlay() {
      const overlay = document.createElement("div");
      overlay.className = "mcp-drag-overlay";
      root.appendChild(overlay);
      overlay.addEventListener("mousedown", (e) => {
        if (state.mode !== "region") return;
        state.isDragging = true;
        const sb = ensureSelectionBox();
        sb.style.display = "block";
        state.startX = e.clientX;
        state.startY = e.clientY;
        sb.style.left = `${state.startX}px`;
        sb.style.top = `${state.startY}px`;
        sb.style.width = "0px";
        sb.style.height = "0px";
        try {
          updateMaskRect(state.startX, state.startY, 0, 0);
        } catch {
        }
        e.preventDefault();
        e.stopPropagation();
      }, true);
      window.addEventListener("mousemove", (e) => {
        if (!state.isDragging || state.mode !== "region") return;
        const sb = ensureSelectionBox();
        const x = Math.min(state.startX, e.clientX);
        const y = Math.min(state.startY, e.clientY);
        const w = Math.abs(e.clientX - state.startX);
        const h = Math.abs(e.clientY - state.startY);
        sb.style.left = `${x}px`;
        sb.style.top = `${y}px`;
        sb.style.width = `${w}px`;
        sb.style.height = `${h}px`;
        try {
          updateMaskRect(x, y, w, h);
        } catch {
        }
      }, true);
      window.addEventListener("mouseup", () => {
        if (!state.isDragging || state.mode !== "region") return;
        state.isDragging = false;
        const sb = ensureSelectionBox();
        const w = parseFloat(sb.style.width || "0");
        const h = parseFloat(sb.style.height || "0");
        if (w < 10 || h < 10) {
          sb.style.display = "none";
          clearRegionSelection();
          report({ selectedDesc: void 0 });
        } else {
          const x = parseFloat(sb.style.left || "0");
          const y = parseFloat(sb.style.top || "0");
          const { container, recordingTarget } = createRegionContainer(x, y, w, h);
          state.regionContainer = container;
          state.regionRecordingTarget = recordingTarget;
          root.appendChild(container);
          sb.style.display = "none";
          try {
            updateMaskRect(x, y, w, h);
            showMask();
          } catch {
          }
          report({ selectedDesc: `区域 ${Math.round(w)}×${Math.round(h)}` });
          state.selecting = false;
          if (dragOverlay) {
            try {
              dragOverlay.remove();
            } catch (_) {
            }
            dragOverlay = null;
          }
          report({ selecting: false });
          hideSelectionTip();
          ensureSinkIframe().catch(() => {
          });
          try {
            showControlBar(true);
          } catch {
          }
        }
      }, true);
      return overlay;
    }
    let dragOverlay = null;
    function enterSelection() {
      document.removeEventListener("mouseover", onHover, true);
      document.removeEventListener("mouseout", onOut, true);
      document.removeEventListener("click", onClick, true);
      state.selecting = true;
      try {
        ensureMaskOverlay();
        showMask();
        updateMaskRect(-99999, -99999, 0, 0);
      } catch {
      }
      if (state.mode === "region") {
        dragOverlay = dragOverlay || addDragOverlay();
      } else {
        document.addEventListener("mouseover", onHover, true);
        document.addEventListener("mouseout", onOut, true);
        document.addEventListener("click", onClick, true);
      }
      showSelectionTip(state.mode === "region" ? "region" : "element");
      report({});
    }
    function exitSelection() {
      state.selecting = false;
      try {
        hideMask();
      } catch {
      }
      if (dragOverlay) {
        dragOverlay.remove();
        dragOverlay = null;
      }
      if (state.selectionBox) {
        state.selectionBox.remove();
        state.selectionBox = null;
      }
      clearHighlight();
      document.removeEventListener("mouseover", onHover, true);
      document.removeEventListener("mouseout", onOut, true);
      document.removeEventListener("click", onClick, true);
      hideSelectionTip();
    }
    function isOwnNode(node) {
      return node === root || root.contains(node) || state.preview && (node === state.preview || state.preview.contains(node));
    }
    function onHover(e) {
      if (!state.selecting || state.mode !== "element") return;
      const el = e.target;
      if (!(el instanceof Element)) return;
      if (isOwnNode(el)) return;
      clearHighlight();
      el.classList.add("mcp-highlight");
      try {
        updateMaskForElement(el);
      } catch {
      }
    }
    function onOut(e) {
      if (!state.selecting || state.mode !== "element") return;
      const el = e.target;
      if (!(el instanceof Element)) return;
      el.classList.remove("mcp-highlight");
    }
    function onClick(e) {
      if (!state.selecting || state.mode !== "element") return;
      const el = e.target;
      if (!(el instanceof Element)) return;
      if (isOwnNode(el)) return;
      e.preventDefault();
      e.stopPropagation();
      selectElement(el);
      try {
        updateMaskForElement(el);
        showMask();
      } catch {
      }
      state.selecting = false;
      document.removeEventListener("mouseover", onHover, true);
      document.removeEventListener("mouseout", onOut, true);
      document.removeEventListener("click", onClick, true);
      report({ selecting: false });
      try {
        showControlBar(true);
      } catch {
      }
      hideSelectionTip();
      ensureSinkIframe().catch(() => {
      });
    }
    function clearHighlight() {
      document.querySelectorAll(".mcp-highlight").forEach((n) => n.classList.remove("mcp-highlight"));
    }
    function getElDesc(el) {
      if (!el) return "";
      const tag = el.tagName?.toLowerCase() || "el";
      const id = el.id ? `#${el.id}` : "";
      const cls = el.className && typeof el.className === "string" ? `.${el.className.trim().split(/\s+/).join(".")}` : "";
      return `${tag}${id}${cls}`;
    }
    function selectElement(el) {
      clearElementSelection();
      const { container, recordingTarget } = createElementContainer(el);
      state.selectedElement = el;
      state.elementContainer = container;
      state.elementRecordingTarget = recordingTarget;
      root.appendChild(container);
      clearHighlight();
      report({ selectedDesc: `元素 ${getElDesc(el)}` });
    }
    state.countdownRaf = 0;
    function cancelStartCountdownGlobal() {
      try {
        state.countdownPending = false;
      } catch {
      }
      try {
        if (state.countdownTimer) {
          clearTimeout(state.countdownTimer);
          state.countdownTimer = null;
        }
      } catch {
      }
      try {
        if (state.countdownOverlay) {
          state.countdownOverlay.remove();
          state.countdownOverlay = null;
        }
      } catch {
      }
      try {
        if (state.countdownRaf) {
          cancelAnimationFrame(state.countdownRaf);
          state.countdownRaf = 0;
        }
      } catch {
      }
    }
    async function showStartCountdownGlobal(seconds = 5) {
      try {
        const host = state.elementContainer || state.regionContainer;
        if (!host || seconds <= 0) return;
        try {
          syncElementContainer();
        } catch {
        }
        const overlay = document.createElement("div");
        overlay.className = "mcp-countdown-overlay";
        overlay.style.cssText = [
          "position:absolute",
          "inset:0",
          "display:flex",
          "align-items:center",
          "justify-content:center",
          "background:rgba(0,0,0,0.25)",
          "color:#fff",
          "font-size:96px",
          "font-weight:700",
          "letter-spacing:.02em",
          "text-shadow:0 2px 8px rgba(0,0,0,.35)",
          "z-index:2147483646",
          "pointer-events:none",
          "backdrop-filter:saturate(120%) blur(0px)"
        ].join(";") + ";";
        const label = document.createElement("div");
        label.style.cssText = "padding:.25em .5em; border-radius:.2em; background:rgba(0,0,0,.35)";
        overlay.appendChild(label);
        state.countdownOverlay = overlay;
        state.countdownPending = true;
        host.appendChild(overlay);
        let n = Math.max(1, Math.floor(seconds));
        label.textContent = String(n);
        try {
          chrome.runtime.sendMessage({ type: "STREAM_META", meta: { preparing: true, countdown: n } });
        } catch {
        }
        const raf = () => {
          if (!state.countdownPending) return;
          try {
            syncElementContainer();
          } catch {
          }
          state.countdownRaf = requestAnimationFrame(raf);
        };
        state.countdownRaf = requestAnimationFrame(raf);
        await new Promise((resolve) => {
          const tick = () => {
            if (!state.countdownPending) {
              cancelStartCountdownGlobal();
              resolve();
              return;
            }
            n -= 1;
            if (n <= 0) {
              cancelStartCountdownGlobal();
              resolve();
              return;
            }
            label.textContent = String(n);
            try {
              chrome.runtime.sendMessage({ type: "STREAM_META", meta: { preparing: true, countdown: n } });
            } catch {
            }
            state.countdownTimer = setTimeout(tick, 1e3);
          };
          state.countdownTimer = setTimeout(tick, 1e3);
        });
      } catch (_) {
        cancelStartCountdownGlobal();
      }
    }
    state._cancelStartCountdown = cancelStartCountdownGlobal;
    state._showStartCountdown = showStartCountdownGlobal;
    async function startCapture() {
      if (state.recording) return;
      try {
        let cancelStartCountdown2 = function() {
          try {
            state.countdownPending = false;
          } catch {
          }
          try {
            if (state.countdownTimer) {
              clearTimeout(state.countdownTimer);
              state.countdownTimer = null;
            }
          } catch {
          }
          try {
            if (state.countdownOverlay) {
              state.countdownOverlay.remove();
              state.countdownOverlay = null;
            }
          } catch {
          }
        };
        var cancelStartCountdown = cancelStartCountdown2;
        state.recording = true;
        try {
          showControlBar(true);
          updateControlBar();
        } catch {
        }
        state.chunkCount = 0;
        state.byteCount = 0;
        state.sinkStarted = false;
        const displayMediaOptions = { video: { displaySurface: "window" }, audio: false, preferCurrentTab: true };
        console.log("[Stream][Content] getDisplayMedia request", displayMediaOptions);
        state.stream = await navigator.mediaDevices.getDisplayMedia(displayMediaOptions);
        console.log("[Stream][Content] getDisplayMedia success", {
          tracks: state.stream ? state.stream.getTracks().map((t) => ({ kind: t.kind, label: t.label, readyState: t.readyState })) : null
        });
        if (state._showStartCountdown) await state._showStartCountdown(5);
        state.track = state.stream.getVideoTracks()[0];
        try {
          console.log("[Stream][Content] video track settings", state.track?.getSettings?.());
        } catch {
        }
        if (state.mode === "element" && state.selectedElement && typeof window.RestrictionTarget !== "undefined") {
          try {
            const rt = await window.RestrictionTarget.fromElement(state.selectedElement);
            await state.track.restrictTo(rt);
          } catch (e) {
            console.warn("restrictTo failed, fallback to crop", e);
          }
        }
        if (typeof window.CropTarget !== "undefined") {
          try {
            let recordingTarget = null;
            if (state.mode === "element") {
              recordingTarget = state.elementRecordingTarget;
            } else if (state.mode === "region") {
              recordingTarget = state.regionRecordingTarget;
            }
            if (recordingTarget) {
              const ct = await window.CropTarget.fromElement(recordingTarget);
              await state.track.cropTo(ct);
            }
          } catch (e) {
            console.warn("cropTo failed", e);
          }
        }
        async function showStartCountdown(seconds = 5) {
          try {
            const host = state.elementContainer || state.regionContainer;
            if (!host || seconds <= 0) return;
            const overlay = document.createElement("div");
            overlay.className = "mcp-countdown-overlay";
            overlay.style.cssText = [
              "position:absolute",
              "inset:0",
              "display:flex",
              "align-items:center",
              "justify-content:center",
              "background:rgba(0,0,0,0.25)",
              "color:#fff",
              "font-size:96px",
              "font-weight:700",
              "letter-spacing:.02em",
              "text-shadow:0 2px 8px rgba(0,0,0,.35)",
              "z-index:2147483646",
              "pointer-events:none",
              "backdrop-filter:saturate(120%) blur(0px)"
            ].join(";") + ";";
            const label = document.createElement("div");
            label.style.cssText = "padding:.25em .5em; border-radius:.2em; background:rgba(0,0,0,.35)";
            overlay.appendChild(label);
            state.countdownOverlay = overlay;
            state.countdownPending = true;
            host.appendChild(overlay);
            let n = Math.max(1, Math.floor(seconds));
            label.textContent = String(n);
            await new Promise((resolve) => {
              const tick = () => {
                if (!state.countdownPending) {
                  cancelStartCountdown2();
                  resolve();
                  return;
                }
                n -= 1;
                if (n <= 0) {
                  cancelStartCountdown2();
                  resolve();
                  return;
                }
                label.textContent = String(n);
                state.countdownTimer = setTimeout(tick, 1e3);
              };
              state.countdownTimer = setTimeout(tick, 1e3);
            });
          } catch (_) {
            cancelStartCountdown2();
          }
        }
        const canWebCodecs = typeof window.VideoEncoder !== "undefined" && typeof window.MediaStreamTrackProcessor !== "undefined";
        if (canWebCodecs) {
          state.usingWebCodecs = true;
          const settings = state.track.getSettings ? state.track.getSettings() : {};
          const dpr = window.devicePixelRatio || 1;
          let cssW = 0, cssH = 0;
          try {
            const rt = state.mode === "element" ? state.elementRecordingTarget : state.mode === "region" ? state.regionRecordingTarget : null;
            if (rt && typeof rt.getBoundingClientRect === "function") {
              const r = rt.getBoundingClientRect();
              cssW = r.width || 0;
              cssH = r.height || 0;
            } else if (state.mode === "region" && state.selectionBox) {
              cssW = parseFloat(state.selectionBox.style.width || "0") || 0;
              cssH = parseFloat(state.selectionBox.style.height || "0") || 0;
            }
          } catch {
          }
          let width = Math.max(2, Math.floor(cssW * dpr));
          let height = Math.max(2, Math.floor(cssH * dpr));
          if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 2 || height <= 2) {
            width = settings.width || 1920;
            height = settings.height || 1080;
          }
          if (width % 2) width -= 1;
          if (height % 2) height -= 1;
          const framerate = Math.round(settings.frameRate || 30);
          state.recordingMetadata = {
            mode: state.mode,
            selectedElement: state.selectedElement ? getElDesc(state.selectedElement) : null,
            selectedRegion: state.mode === "region" && state.selectionBox ? {
              width: parseFloat(state.selectionBox.style.width || "0"),
              height: parseFloat(state.selectionBox.style.height || "0"),
              x: parseFloat(state.selectionBox.style.left || "0"),
              y: parseFloat(state.selectionBox.style.top || "0")
            } : null,
            startTime: Date.now(),
            codec: "vp8",
            width,
            height,
            framerate
          };
          console.log("[Stream][Content] recordingMetadata prepared", {
            startTime: state.recordingMetadata.startTime,
            width: state.recordingMetadata.width,
            height: state.recordingMetadata.height,
            framerate: state.recordingMetadata.framerate,
            selection: state.recordingMetadata.selection
          });
          safePortPost({ type: "STREAM_START", codec: "vp8", width, height, framerate, startTime: state.recordingMetadata?.startTime || Date.now() });
          console.log("[Stream][Content] port connected; sending start", { width, height, framerate });
          const workerUrl = chrome.runtime.getURL("encoder-worker.js");
          safePortPost({ type: "STREAM_META", metadata: state.recordingMetadata });
          try {
            const ok = await ensureSinkIframe();
            if (ok && state.sinkWin && !state.sinkStarted) {
              try {
                state.sinkWin.postMessage({ type: "start", codec: "vp8", width, height, framerate }, "*");
                state.sinkWin.postMessage({ type: "meta", metadata: state.recordingMetadata }, "*");
                state.sinkStarted = true;
                console.log("[Stream][Content] sink pre-started with meta");
              } catch (e) {
                console.warn("[Stream][Content] sink pre-start failed", e);
              }
            }
          } catch (e) {
            console.warn("[Stream][Content] ensureSinkIframe failed (pre-start)", e);
          }
          console.log("[Stream][Content] meta posted to background", { startTime: state.recordingMetadata?.startTime });
          let workerText = "";
          try {
            const res = await fetch(workerUrl, { cache: "no-cache" });
            workerText = await res.text();
          } catch (e) {
            console.error("Failed to fetch worker script", e);
            throw e;
          }
          const workerBlob = new Blob([workerText], { type: "text/javascript" });
          state.workerBlobUrl = URL.createObjectURL(workerBlob);
          state.worker = new Worker(state.workerBlobUrl);
          let cleanedUp = false;
          const finalizeStop = () => {
            if (cleanedUp) return;
            cleanedUp = true;
            try {
              state.stream && state.stream.getTracks().forEach((t) => t.stop());
            } catch {
            }
            try {
              state.worker?.terminate();
            } catch {
            }
            if (state.workerBlobUrl) {
              try {
                URL.revokeObjectURL(state.workerBlobUrl);
              } catch {
              }
            }
            state.worker = null;
            state.workerBlobUrl = null;
            state.usingWebCodecs = false;
            state.recording = false;
            state.sinkStarted = false;
            state.chunkCount = 0;
            state.byteCount = 0;
            state.recordingMetadata = null;
            hidePreview();
            try {
              clearSelection();
            } catch {
            }
            report({ recording: false });
            try {
              showControlBar(true);
              updateControlBar();
            } catch {
            }
          };
          state.worker.onmessage = (ev) => {
            const msg = ev.data || {};
            switch (msg.type) {
              case "configured":
                try {
                  const cfg = msg.config || {};
                  if (cfg && (cfg.width || cfg.height || cfg.framerate)) {
                    if (typeof cfg.width === "number") state.recordingMetadata.width = cfg.width;
                    if (typeof cfg.height === "number") state.recordingMetadata.height = cfg.height;
                    if (typeof cfg.framerate === "number") state.recordingMetadata.framerate = cfg.framerate;
                  }
                } catch {
                }
                console.log("[encoder-worker] configured", { codec: state.recordingMetadata?.codec, width: state.recordingMetadata?.width, height: state.recordingMetadata?.height, framerate: state.recordingMetadata?.framerate });
                try {
                  ensureSinkIframe().then(() => {
                    try {
                      if (state.sinkWin && !state.sinkStarted) {
                        state.sinkWin.postMessage({ type: "start", codec: state.recordingMetadata?.codec || "vp8", width: state.recordingMetadata?.width, height: state.recordingMetadata?.height, framerate: state.recordingMetadata?.framerate }, "*");
                        state.sinkWin.postMessage({ type: "meta", metadata: state.recordingMetadata }, "*");
                        state.sinkStarted = true;
                      }
                    } catch {
                    }
                  });
                } catch {
                }
                break;
              case "chunk":
                try {
                  state.chunkCount += 1;
                  state.byteCount += msg.size || 0;
                  try {
                    const sink = state.sinkWin || null;
                    if (sink && msg.data) {
                      sink.postMessage({ type: "chunk", ts: msg.ts, kind: msg.kind, data: msg.data }, "*", [msg.data]);
                    }
                  } catch (_) {
                  }
                } catch (err) {
                  console.error("forward chunk failed", err);
                }
                break;
              case "end":
                safeSinkPost({ type: "end", chunks: state.chunkCount, bytes: state.byteCount });
                safePortPost({ type: "STREAM_END", chunks: state.chunkCount, bytes: state.byteCount });
                console.log(`🎬 [Element Recording] Collected ${state.encodedChunks.length} encoded chunks for editing`);
                finalizeStop();
                break;
              case "error":
                console.error("[encoder-worker] error", msg.message);
                safePortPost({ type: "STREAM_ERROR", message: msg.message });
                finalizeStop();
                break;
              default:
                break;
            }
          };
          state.worker.postMessage({ type: "configure", codec: "vp8", width, height, framerate, bitrate: 4e6 });
          state.processor = new MediaStreamTrackProcessor({ track: state.track });
          state.reader = state.processor.readable.getReader();
          let frameIndex = 0;
          (async () => {
            try {
              for (; ; ) {
                const { done, value: frame } = await state.reader.read();
                if (done) break;
                if (state.paused) {
                  try {
                    frame?.close?.();
                  } catch {
                  }
                  await new Promise((r) => setTimeout(r, 60));
                  continue;
                }
                const keyFrame = frameIndex === 0 || frameIndex % (framerate * 2) === 0;
                state.worker?.postMessage({ type: "frame", frame, keyFrame, i: frameIndex }, [frame]);
                frameIndex++;
              }
              state.worker?.postMessage({ type: "stop" });
            } catch (err) {
              console.error("frame pump error", err);
            }
          })();
        } else {
          state.recordedChunks = [];
          state.mediaRecorder = new MediaRecorder(state.stream, {
            mimeType: "video/webm;codecs=vp9"
          });
          state.mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
              state.recordedChunks.push(event.data);
            }
          };
          state.mediaRecorder.onstop = () => {
            state.videoBlob = new Blob(state.recordedChunks, { type: "video/webm" });
            const videoUrl = URL.createObjectURL(state.videoBlob);
            try {
              clearSelection();
            } catch {
            }
            report({ recording: false, hasVideo: true, videoSize: state.videoBlob.size, videoUrl });
            try {
              showControlBar(true);
              updateControlBar();
            } catch {
            }
          };
          state.mediaRecorder.start(1e3);
        }
        showPreview();
        state.track.onended = () => {
          console.log("[Stream][Content] track.onended fired");
          try {
            stopCapture();
          } catch (err) {
            console.warn("[Stream][Content] stopCapture error from onended", err);
          }
        };
        report({ recording: true });
        try {
          showControlBar(true);
          updateControlBar();
        } catch {
        }
      } catch (e) {
        try {
          showControlBar(true);
          updateControlBar();
        } catch {
        }
        const name = e?.name || "";
        const message = e?.message || "";
        const stack = e?.stack || "";
        console.error("startCapture error", e, { name, message, stack, usingWebCodecs: state.usingWebCodecs, recording: state.recording, chunkCount: state.chunkCount, byteCount: state.byteCount });
        try {
          if (state.stream && !state.mediaRecorder) {
            console.warn("[Stream][Content] Falling back to MediaRecorder...");
            state.recordedChunks = [];
            state.mediaRecorder = new MediaRecorder(state.stream, { mimeType: "video/webm;codecs=vp9" });
            state.mediaRecorder.ondataavailable = (event) => {
              if (event?.data?.size > 0) state.recordedChunks.push(event.data);
            };
            state.mediaRecorder.onstop = () => {
              try {
                state.videoBlob = new Blob(state.recordedChunks, { type: "video/webm" });
                const videoUrl = URL.createObjectURL(state.videoBlob);
                try {
                  clearSelection();
                } catch {
                }
                report({ recording: false, hasVideo: true, videoSize: state.videoBlob.size, videoUrl });
                try {
                  showControlBar(true);
                  updateControlBar();
                } catch {
                }
              } catch (err) {
                console.error("[Stream][Content] MediaRecorder onstop error", err);
              }
            };
            state.mediaRecorder.start(1e3);
            state.recording = true;
            try {
              showPreview();
            } catch {
            }
            report({ recording: true });
            try {
              showControlBar(true);
              updateControlBar();
            } catch {
            }
            return;
          }
        } catch (fallbackErr) {
          console.warn("[Stream][Content] MediaRecorder fallback failed", fallbackErr);
        }
        state.recording = false;
        try {
          chrome.runtime.sendMessage({ type: "CAPTURE_FAILED", error: name || message || String(e) });
        } catch {
        }
        report({ recording: false });
      }
    }
    function stopCapture() {
      console.log("[Stream][Content] stopCapture called", { usingWebCodecs: state.usingWebCodecs, recording: state.recording, chunkCount: state.chunkCount, byteCount: state.byteCount });
      try {
        if (state.usingWebCodecs) {
          try {
            state.reader?.cancel();
          } catch {
          }
          try {
            state.worker?.postMessage({ type: "stop" });
          } catch {
          }
          Promise.resolve(state.encoder?.flush?.()).catch(() => {
          }).finally(() => {
            try {
              state.encoder?.close?.();
            } catch {
            }
          });
          safeSinkPost({ type: "end-request" });
          safePortPost({ type: "STREAM_END_REQUEST" });
          console.log("[Stream][Content] end-request posted", { streamingReady, encodedChunks: state.encodedChunks.length });
          console.log('[Stream][Content] awaiting worker "end" to finalize...');
          if (!state.worker && !state.mediaRecorder) {
            console.log("[Stream][Content] stopCapture during countdown/pre-start");
            try {
              state._cancelStartCountdown?.();
            } catch {
            }
            try {
              state.stream && state.stream.getTracks().forEach((t) => t.stop());
            } catch {
            }
            state.stream = null;
            state.track = null;
            state.usingWebCodecs = false;
            state.recording = false;
            try {
              hidePreview();
            } catch {
            }
            try {
              clearSelection();
            } catch {
            }
            report({ recording: false });
            try {
              showControlBar(true);
              updateControlBar();
            } catch {
            }
            return;
          }
          if (!streamingReady && state.encodedChunks.length > 0) {
            transferToMainSystem();
          }
        } else {
          if (state.mediaRecorder && state.mediaRecorder.state !== "inactive") {
            state.mediaRecorder.stop();
          }
        }
        if (state.stream) state.stream.getTracks().forEach((t) => t.stop());
      } finally {
        if (!state.usingWebCodecs) {
          state.stream = null;
          state.track = null;
          state.mediaRecorder = null;
          state.encoder = null;
          state.processor = null;
          state.reader = null;
          try {
            state.worker?.terminate();
          } catch {
          }
          if (state.workerBlobUrl) {
            try {
              URL.revokeObjectURL(state.workerBlobUrl);
            } catch {
            }
          }
          state.worker = null;
          state.workerBlobUrl = null;
          state.usingWebCodecs = false;
          state.recording = false;
          state.sinkStarted = false;
          state.chunkCount = 0;
          state.byteCount = 0;
          state.recordingMetadata = null;
          hidePreview();
          report({ recording: false });
        }
      }
    }
    function clearSelection() {
      clearElementSelection();
      clearRegionSelection();
      if (state.selectionBox) {
        state.selectionBox.style.display = "none";
        state.selectionBox.style.width = "0px";
        state.selectionBox.style.height = "0px";
      }
      try {
        hideMask();
      } catch {
      }
      hideSelectionTip();
      try {
        hideControlBar(true);
      } catch {
      }
      report({ selectedDesc: void 0 });
    }
    function downloadVideo() {
      if (!state.videoBlob) {
        console.warn("No video blob available for download");
        return;
      }
      const url = URL.createObjectURL(state.videoBlob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `element-recording-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace(/:/g, "-")}.webm`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      state.videoBlob = null;
      state.recordedChunks = [];
      report({ hasVideo: false, videoUrl: null });
    }
    function showPreview() {
      if (state.preview) return;
      const box = document.createElement("div");
      box.className = "mcp-preview";
      const bar = document.createElement("div");
      bar.className = "bar";
      const title = document.createElement("div");
      title.className = "title";
      title.textContent = "录制预览";
      const btns = document.createElement("div");
      btns.className = "btns";
      const btnMin = document.createElement("div");
      btnMin.className = "btn";
      btnMin.textContent = "—";
      const btnClose = document.createElement("div");
      btnClose.className = "btn";
      btnClose.textContent = "×";
      btns.append(btnMin, btnClose);
      bar.append(title, btns);
      const video = document.createElement("video");
      video.autoplay = true;
      video.muted = true;
      video.playsInline = true;
      video.srcObject = state.stream;
      box.append(bar, video);
      document.documentElement.appendChild(box);
      state.preview = box;
      let dragging = false;
      let dx = 0, dy = 0;
      bar.addEventListener("mousedown", (e) => {
        dragging = true;
        const r = box.getBoundingClientRect();
        dx = e.clientX - r.left;
        dy = e.clientY - r.top;
        e.preventDefault();
      });
      window.addEventListener("mousemove", (e) => {
        if (!dragging) return;
        box.style.left = `${e.clientX - dx}px`;
        box.style.top = `${e.clientY - dy}px`;
        box.style.right = "auto";
        box.style.bottom = "auto";
        box.style.position = "fixed";
      });
      window.addEventListener("mouseup", () => dragging = false);
      btnMin.addEventListener("click", () => {
        box.classList.toggle("min");
      });
      btnClose.addEventListener("click", () => {
        stopCapture();
      });
    }
    function hidePreview() {
      if (state.preview) {
        try {
          state.preview.remove();
        } catch {
        }
        state.preview = null;
      }
    }
    function transferToMainSystem() {
      try {
        console.log("🔄 [Element Recording] Transferring data to main system...", {
          chunks: state.encodedChunks.length,
          metadata: state.recordingMetadata
        });
        const transferData = {
          type: "ELEMENT_RECORDING_COMPLETE",
          data: {
            encodedChunks: state.encodedChunks,
            // 直接使用数组格式的数据
            metadata: state.recordingMetadata,
            source: "element-recording"
          }
        };
        console.log("📤 [Element Recording] Transferring", state.encodedChunks.length, "chunks");
        chrome.runtime.sendMessage(transferData, (response) => {
          if (chrome.runtime.lastError) {
            console.error("❌ [Element Recording] Failed to transfer data:", chrome.runtime.lastError);
            return;
          }
          if (response?.success) {
            console.log("✅ [Element Recording] Data transferred successfully");
            state.encodedChunks = [];
            state.recordingMetadata = null;
            showEditingNotification();
          } else {
            console.error("❌ [Element Recording] Transfer failed:", response?.error);
          }
        });
      } catch (error) {
        console.error("❌ [Element Recording] Transfer error:", error);
      }
    }
    function showEditingNotification() {
      const notification = document.createElement("div");
      notification.className = "mcp-edit-notification";
      notification.innerHTML = `
      <div class="notification-content">
        <div class="notification-icon">🎬</div>
        <div class="notification-text">
          <div class="notification-title">录制完成</div>
          <div class="notification-desc">数据已传递到编辑系统，请在侧边栏查看</div>
        </div>
        <button class="notification-close">×</button>
      </div>
    `;
      notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 16px;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      max-width: 320px;
      animation: slideIn 0.3s ease-out;
    `;
      const style = document.createElement("style");
      style.textContent = `
      @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      .notification-content {
        display: flex;
        align-items: flex-start;
        gap: 12px;
      }
      .notification-icon {
        font-size: 24px;
        flex-shrink: 0;
      }
      .notification-text {
        flex: 1;
      }
      .notification-title {
        font-weight: 600;
        font-size: 14px;
        margin-bottom: 4px;
      }
      .notification-desc {
        font-size: 12px;
        opacity: 0.9;
        line-height: 1.4;
      }
      .notification-close {
        background: none;
        border: none;
        color: white;
        font-size: 18px;
        cursor: pointer;
        padding: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: background-color 0.2s;
      }
      .notification-close:hover {
        background-color: rgba(255,255,255,0.2);
      }
    `;
      document.head.appendChild(style);
      document.body.appendChild(notification);
      const closeBtn = notification.querySelector(".notification-close");
      closeBtn.addEventListener("click", () => {
        notification.remove();
        style.remove();
      });
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove();
          style.remove();
        }
      }, 5e3);
    }
    window.addEventListener("scroll", syncElementContainer, { passive: true });
    window.addEventListener("resize", syncElementContainer, { passive: true });
    function onEscKey(e) {
      if (e.key === "Escape" || e.key === "Esc") {
        const hasSel = state.selecting || !!state.elementContainer || !!state.regionContainer || state.selectionBox && state.selectionBox.style.display !== "none";
        if (!hasSel) return;
        try {
          exitSelection();
        } catch {
        }
        try {
          clearSelection();
        } catch {
        }
        report({ selecting: false, selectedDesc: void 0 });
        e.stopPropagation();
        e.preventDefault();
      }
    }
    window.addEventListener("keydown", onEscKey, true);
    chrome.runtime.onMessage.addListener((msg) => {
      switch (msg.type) {
        case "ENTER_SELECTION":
          state.mode = msg.mode || state.mode;
          enterSelection();
          break;
        case "EXIT_SELECTION":
          exitSelection();
          break;
        case "START_CAPTURE":
          startCapture();
          break;
        case "STOP_CAPTURE":
          stopCapture();
          break;
        case "CLEAR_SELECTION":
          clearSelection();
          break;
        case "DOWNLOAD_VIDEO":
          downloadVideo();
          break;
        case "TOGGLE_PAUSE":
          if (state.recording) setPaused(!state.paused);
          break;
        case "STATE_UPDATE":
          break;
        case "STREAMING_READY":
          streamingReady = true;
          console.log("[Stream][Content] STREAMING_READY received", { startTime: state.recordingMetadata?.startTime });
          break;
      }
    });
  })();
})();
