import"./Bzak7iHL.js";import{p as h,b,d as v,e as $,a as C,g as A,aH as g,aP as y,J as s,a5 as d}from"./CXmNGZIW.js";import{s as S}from"./CCVuujmc.js";import{s as F,r as w}from"./DbcSoKIt.js";import{I as D}from"./E9i7adAJ.js";function R(i,e){h(e,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let t=w(e,["$$slots","$$events","$$legacy"]);const r=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"m9 12 2 2 4-4"}]];D(i,F({name:"circle-check"},()=>t,{get iconNode(){return r},children:(o,l)=>{var n=b(),u=v(n);S(u,()=>e.children??$),C(o,n)},$$slots:{default:!0}})),A()}function W(i,e){h(e,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let t=w(e,["$$slots","$$events","$$legacy"]);const r=[["path",{d:"M12 6v6l4 2"}],["circle",{cx:"12",cy:"12",r:"10"}]];D(i,F({name:"clock"},()=>t,{get iconNode(){return r},children:(o,l)=>{var n=b(),u=v(n);S(u,()=>e.children??$),C(o,n)},$$slots:{default:!0}})),A()}const m={includeAudio:!1,videoQuality:"medium",maxDuration:3600,preferredEngine:"mediarecorder",codec:"vp9",framerate:30,useWorkers:!0},p={isRecording:!1,duration:0,status:"idle",error:null,videoBlob:null,startTime:null,engine:"mediarecorder",progress:{encodedChunks:0,processedFrames:0,encodedFrames:0,fileSize:0,fps:0,bitrate:0,cpuUsage:0}};function V(){let i=g(y({...p})),e=g(y({...m}));return{get state(){return s(i)},get options(){return s(e)},get isIdle(){return s(i).status==="idle"},get isRecording(){return s(i).status==="recording"},get isProcessing(){return s(i).status==="requesting"||s(i).status==="stopping"},get hasError(){return s(i).status==="error"},get hasVideo(){return s(i).videoBlob!==null},get formattedDuration(){const t=Math.floor(s(i).duration/60),r=s(i).duration%60;return`${t.toString().padStart(2,"0")}:${r.toString().padStart(2,"0")}`},get formattedFileSize(){const t=s(i).progress.fileSize;return t<1024?`${t} B`:t<1024*1024?`${(t/1024).toFixed(1)} KB`:`${(t/1024/1024).toFixed(1)} MB`},get formattedBitrate(){const t=s(i).progress.bitrate;return t<1e3?`${t} bps`:t<1e6?`${(t/1e3).toFixed(1)} Kbps`:`${(t/1e6).toFixed(1)} Mbps`},updateStatus(t,r){s(i).status=t,s(i).error=r||null,t==="recording"&&!s(i).startTime?(s(i).startTime=Date.now(),s(i).isRecording=!0):(t==="completed"||t==="error")&&(s(i).isRecording=!1)},updateProgress(t){s(i).progress={...t}},updateDuration(t){s(i).duration=t},setVideoBlob(t){s(i).videoBlob=t},setEngine(t){s(i).engine=t},updateOptions(t){d(e,{...s(e),...t},!0)},setVideoQuality(t){s(e).videoQuality=t},setIncludeAudio(t){s(e).includeAudio=t},setPreferredEngine(t){s(e).preferredEngine=t},setCodec(t){s(e).codec=t},reset(){d(i,{...p},!0)},resetOptions(){d(e,{...m},!0)},resetAll(){d(i,{...p},!0),d(e,{...m},!0)},getSnapshot(){return{state:{...s(i)},options:{...s(e)}}},restoreFromSnapshot(t){d(i,{...t.state},!0),d(e,{...t.options},!0)},exportData(){return{timestamp:new Date().toISOString(),state:{...s(i)},options:{...s(e)},summary:{duration:this.formattedDuration,fileSize:this.formattedFileSize,bitrate:this.formattedBitrate,fps:s(i).progress.fps,engine:s(i).engine,status:s(i).status}}}}}const O=V();class f{static validateChunk(e){const t={isValid:!0,errors:[],warnings:[],format:"unknown",size:0};return e?e.data?(typeof e.timestamp!="number"&&(t.errors.push("Chunk.timestamp is not a number"),t.isValid=!1),(!e.type||e.type!=="key"&&e.type!=="delta")&&(t.errors.push('Chunk.type must be "key" or "delta"'),t.isValid=!1),e.data instanceof Uint8Array?(t.format="uint8array",t.size=e.data.length):e.data instanceof ArrayBuffer?(t.format="arraybuffer",t.size=e.data.byteLength):Array.isArray(e.data)?(t.format="array",t.size=e.data.length,e.data.every(r=>typeof r=="number"&&r>=0&&r<=255)||t.warnings.push("Array contains invalid byte values")):e.data&&typeof e.data=="object"&&"buffer"in e.data?(t.format="typed-array",t.size=e.data.byteLength||0):(t.errors.push(`Unknown data format: ${typeof e.data}`),t.isValid=!1),(typeof e.codedWidth!="number"||e.codedWidth<=0)&&t.warnings.push("Invalid or missing codedWidth"),(typeof e.codedHeight!="number"||e.codedHeight<=0)&&t.warnings.push("Invalid or missing codedHeight"),t):(t.errors.push("Chunk.data is missing"),t.isValid=!1,t):(t.errors.push("Chunk is null or undefined"),t.isValid=!1,t)}static validateChunks(e){if(!Array.isArray(e))return{isValid:!1,totalErrors:1,totalWarnings:0,chunkResults:[],summary:{totalChunks:0,validChunks:0,totalSize:0,formats:{}}};const t=e.map(a=>this.validateChunk(a)),r=t.filter(a=>a.isValid).length,o=t.reduce((a,c)=>a+c.errors.length,0),l=t.reduce((a,c)=>a+c.warnings.length,0),n=t.reduce((a,c)=>a+c.size,0),u={};return t.forEach(a=>{u[a.format]=(u[a.format]||0)+1}),{isValid:o===0,totalErrors:o,totalWarnings:l,chunkResults:t,summary:{totalChunks:e.length,validChunks:r,totalSize:n,formats:u}}}static convertToUint8Array(e){try{if(e instanceof Uint8Array)return e;if(e instanceof ArrayBuffer)return new Uint8Array(e);if(e&&typeof e=="object"&&"buffer"in e)return new Uint8Array(e.buffer,e.byteOffset,e.byteLength);if(Array.isArray(e))return e.every(t=>typeof t=="number"&&t>=0&&t<=255)?new Uint8Array(e):(console.warn("⚠️ [DataFormatValidator] Array contains invalid byte values"),null);if(e&&typeof e=="object"){const t=Object.values(e);if(t.length>0&&t.every(r=>typeof r=="number"&&r>=0&&r<=255))return new Uint8Array(t);if(e.length!==void 0&&typeof e.length=="number"&&e.length>0){const r=[];for(let o=0;o<e.length;o++)e[o]!==void 0&&typeof e[o]=="number"&&r.push(e[o]);if(r.length>0)return new Uint8Array(r)}if(e.data)return this.convertToUint8Array(e.data);if(e.buffer&&e.byteOffset!==void 0&&e.byteLength!==void 0){const r=this.convertToUint8Array(e.buffer);if(r)return r.slice(e.byteOffset,e.byteOffset+e.byteLength)}}return console.warn("⚠️ [DataFormatValidator] Unknown data format:",typeof e),null}catch(t){return console.error("❌ [DataFormatValidator] Conversion error:",t),null}}static generateDebugReport(e,t="unknown"){const r=this.validateChunks(e);let o=`
📊 Data Format Debug Report - Source: ${t}
`;return o+=`${"=".repeat(50)}
`,o+=`Total Chunks: ${r.summary.totalChunks}
`,o+=`Valid Chunks: ${r.summary.validChunks}
`,o+=`Total Size: ${(r.summary.totalSize/1024/1024).toFixed(2)} MB
`,o+=`Errors: ${r.totalErrors}
`,o+=`Warnings: ${r.totalWarnings}
`,o+=`Overall Valid: ${r.isValid?"✅":"❌"}

`,o+=`Format Distribution:
`,Object.entries(r.summary.formats).forEach(([l,n])=>{o+=`  ${l}: ${n} chunks
`}),r.totalErrors>0&&(o+=`
❌ Errors:
`,r.chunkResults.forEach((l,n)=>{l.errors.length>0&&(o+=`  Chunk ${n}: ${l.errors.join(", ")}
`)})),r.totalWarnings>0&&(o+=`
⚠️ Warnings:
`,r.chunkResults.forEach((l,n)=>{l.warnings.length>0&&(o+=`  Chunk ${n}: ${l.warnings.join(", ")}
`)})),o}static fixChunkFormat(e){if(!e||!e.data)return null;const t=this.convertToUint8Array(e.data);return t?{data:t,timestamp:e.timestamp||0,type:e.type||"delta",size:e.size||t.length,codedWidth:e.codedWidth||1920,codedHeight:e.codedHeight||1080,codec:e.codec||"vp8"}:(console.error("❌ [DataFormatValidator] Cannot convert chunk data"),null)}static fixChunksFormat(e){return Array.isArray(e)?e.map(t=>this.fixChunkFormat(t)).filter(t=>t!==null):[]}}f.validateChunks.bind(f);f.generateDebugReport.bind(f);f.fixChunksFormat.bind(f);export{R as C,f as D,W as a,O as r};
