import"./Bzak7iHL.js";import{i as o,j as p,t as h,aY as W,k as A,E as T,m as I,aZ as z,am as F,a_ as j,I as D,l as L,D as w,C as y,a3 as M,u as P,F as R,Y,p as B,a$ as G,a as E,g as J,c as O,s as V,e as Z,r as q,b as H,d as K,J as g,aI as Q,aL as U}from"./CXmNGZIW.js";import{s as X}from"./CCVuujmc.js";import{e as $,i as ee}from"./CClpJWUu.js";import{f as N}from"./CnU3SatZ.js";import{p as d,r as te}from"./DbcSoKIt.js";function ae(u,t,v,i,m,k){let _=o;o&&p();var n,r,e=null;o&&h.nodeType===W&&(e=h,p());var c=o?h:u,a;A(()=>{const s=t()||null;var f=z;s!==n&&(a&&(s===null?P(a,()=>{a=null,r=null}):s===r?R(a):Y(a)),s&&s!==r&&(a=I(()=>{if(e=o?e:document.createElementNS(f,s),F(e,e),i){o&&j(s)&&e.append(document.createComment(""));var l=o?D(e):e.appendChild(L());o&&(l===null?w(!1):y(l)),i(e,l)}M.nodes_end=e,c.before(e)})),n=s,n&&(r=n))},T),_&&(w(!0),y(c))}/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * ---
 * 
 * The MIT License (MIT) (for portions derived from Feather)
 * 
 * Copyright (c) 2013-2023 Cole Bemis
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 */const se={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var re=G("<svg><!><!></svg>");function ue(u,t){B(t,!0);const v=d(t,"color",3,"currentColor"),i=d(t,"size",3,24),m=d(t,"strokeWidth",3,2),k=d(t,"absoluteStrokeWidth",3,!1),_=d(t,"iconNode",19,()=>[]),n=te(t,["$$slots","$$events","$$legacy","name","color","size","strokeWidth","absoluteStrokeWidth","iconNode","children"]);var r=re();N(r,a=>({...se,...n,width:i(),height:i(),stroke:v(),"stroke-width":a,class:["lucide-icon lucide",t.name&&`lucide-${t.name}`,t.class]}),[()=>k()?Number(m())*24/Number(i()):m()]);var e=O(r);$(e,17,_,ee,(a,s)=>{var f=Q(()=>U(g(s),2));let l=()=>g(f)[0],x=()=>g(f)[1];var b=H(),C=K(b);ae(C,l,!0,(S,oe)=>{N(S,()=>({...x()}))}),E(a,b)});var c=V(e);X(c,()=>t.children??Z),q(r),E(u,r),J()}export{ue as I};
