import"../chunks/Bzak7iHL.js";import{o as ve}from"../chunks/Bqf1CTu2.js";import{p as D,b as O,d as C,e as X,a as b,g as k,aG as ke,f as y,h as Fe,s as m,c as p,J as e,aH as M,a4 as N,a5 as s,$ as Ge,n as L,r as d,aI as J}from"../chunks/CXmNGZIW.js";import{s as I}from"../chunks/7FdNRQaY.js";import{i as S}from"../chunks/Co44HDAx.js";import{e as Ue,i as qe}from"../chunks/CClpJWUu.js";import{c as ge}from"../chunks/ZJBcVnyf.js";import{a as V,s as He}from"../chunks/CnU3SatZ.js";import{M as me}from"../chunks/DQTu8ve7.js";import{H as We}from"../chunks/DNATbktP.js";import{C as je}from"../chunks/DK2OxeaC.js";import{M as Be}from"../chunks/_eO3vVtN.js";import{s as Y}from"../chunks/CCVuujmc.js";import{s as K,r as Z}from"../chunks/DbcSoKIt.js";import{I as ee}from"../chunks/E9i7adAJ.js";import{F as Qe}from"../chunks/IcZhpbTg.js";import{L as be,P as ze}from"../chunks/DrwYz3Rm.js";import{S as Je,P as _e}from"../chunks/Csf-45r7.js";function Ve(h,f){D(f,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let o=Z(f,["$$slots","$$events","$$legacy"]);const l=[["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"}],["path",{d:"M10 4v4"}],["path",{d:"M2 8h20"}],["path",{d:"M6 4v4"}]];ee(h,K({name:"app-window"},()=>o,{get iconNode(){return l},children:(i,c)=>{var v=O(),w=C(v);Y(w,()=>f.children??X),b(i,v)},$$slots:{default:!0}})),k()}function Xe(h,f){D(f,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let o=Z(f,["$$slots","$$events","$$legacy"]);const l=[["path",{d:"M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z"}],["circle",{cx:"12",cy:"13",r:"3"}]];ee(h,K({name:"camera"},()=>o,{get iconNode(){return l},children:(i,c)=>{var v=O(),w=C(v);Y(w,()=>f.children??X),b(i,v)},$$slots:{default:!0}})),k()}function Ye(h,f){D(f,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let o=Z(f,["$$slots","$$events","$$legacy"]);const l=[["path",{d:"M13 3H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3"}],["path",{d:"M8 21h8"}],["path",{d:"M12 17v4"}],["path",{d:"m17 8 5-5"}],["path",{d:"M17 3h5v5"}]];ee(h,K({name:"screen-share"},()=>o,{get iconNode(){return l},children:(i,c)=>{var v=O(),w=C(v);Y(w,()=>f.children??X),b(i,v)},$$slots:{default:!0}})),k()}async function Ke(h,f,o,l,i){try{if(e(f)==="element"||e(f)==="area"){let c=e(o);try{if(c==null){const v=await chrome.tabs.query({active:!0,currentWindow:!0});c=v&&v[0]&&typeof v[0].id=="number"?v[0].id:null}}catch{}c!=null?await chrome.runtime.sendMessage({type:"STOP_CAPTURE",tabId:c}):console.warn("Failed to get active tab, cannot stop recording")}else await chrome.runtime.sendMessage({type:"REQUEST_STOP_RECORDING"})}catch(c){console.warn("Failed to send stop recording message",c)}s(l,!1),s(i,!1)}var Ze=()=>window.open("/drive.html","_blank"),et=(h,f,o)=>f(e(o).id),tt=y('<div class="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full border-2 border-white"></div>'),rt=y('<div class="absolute -top-1 -right-1 bg-orange-500 text-white text-xs px-1.5 py-0.5 rounded-full font-medium">Coming Soon</div>'),at=y("<button><!> <!> <!> <span> </span></button>"),ot=y('<div class="px-4 py-3 bg-red-50 border-t border-red-100"><div class="flex items-center justify-between"><div class="flex items-center gap-2"><div class="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div> <span class="text-sm font-medium text-red-700"> </span></div> <div class="text-xs text-red-600"> </div></div></div>'),nt=y('<button class="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"><!> <span>Stop Recording</span></button>'),it=y('<p class="font-medium mb-1">Recording Tips:</p> <p>Selected <strong> </strong> mode, click Start Recording to begin.</p>',1),st=y('<p class="font-medium">Recording is paused, click Resume Recording to continue.</p>'),ct=y('<p class="font-medium">Recording in progress, click Pause to pause recording.</p>'),dt=y('<div class="w-[320px] bg-white font-sans"><div class="px-4 py-3 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50"><div class="flex items-center justify-between"><div><h1 class="text-lg font-semibold text-gray-800 flex items-center gap-2"><!> Screen Recorder</h1> <p class="text-sm text-gray-600 mt-1">Select recording mode and start recording</p></div> <button class="p-2 rounded-lg border border-gray-300 hover:border-blue-400 hover:bg-white/70 hover:shadow-sm transition-all duration-200 group" title="Open recording file manager"><!></button></div></div> <div class="p-4"><h2 class="text-sm font-medium text-gray-700 mb-3">Recording Mode</h2> <div class="grid grid-cols-3 gap-2"></div></div> <!> <div class="p-4 border-t border-gray-200 bg-gray-50"><div class="space-y-2"><button><div class="flex items-center justify-center w-5 h-5"><!></div> <span class="font-semibold"> </span></button> <!></div> <div class="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200"><div class="flex items-start gap-2"><!> <div class="text-xs text-blue-700"><!></div></div></div></div></div>');function At(h,f){D(f,!0);let o=M(!1),l=M(!1),i=M("tab"),c=M(!1),v=M(null),w=M(void 0),E=M(null);function T(r){const t=(r==="element"||r==="area")&&e(v)===!1,a=e(o)&&e(i)!==r;return t||a||r==="camera"}ve(async()=>{try{const r=await chrome.runtime.sendMessage({type:"REQUEST_RECORDING_STATE"});s(o,!!r?.state?.isRecording),s(l,!!r?.state?.isPaused)}catch(r){console.warn("Failed to initialize recording state",r)}try{const r=await chrome.tabs.query({active:!0,currentWindow:!0});if(s(E,r&&r[0]&&typeof r[0].id=="number"?r[0].id:null,!0),e(E)!=null){const t=await chrome.runtime.sendMessage({type:"GET_STATE",tabId:e(E)}),a=t?.state?.capabilities;a&&(s(v,!!a.contentScriptAvailable),s(w,a.reason,!0));const n=t?.state?.uiSelectedMode,u=t?.state?.mode;if(n==="element"||n==="area"||n==="camera"||n==="tab"||n==="window"||n==="screen"?s(i,n,!0):(u==="region"||u==="element")&&s(i,u==="region"?"area":"element",!0),T(e(i))){s(i,"tab");try{await chrome.runtime.sendMessage({type:"SET_SELECTED_MODE",uiMode:"tab",tabId:e(E)})}catch{}}!e(o)&&typeof t?.state?.recording=="boolean"&&t.state.recording&&s(o,!0)}}catch{}}),ve(()=>{const r=t=>{try{if(t?.type==="STREAM_META"&&t?.meta&&typeof t.meta.paused=="boolean"&&(console.log("[stop-share] popup: STREAM_META",t.meta),s(l,!!t.meta.paused)),t?.type==="STREAM_START"&&(console.log("[stop-share] popup: STREAM_START",t),s(o,!0),s(l,!1),s(c,!1)),(t?.type==="STREAM_END"||t?.type==="STREAM_ERROR"||t?.type==="RECORDING_COMPLETE"||t?.type==="OPFS_RECORDING_READY")&&(console.log("[stop-share] popup: received",t?.type),s(o,!1),s(l,!1),s(c,!1)),t?.type==="STATE_UPDATE"&&t?.state){console.log("[stop-share] popup: STATE_UPDATE",t.state),typeof t.state.recording=="boolean"&&(s(o,!!t.state.recording),e(o)||s(l,!1)),t.state.capabilities&&(s(v,!!t.state.capabilities.contentScriptAvailable),s(w,t.state.capabilities.reason,!0));const a=t.state.uiSelectedMode,n=t.state.mode;a==="element"||a==="area"||a==="camera"||a==="tab"||a==="window"||a==="screen"?s(i,a,!0):(n==="region"||n==="element")&&s(i,n==="region"?"area":"element",!0)}}catch{}};return chrome.runtime.onMessage.addListener(r),()=>chrome.runtime.onMessage.removeListener(r)});const F=[{id:"area",name:"Area",icon:Be,description:"Select screen area to record"},{id:"element",name:"Element",icon:me,description:"Select page element to record"},{id:"camera",name:"Camera",icon:Xe,description:"Record camera feed"},{id:"tab",name:"Tab",icon:Qe,description:"Record current tab"},{id:"window",name:"Window",icon:Ve,description:"Record entire window"},{id:"screen",name:"Screen",icon:Ye,description:"Record entire screen"}];async function he(r){if(!T(r)&&!e(o)){const t=e(i);s(i,r,!0);let a=e(E);try{if(a==null){const u=await chrome.tabs.query({active:!0,currentWindow:!0});a=u&&u[0]&&typeof u[0].id=="number"?u[0].id:null}}catch{}try{await chrome.runtime.sendMessage({type:"SET_SELECTED_MODE",uiMode:e(i),tabId:a})}catch{}const n=u=>u==="element"||u==="area";if(n(t)&&!n(r)&&a!=null)try{await chrome.runtime.sendMessage({type:"CLEAR_SELECTION",tabId:a}),await chrome.runtime.sendMessage({type:"EXIT_SELECTION",tabId:a})}catch{}if(n(r)&&a!=null){try{await chrome.runtime.sendMessage({type:"CLEAR_SELECTION",tabId:a})}catch{}const u=r==="area"?"region":"element";await chrome.runtime.sendMessage({type:"SET_MODE",mode:u,tabId:a}).catch(()=>{}),await chrome.runtime.sendMessage({type:"ENTER_SELECTION",tabId:a}).catch(()=>{})}}}async function ye(){if(!e(c)){s(c,!0);try{if(e(i)==="element"||e(i)==="area"){let r=e(E);try{if(r==null){const t=await chrome.tabs.query({active:!0,currentWindow:!0});r=t&&t[0]&&typeof t[0].id=="number"?t[0].id:null}}catch{}if(r!=null)await chrome.runtime.sendMessage({type:"START_CAPTURE",tabId:r});else throw new Error("Failed to get active tab, cannot start recording")}else{const r=["tab","window","screen"].includes(e(i))?e(i):"screen";await chrome.runtime.sendMessage({type:"REQUEST_START_RECORDING",payload:{options:{mode:r,video:!0,audio:!1}}})}}catch(r){console.error("Failed to start recording:",r)}finally{s(c,!1)}}}async function we(){if(!(!e(o)||e(c))){s(c,!0);try{const r={type:"REQUEST_TOGGLE_PAUSE"};if(e(i)==="element"||e(i)==="area"){let a=e(E);try{if(a==null){const n=await chrome.tabs.query({active:!0,currentWindow:!0});a=n&&n[0]&&typeof n[0].id=="number"?n[0].id:null}}catch{}a!=null&&(r.tabId=a)}const t=await chrome.runtime.sendMessage(r);t&&typeof t.paused=="boolean"&&s(l,t.paused,!0)}catch(r){console.warn("Failed to toggle pause",r)}finally{s(c,!1)}}}function Ee(){return e(c)?"Preparing...":e(o)?e(l)?"Resume Recording":"Pause Recording":"Start Recording"}function xe(){return e(c)?be:e(o)?e(l)?_e:ze:_e}var G=dt();Fe(r=>{Ge.title="Screen Recording Extension"});var U=p(G),te=p(U),q=p(te),re=p(q),Re=p(re);me(Re,{class:"w-5 h-5 text-blue-600"}),L(),d(re),L(2),d(q);var H=m(q,2);H.__click=[Ze];var Me=p(H);We(Me,{class:"w-5 h-5 text-gray-600 group-hover:text-blue-600 transition-colors duration-200"}),d(H),d(te),d(U);var W=m(U,2),ae=m(p(W),2);Ue(ae,21,()=>F,qe,(r,t)=>{const a=J(()=>e(t).icon);var n=at();let u;n.__click=[et,he,t];var g=p(n);{var x=_=>{var R=tt();b(_,R)};S(g,_=>{e(i)===e(t).id&&_(x)})}var $=m(g,2);{var P=_=>{var R=rt();b(_,R)};S($,_=>{e(t).id==="camera"&&_(P)})}var pe=m($,2);{let _=J(()=>`w-6 h-6 mb-2 transition-colors duration-200 ${e(i)===e(t).id?"text-blue-600":"text-gray-600"}`);ge(pe,()=>e(a),(R,z)=>{z(R,{get class(){return e(_)}})})}var Q=m(pe,2);let fe;var De=p(Q,!0);d(Q),d(n),N((_,R,z)=>{u=V(n,1,"group relative flex flex-col items-center p-3 rounded-lg border-2 transition-all duration-200 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1",null,u,_),n.disabled=R,He(n,"title",e(t).id==="camera"?"Coming Soon":(e(t).id==="element"||e(t).id==="area")&&e(v)===!1?"This page is restricted, cannot use this mode":e(t).description),fe=V(Q,1,"text-xs font-medium transition-colors duration-200",null,fe,z),I(De,e(t).name)},[()=>({"border-blue-500":e(i)===e(t).id,"bg-blue-50":e(i)===e(t).id,"border-gray-200":e(i)!==e(t).id,"bg-white":e(i)!==e(t).id,"hover:border-gray-300":e(i)!==e(t).id&&!T(e(t).id),"opacity-50":T(e(t).id),"cursor-not-allowed":T(e(t).id)}),()=>T(e(t).id),()=>({"text-blue-700":e(i)===e(t).id,"text-gray-700":e(i)!==e(t).id})]),b(r,n)}),d(ae),d(W);var oe=m(W,2);{var Se=r=>{var t=ot(),a=p(t),n=p(a),u=m(p(n),2),g=p(u,!0);d(u),d(n);var x=m(n,2),$=p(x,!0);d(x),d(a),d(t),N(P=>{I(g,e(l)?"Recording Paused":"Recording"),I($,P)},[()=>F.find(P=>P.id===e(i))?.name]),b(r,t)};S(oe,r=>{e(o)&&r(Se)})}var ne=m(oe,2),j=p(ne),A=p(j);let ie;A.__click=function(...r){(e(o)?we:ye)?.apply(this,r)};var B=p(A),Te=p(B);{var Ae=r=>{be(r,{class:"w-5 h-5 animate-spin"})},Ce=r=>{const t=J(xe);var a=O(),n=C(a);ge(n,()=>e(t),(u,g)=>{g(u,{class:"w-5 h-5"})}),b(r,a)};S(Te,r=>{e(c)?r(Ae):r(Ce,!1)})}d(B);var se=m(B,2),Pe=p(se,!0);d(se),d(A);var Ie=m(A,2);{var Oe=r=>{var t=nt();t.__click=[Ke,i,E,o,l];var a=p(t);Je(a,{class:"w-4 h-4"}),L(2),d(t),b(r,t)};S(Ie,r=>{e(o)&&r(Oe)})}d(j);var ce=m(j,2),de=p(ce),le=p(de);je(le,{class:"w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0"});var ue=m(le,2),$e=p(ue);{var Ne=r=>{var t=it(),a=m(C(t),2),n=m(p(a)),u=p(n,!0);d(n),L(),d(a),N(g=>I(u,g),[()=>F.find(g=>g.id===e(i))?.name]),b(r,t)},Le=r=>{var t=O(),a=C(t);{var n=g=>{var x=st();b(g,x)},u=g=>{var x=ct();b(g,x)};S(a,g=>{e(l)?g(n):g(u,!1)},!0)}b(r,t)};S($e,r=>{e(o)?r(Le,!1):r(Ne)})}d(ue),d(de),d(ce),d(ne),d(G),N((r,t)=>{ie=V(A,1,"w-full flex items-center justify-center gap-3 px-4 py-3 rounded-lg font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed",null,ie,r),A.disabled=e(c),I(Pe,t)},[()=>({"bg-gradient-to-r":!e(o),"from-blue-500":!e(o),"to-blue-600":!e(o),"text-white":!e(o),"hover:from-blue-600":!e(o)&&!e(c),"hover:to-blue-700":!e(o)&&!e(c),"focus:ring-blue-500":!e(o),"bg-orange-500":e(o)&&!e(l),"hover:bg-orange-600":e(o)&&!e(l)&&!e(c),"focus:ring-orange-500":e(o)&&!e(l),"bg-green-500":e(o)&&e(l),"hover:bg-green-600":e(o)&&e(l)&&!e(c),"focus:ring-green-500":e(o)&&e(l)}),Ee]),b(h,G),k()}ke(["click"]);export{At as component};
