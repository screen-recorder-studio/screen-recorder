var Ut=Object.defineProperty;var jt=(w,t,r)=>t in w?Ut(w,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):w[t]=r;var Pt=(w,t,r)=>jt(w,typeof t!="symbol"?t+"":t,r);import"../chunks/Bzak7iHL.js";import{o as Wt,a as Ht}from"../chunks/Bqf1CTu2.js";import{p as ne,b as $e,d as re,e as Re,a as I,g as se,aG as st,aH as X,aP as bt,a7 as tt,J as e,aI as ge,f as Z,a4 as ze,a5 as m,c as n,s as v,n as Fe,r as i,h as qt,$ as Kt}from"../chunks/CXmNGZIW.js";import{b as Tt}from"../chunks/DJUrUaJP.js";import{D as vt,C as Zt,a as Jt,r as Ft}from"../chunks/DU0p2IVN.js";import{s as Q}from"../chunks/7FdNRQaY.js";import{i as Le}from"../chunks/Co44HDAx.js";import{a as Ke,b as nt,r as Ze,s as ft,g as $t,h as Qt}from"../chunks/CnU3SatZ.js";import{s as Ee,r as We,p as Se}from"../chunks/DbcSoKIt.js";import{b as Ge,i as ht}from"../chunks/-_mRqwun.js";import{M as Ct}from"../chunks/DQTu8ve7.js";import{L as St,P as ea}from"../chunks/DrwYz3Rm.js";import{P as ta,S as Bt}from"../chunks/Csf-45r7.js";import{s as Te}from"../chunks/CCVuujmc.js";import{I as Ce}from"../chunks/E9i7adAJ.js";import{I as aa}from"../chunks/C-fuRH-J.js";import{T as ra}from"../chunks/COMA96Ua.js";import{P as oa,B as ia}from"../chunks/BtGRvS7W.js";import{e as xt,i as yt}from"../chunks/CClpJWUu.js";import{c as _t}from"../chunks/ZJBcVnyf.js";import{b as ut}from"../chunks/BPCVdJnz.js";import{H as na}from"../chunks/DNATbktP.js";function sa(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["path",{d:"M12 7v14"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"}]];Ce(w,Ee({name:"book-open"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function wt(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["circle",{cx:"12",cy:"12",r:"10"}]];Ce(w,Ee({name:"circle"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function la(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["path",{d:"M12 15V3"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}],["path",{d:"m7 10 5 5 5-5"}]];Ce(w,Ee({name:"download"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function It(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"}],["circle",{cx:"12",cy:"12",r:"3"}]];Ce(w,Ee({name:"eye"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function da(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2"}],["path",{d:"M7 3v18"}],["path",{d:"M3 7.5h4"}],["path",{d:"M3 12h18"}],["path",{d:"M3 16.5h4"}],["path",{d:"M17 3v18"}],["path",{d:"M17 7.5h4"}],["path",{d:"M17 16.5h4"}]];Ce(w,Ee({name:"film"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function Et(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["circle",{cx:"12",cy:"12",r:"3"}],["path",{d:"M3 7V5a2 2 0 0 1 2-2h2"}],["path",{d:"M17 3h2a2 2 0 0 1 2 2v2"}],["path",{d:"M21 17v2a2 2 0 0 1-2 2h-2"}],["path",{d:"M7 21H5a2 2 0 0 1-2-2v-2"}]];Ce(w,Ee({name:"focus"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function ca(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["path",{d:"M15 3h6v6"}],["path",{d:"m21 3-7 7"}],["path",{d:"m3 21 7-7"}],["path",{d:"M9 21H3v-6"}]];Ce(w,Ee({name:"maximize-2"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function pa(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["path",{d:"m14 10 7-7"}],["path",{d:"M20 10h-6V4"}],["path",{d:"m3 21 7-7"}],["path",{d:"M4 14h6v6"}]];Ce(w,Ee({name:"minimize-2"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function ua(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"}]];Ce(w,Ee({name:"moon"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function mt(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["path",{d:"M12 2v20"}],["path",{d:"m15 19-3 3-3-3"}],["path",{d:"m19 9 3 3-3 3"}],["path",{d:"M2 12h20"}],["path",{d:"m5 9-3 3 3 3"}],["path",{d:"m9 5 3-3 3 3"}]];Ce(w,Ee({name:"move"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function Vt(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["line",{x1:"21",x2:"14",y1:"4",y2:"4"}],["line",{x1:"10",x2:"3",y1:"4",y2:"4"}],["line",{x1:"21",x2:"12",y1:"12",y2:"12"}],["line",{x1:"8",x2:"3",y1:"12",y2:"12"}],["line",{x1:"21",x2:"16",y1:"20",y2:"20"}],["line",{x1:"12",x2:"3",y1:"20",y2:"20"}],["line",{x1:"14",x2:"14",y1:"2",y2:"6"}],["line",{x1:"8",x2:"8",y1:"10",y2:"14"}],["line",{x1:"16",x2:"16",y1:"18",y2:"22"}]];Ce(w,Ee({name:"sliders-horizontal"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function ga(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2"}],["path",{d:"M12 18h.01"}]];Ce(w,Ee({name:"smartphone"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function ma(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z"}],["path",{d:"M20 2v4"}],["path",{d:"M22 4h-4"}],["circle",{cx:"4",cy:"20",r:"2"}]];Ce(w,Ee({name:"sparkles"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function fa(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["circle",{cx:"12",cy:"12",r:"4"}],["path",{d:"M12 2v2"}],["path",{d:"M12 20v2"}],["path",{d:"m4.93 4.93 1.41 1.41"}],["path",{d:"m17.66 17.66 1.41 1.41"}],["path",{d:"M2 12h2"}],["path",{d:"M20 12h2"}],["path",{d:"m6.34 17.66-1.41 1.41"}],["path",{d:"m19.07 4.93-1.41 1.41"}]];Ce(w,Ee({name:"sun"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function zt(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2"}]];Ce(w,Ee({name:"video"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}function va(w,t){ne(t,!0);/**
 * @license @lucide/svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let r=We(t,["$$slots","$$events","$$legacy"]);const f=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"}]];Ce(w,Ee({name:"zap"},()=>r,{get iconNode(){return f},children:(g,s)=>{var c=$e(),l=re(c);Te(l,()=>t.children??Re),I(g,c)},$$slots:{default:!0}})),se()}var ha=Z('<div class="absolute inset-0 flex flex-col items-center justify-center bg-black/50 text-white"><!> <span class="text-sm">Processing video...</span></div>'),wa=(w,t)=>t(parseInt(w.target.value)),ba=Z('<div class="flex-shrink-0 p-3 bg-gray-800"><input type="range" class="w-full h-1 bg-gray-600 rounded-sm outline-none cursor-pointer timeline-slider svelte-1w9wlfj" min="0"/> <div class="flex justify-between items-center mt-1"><div class="flex items-center gap-2 text-white text-sm"><button class="flex items-center justify-center w-8 h-8 border border-gray-600 text-white rounded cursor-pointer transition-all duration-200 hover:bg-gray-700 hover:border-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"><!></button> <span class="font-mono text-sm text-gray-300 ml-2"> </span></div> <div class="flex items-center gap-4 text-xs text-gray-400"><span> </span> <span> </span> <span> </span> <span> </span></div></div></div>'),xa=Z('<div><div class="flex-shrink-0 flex justify-between items-center p-3 border-b border-gray-700"><div class="flex items-center gap-2"><!> <span class="text-sm font-semibold text-gray-100">Video Preview</span></div> <span class="text-xs font-medium text-purple-400 bg-purple-500/10 px-2 py-1 rounded border border-purple-500/20"> </span></div> <div class="flex-1 flex items-center justify-center p-4 min-h-0"><div class="relative bg-black flex items-center justify-center rounded overflow-hidden"><canvas></canvas> <!></div></div> <!></div>');function ya(w,t){ne(t,!0);let r=Se(t,"encodedChunks",23,()=>[]),f=Se(t,"isRecordingComplete",3,!1),g=Se(t,"displayWidth",3,640),s=Se(t,"displayHeight",3,360),c=Se(t,"showControls",3,!0),l=Se(t,"showTimeline",3,!0),a=Se(t,"durationMs",3,0),R=Se(t,"windowStartMs",3,0),E=Se(t,"windowEndMs",3,0),b=Se(t,"totalFramesAll",3,0),h=Se(t,"windowStartIndex",3,0),A=Se(t,"className",3,""),C=null,M=null,le=!1,H=null,O=null,ce=0,oe=0,pe=null;const u=ge(()=>Ge.config);let B,W=null,U=X(!1),L=X(!1),me=X(!1),F=null,ue=X(0),V=X(0),G=X(0),Y=X(0),z=30,D=X(!1),de=X(!1),Be=X(0),Xe=X(bt(h()));const Ne=ge(()=>b()>0&&z>0?b()/z:a()>0?a()/1e3:e(Y)),fe=ge(()=>{let o;return b()>0&&z>0?(o=Math.max(1,Math.floor(b()/z*1e3)),console.log("[progress] timelineMaxMs: using global frames:",{totalFramesAll:b(),frameRate:z,result:o})):a()>0?(o=Math.max(1,Math.floor(a())),console.log("[progress] timelineMaxMs: using durationMs:",{durationMs:a(),result:o})):e(V)>0&&z>0?(o=Math.max(1,Math.floor(e(V)/z*1e3)),console.log("[progress] timelineMaxMs: using window frames:",{totalFrames:e(V),frameRate:z,result:o})):E()>R()?(o=Math.max(1,E()-R()),console.log("[progress] timelineMaxMs: using window duration:",{windowStartMs:R(),windowEndMs:E(),result:o})):(o=1e3,console.log("[progress] timelineMaxMs: using fallback:",{result:o})),console.log("[progress] timelineMaxMs calculated:",{result:o,totalFramesAll:b(),durationMs:a(),totalFrames:e(V),frameRate:z,windowStartMs:R(),windowEndMs:E(),showTimeline:l()}),o});let q=X(1920),xe=X(1080),ye=X(bt(g())),Ie=X(bt(s()));function Ve(){const o=e(q)/e(xe),_=60,x=c()&&e(V)>0?56:0,P=l()&&e(V)>0?48:0,T=32,ae=g()-T,k=s()-_-x-P-T;let we,be;o>ae/k?(we=ae,be=Math.round(we/o)):(be=k,we=Math.round(be*o));const Oe=300;we<Oe||be<Oe?o>1?(m(ye,Math.max(Oe,we),!0),m(Ie,Math.round(e(ye)/o),!0)):(m(Ie,Math.max(Oe,be),!0),m(ye,Math.round(e(Ie)*o),!0)):(m(ye,we,!0),m(Ie,be,!0)),m(ye,Math.min(e(ye),ae),!0),m(Ie,Math.min(e(Ie),k),!0),console.log("📐 [VideoPreview] Preview size updated:",{outputSize:{width:e(q),height:e(xe)},previewSize:{width:e(ye),height:e(Ie)},availableSpace:{width:ae,height:k},uiElements:{headerHeight:_,controlsHeight:x,timelineHeight:P,padding:T},aspectRatio:o.toFixed(3)})}function Je(){if(B){if(W=B.getContext("bitmaprenderer"),!W){console.error("❌ [VideoPreview] Failed to get ImageBitmapRenderingContext");return}console.log("🎨 [VideoPreview] Canvas container size:",{containerWidth:B.parentElement?.clientWidth,containerHeight:B.parentElement?.clientHeight}),m(U,!0),console.log("🎨 [VideoPreview] Canvas initialized for bitmap rendering")}}function ee(){F||(console.log("👷 [VideoPreview] Creating VideoComposite Worker..."),F=new Worker(new URL(""+new URL("../workers/index-P199Z2fo.js",import.meta.url).href,import.meta.url),{type:"module"}),F.onmessage=o=>{const{type:_,data:x}=o.data;switch(_){case"initialized":console.log("✅ [VideoPreview] Worker initialized");break;case"ready":if(console.log("✅ [VideoPreview] Video processing ready:",x),m(me,!0),m(V,x.totalFrames,!0),m(Y,e(V)/z),m(q,x.outputSize.width,!0),m(xe,x.outputSize.height,!0),console.log("[progress] Worker ready - internal state updated:",{totalFrames:e(V),duration:e(Y),outputSize:{width:e(q),height:e(xe)},shouldContinuePlayback:e(de),windowStartIndex:h()}),B.width=e(q),B.height=e(xe),m(L,!1),pe){try{console.timeEnd(pe)}catch{}pe=null}if(e(de)||j(0),e(de)){const P=e(Be)-h(),T=Math.max(0,Math.min(P,x.totalFrames-1));console.log("[progress] Worker ready, continuing playback in new window:",{shouldContinuePlayback:e(de),continueFromGlobalFrame:e(Be),windowStartIndex:h(),targetWindowFrame:P,startFrame:T,totalFrames:x.totalFrames}),m(de,!1),requestAnimationFrame(()=>{console.log("[progress] Starting playback in new window from frame",T),j(T),requestAnimationFrame(()=>{console.log("[progress] Resuming playback after seek"),ke()})})}break;case"frame":_e(x.bitmap,x.frameIndex,x.timestamp);break;case"bufferStatus":if(console.log(`🧯 [VideoPreview] Buffer status: ${x.level}`,x),O=x.level,(x.level==="low"||x.level==="critical")&&F&&M&&M.targetGlobalFrame>h()&&H!==M.targetGlobalFrame)try{const P=M.transferableChunks.map(ae=>{const k=ae.data.slice(0);return{...ae,data:k}}),T=P.map(ae=>ae.data);F.postMessage({type:"appendWindow",data:{chunks:P,startGlobalFrame:M.targetGlobalFrame}},{transfer:T}),H=M.targetGlobalFrame,console.log("➕ [prefetch] appendWindow dispatched (reuse cache) for start:",H,"chunks:",P.length)}catch(P){console.warn("⚠️ [prefetch] appendWindow (reuse) failed:",P)}if(b()>0){const P=h()+Math.max(0,e(V)),T=Math.min(P,Math.max(0,b())),ae=Math.max(0,b()-T),k=Math.min(90,ae);k>0&&(C&&C.nextGlobalFrame===T||(C={nextGlobalFrame:T,windowSize:k},console.log("[prefetch] Planned next window:",C)),M&&M.targetGlobalFrame<=h()&&(console.log("[prefetch] Discard stale cache for start:",M.targetGlobalFrame,"current windowStartIndex:",h()),M=null),t.fetchWindowData&&!le&&!M&&C&&(x.level==="low"||x.level==="critical")&&(le=!0,(async()=>{try{console.time("[prefetch] build");const be=C.nextGlobalFrame/z*1e3,Oe=C.windowSize/z*1e3;console.log("[prefetch] Building cache for plan:",{centerMs:be,afterMs:Oe,plan:C});const rt=await t.fetchWindowData({centerMs:be,beforeMs:0,afterMs:Oe}),ot=(Array.isArray(rt?.chunks)?rt.chunks:[]).map(Pe=>{const He=vt.convertToUint8Array(Pe.data);return{data:He?He.buffer.slice(He.byteOffset,He.byteOffset+He.byteLength):Pe.data,timestamp:Pe.timestamp,type:Pe.type,size:Pe.size,codedWidth:Pe.codedWidth,codedHeight:Pe.codedHeight,codec:Pe.codec}});M={targetGlobalFrame:rt?.windowStartIndex??C.nextGlobalFrame,windowSize:ot.length,transferableChunks:ot,transferObjects:ot.map(Pe=>Pe.data)},console.timeEnd("[prefetch] build"),console.log("[prefetch] Cache ready for start:",M?.targetGlobalFrame,"size:",M?.windowSize);try{if((O==="low"||O==="critical")&&F&&M&&M.targetGlobalFrame>h()&&H!==M.targetGlobalFrame){const Pe=M.transferableChunks.map(it=>{const pt=it.data.slice(0);return{...it,data:pt}}),He=Pe.map(it=>it.data);F.postMessage({type:"appendWindow",data:{chunks:Pe,startGlobalFrame:M.targetGlobalFrame}},{transfer:He}),H=M.targetGlobalFrame,console.log("➕ [prefetch] appendWindow dispatched for start:",H,"chunks:",Pe.length)}}catch(Pe){console.warn("⚠️ [prefetch] appendWindow failed:",Pe)}}catch(be){console.warn("⚠️ [prefetch] build failed:",be)}finally{le=!1}})()))}break;case"sizeChanged":console.log("📐 [VideoPreview] Output size changed:",x),m(q,x.outputSize.width,!0),m(xe,x.outputSize.height,!0),Ve(),B.width=e(q),B.height=e(xe);break;case"windowComplete":console.log("🔄 [VideoPreview] Window playback completed, requesting next window"),N(x);break;case"complete":console.log("🎉 [VideoPreview] Playback completed"),m(D,!1);break;case"error":console.error("❌ [VideoPreview] Worker error:",x),m(L,!1);break;default:console.warn("⚠️ [VideoPreview] Unknown worker message:",_)}},F.onerror=o=>{console.error("❌ [VideoPreview] Worker error:",o),m(L,!1)},F.postMessage({type:"init"}))}function _e(o,_,x){if(!W){console.error("❌ [VideoPreview] Bitmap context not available");return}try{W.transferFromImageBitmap(o),m(ue,_,!0),m(Xe,h()),m(G,(e(Xe)+_)/z)}catch(P){console.error("❌ [VideoPreview] Display error:",P)}}async function te(){if(!F||!r().length){console.warn("⚠️ [VideoPreview] Cannot process: missing worker or chunks");return}if(console.log("🎬 [VideoPreview] Processing video with",r().length,"chunks"),!vt.validateChunks(r()).isValid){console.warn("⚠️ [VideoPreview] Invalid chunk data detected, attempting to fix...");const k=vt.fixChunksFormat(r());if(k.length>0)r(k),console.log("✅ [VideoPreview] Fixed chunk format");else{console.error("❌ [VideoPreview] Cannot fix chunk format, aborting"),m(L,!1);return}}m(L,!e(me));let _,x=!1;if(M&&M.targetGlobalFrame===h()?(_=M.transferableChunks,x=!0,console.log("⚡ [prefetch] Using cached transferableChunks:",{targetGlobalFrame:M.targetGlobalFrame,windowSize:M.windowSize,chunks:_.length}),M=null):_=r().map(k=>{let we;try{const be=vt.convertToUint8Array(k.data);if(!be)return console.error("❌ [VideoPreview] Cannot convert chunk data to Uint8Array:",k.data),null;const Oe=be.byteOffset,rt=be.byteLength;we=be.buffer.slice(Oe,Oe+rt)}catch(be){return console.error("❌ [VideoPreview] Error processing chunk data:",be),null}return{data:we,timestamp:k.timestamp,type:k.type,size:k.size,codedWidth:k.codedWidth,codedHeight:k.codedHeight,codec:k.codec}}).filter(k=>k!==null),console.log("📤 [VideoPreview] Prepared",_.length,"transferable chunks",x?"(from cache)":""),_.length>0){const k=_[0];console.log("🔍 [VideoPreview] First chunk dimensions:",{codedWidth:k.codedWidth,codedHeight:k.codedHeight,aspectRatio:k.codedWidth&&k.codedHeight?(k.codedWidth/k.codedHeight).toFixed(3):"unknown",size:k.size,type:k.type,codec:k.codec})}const P=_.map(k=>k.data),T={type:e(u).type,color:e(u).color,padding:e(u).padding,outputRatio:e(u).outputRatio,videoPosition:e(u).videoPosition,borderRadius:e(u).borderRadius,inset:e(u).inset,gradient:e(u).gradient?{type:e(u).gradient.type,...e(u).gradient.type==="linear"&&"angle"in e(u).gradient?{angle:e(u).gradient.angle}:{},...e(u).gradient.type==="radial"&&"centerX"in e(u).gradient?{centerX:e(u).gradient.centerX,centerY:e(u).gradient.centerY,radius:e(u).gradient.radius}:{},...e(u).gradient.type==="conic"&&"centerX"in e(u).gradient?{centerX:e(u).gradient.centerX,centerY:e(u).gradient.centerY,angle:"angle"in e(u).gradient?e(u).gradient.angle:0}:{},stops:e(u).gradient.stops.map(k=>({color:k.color,position:k.position}))}:void 0,shadow:e(u).shadow?{offsetX:e(u).shadow.offsetX,offsetY:e(u).shadow.offsetY,blur:e(u).shadow.blur,color:e(u).shadow.color}:void 0,image:e(u).image?{imageId:e(u).image.imageId,imageBitmap:null,fit:e(u).image.fit,position:e(u).image.position,opacity:e(u).image.opacity,blur:e(u).image.blur,scale:e(u).image.scale,offsetX:e(u).image.offsetX,offsetY:e(u).image.offsetY}:void 0,wallpaper:e(u).wallpaper?{imageId:e(u).wallpaper.imageId,imageBitmap:null,fit:e(u).wallpaper.fit,position:e(u).wallpaper.position,opacity:e(u).wallpaper.opacity,blur:e(u).wallpaper.blur,scale:e(u).wallpaper.scale,offsetX:e(u).wallpaper.offsetX,offsetY:e(u).wallpaper.offsetY}:void 0},ae=[...P];if(T.image&&e(u).image)try{const k=ht.getImageBitmap(e(u).image.imageId);if(k){const we=await createImageBitmap(k);T.image.imageBitmap=we,ae.push(we)}else console.warn("⚠️ [VideoPreview] ImageBitmap not found for imageId:",e(u).image.imageId),T.image=void 0}catch(k){console.error("❌ [VideoPreview] Failed to get ImageBitmap:",k),T.image=void 0}if(T.wallpaper&&e(u).wallpaper)try{const k=ht.getImageBitmap(e(u).wallpaper.imageId);if(k){const we=await createImageBitmap(k);T.wallpaper.imageBitmap=we,ae.push(we)}else console.warn("⚠️ [VideoPreview] ImageBitmap not found for wallpaper imageId:",e(u).wallpaper.imageId),T.wallpaper=void 0}catch(k){console.error("❌ [VideoPreview] Failed to get wallpaper ImageBitmap:",k),T.wallpaper=void 0}console.log("📤 [VideoPreview] Sending config to worker:",T),console.log("[progress] VideoPreview - sending process message to worker:",{chunksLength:_.length,transferObjectsLength:ae.length,windowStartIndex:h()}),F.postMessage({type:"process",data:{chunks:_,backgroundConfig:T,startGlobalFrame:h()}},{transfer:ae}),console.log("[progress] VideoPreview - process message sent"),x?ce++:oe++;{const k=ce+oe,we=k?(ce/k).toFixed(2):"0.00";console.log("[prefetch] stats",{hits:ce,misses:oe,hitRate:we})}}function ke(){!F||e(V)===0||(console.log("▶️ [VideoPreview] Starting playback"),m(D,!0),F.postMessage({type:"play"}))}function ve(){F&&(console.log("⏸️ [VideoPreview] Pausing playback"),m(D,!1),F.postMessage({type:"pause"}))}function K(){ve(),j(0)}function j(o){!F||o<0||o>=e(V)||(console.log("⏭️ [VideoPreview] Seeking to frame:",o),F.postMessage({type:"seek",data:{frameIndex:o}}))}function ie(o){const _=Math.floor(o*z);j(_)}function d(o){const _=Math.max(0,Math.floor(o)),x=Math.floor(_/60),P=_%60;return`${String(x).padStart(2,"0")}:${String(P).padStart(2,"0")}`}let p=-1;tt(()=>{const o=e(Xe)+e(ue),_=e(Ne);if(o!==p){if(p>=0){const x=o-p;Math.abs(x)!==1&&console.warn(`[video-timer] frame jump ${p} -> ${o} (Δ=${x})`)}p=o,console.log(`[video-timer] ${d(o/z)} / ${d(_)}`)}});async function $(o){if(!F)return;const _={type:o.type,color:o.color,padding:o.padding,outputRatio:o.outputRatio,videoPosition:o.videoPosition,borderRadius:o.borderRadius,inset:o.inset,gradient:o.gradient?{type:o.gradient.type,...o.gradient.type==="linear"&&"angle"in o.gradient?{angle:o.gradient.angle}:{},...o.gradient.type==="radial"&&"centerX"in o.gradient?{centerX:o.gradient.centerX,centerY:o.gradient.centerY,radius:o.gradient.radius}:{},...o.gradient.type==="conic"&&"centerX"in o.gradient?{centerX:o.gradient.centerX,centerY:o.gradient.centerY,angle:"angle"in o.gradient?o.gradient.angle:0}:{},stops:o.gradient.stops.map(P=>({color:P.color,position:P.position}))}:void 0,shadow:o.shadow?{offsetX:o.shadow.offsetX,offsetY:o.shadow.offsetY,blur:o.shadow.blur,color:o.shadow.color}:void 0,image:o.image?{imageId:o.image.imageId,imageBitmap:null,fit:o.image.fit,position:o.image.position,opacity:o.image.opacity,blur:o.image.blur,scale:o.image.scale,offsetX:o.image.offsetX,offsetY:o.image.offsetY}:void 0,wallpaper:o.wallpaper?{imageId:o.wallpaper.imageId,imageBitmap:null,fit:o.wallpaper.fit,position:o.wallpaper.position,opacity:o.wallpaper.opacity,blur:o.wallpaper.blur,scale:o.wallpaper.scale,offsetX:o.wallpaper.offsetX,offsetY:o.wallpaper.offsetY}:void 0};console.log("⚙️ [VideoPreview] Updating background config:",_);const x=[];if(_.image&&o.image)try{const P=ht.getImageBitmap(o.image.imageId);if(P){const T=await createImageBitmap(P);_.image.imageBitmap=T,x.push(T)}else console.warn("⚠️ [VideoPreview] ImageBitmap not found for imageId:",o.image.imageId),_.image=void 0}catch(P){console.error("❌ [VideoPreview] Failed to get ImageBitmap:",P),_.image=void 0}if(_.wallpaper&&o.wallpaper)try{const P=ht.getImageBitmap(o.wallpaper.imageId);if(P){const T=await createImageBitmap(P);_.wallpaper.imageBitmap=T,x.push(T)}else console.warn("⚠️ [VideoPreview] ImageBitmap not found for wallpaper imageId:",o.wallpaper.imageId),_.wallpaper=void 0}catch(P){console.error("❌ [VideoPreview] Failed to get wallpaper ImageBitmap:",P),_.wallpaper=void 0}F.postMessage({type:"config",data:{backgroundConfig:_}},x.length>0?{transfer:x}:void 0)}let S=!1;tt(()=>{console.log("🔍 [VideoPreview] Effect triggered:",{isRecordingComplete:f(),chunksLength:r().length,hasProcessed:S,isInitialized:e(U),hasWorker:!!F}),console.log("[progress] Component state check:",{isRecordingComplete:f(),chunksLength:r().length,hasProcessed:S,isInitialized:e(U),hasWorker:!!F,durationMs:a(),totalFrames:e(V),totalFramesAll:b(),showTimeline:l(),timelineMaxMs:e(fe),timelineCondition:l()&&e(fe)>0}),f()&&r().length>0&&!S&&e(U)&&F&&(console.log("🎬 [VideoPreview] Processing completed recording with",r().length,"chunks"),S=!0,te().catch(o=>{console.error("❌ [VideoPreview] Failed to process video:",o)}))});let y=null;tt(()=>{r()&&r()!==y&&(console.log("[progress] New window data detected, reprocessing:",{oldLength:y?.length||0,newLength:r().length,windowStartIndex:h()}),y=r(),S=!1,f()&&r().length>0&&e(U)&&F&&(console.log("[progress] Immediately processing new window data"),e(de)?console.log("[progress] Keep currentFrameIndex for resume playback"):(m(ue,0),console.log("[progress] Reset currentFrameIndex to 0 for new window (no resume)")),S=!0,te().catch(o=>{console.error("❌ [VideoPreview] Failed to process new window data:",o)})))});function N(o){if(console.log("[progress] Handling window complete:",{windowStartIndex:h(),totalFrames:o.totalFrames,lastFrameIndex:o.lastFrameIndex,totalFramesAll:b(),currentGlobalFrame:h()+o.lastFrameIndex,isPlaying:e(D)}),!e(D)){console.log("[progress] Not playing, ignoring window complete");return}const x=h()+o.lastFrameIndex+1;if(x<b()){let P=x,T=Math.min(90,b()-x);if(M&&M.targetGlobalFrame>=x&&M.targetGlobalFrame>h()?(P=M.targetGlobalFrame,T=Math.min(M.windowSize,b()-P),console.log("[prefetch] Using cached plan for next window:",{plannedNext:P,windowSize:T})):C&&C.nextGlobalFrame>=x&&C.nextGlobalFrame>h()&&(P=C.nextGlobalFrame,T=Math.min(C.windowSize,b()-P),console.log("[prefetch] Using planned next window:",{plannedNext:P,windowSize:T})),P<=h()||P>=b()){console.log("[progress] No forward progress available (plannedNext=",P,"), stopping playback"),m(D,!1),m(de,!1);return}console.log("[progress] Requesting next window for continuous playback:",{nextGlobalFrame:P,totalFramesAll:b(),remainingFrames:b()-P}),pe=`[cutover] to ${P}`;try{console.time(pe)}catch{}if(m(de,!0),m(Be,P,!0),console.log("[progress] Set shouldContinuePlayback = true, continueFromGlobalFrame =",P),t.onRequestWindow){const ae=P/z*1e3;t.onRequestWindow({centerMs:ae,beforeMs:0,afterMs:T/z*1e3})}C=null}else console.log("[progress] Reached end of video, stopping playback"),m(D,!1),m(de,!1)}function he(o){console.log("[progress] Seeking to global frame:",{globalFrameIndex:o,windowStartIndex:h(),totalFrames:e(V),totalFramesAll:b()});const _=o-h();if(_>=0&&_<e(V))console.log("[progress] Frame in current window, seeking locally:",_),j(_);else{console.log("[progress] Frame outside current window, requesting new window");const x=o/z*1e3;t.onRequestWindow?.({centerMs:x,beforeMs:1500,afterMs:1500})}}function J(o){const _=Math.floor(o/1e3*z);he(_)}function Me(o){const _=Math.max(0,Math.min(o,e(fe)));console.log("[progress] Timeline input:",{timeMs:o,clampedMs:_,windowStartMs:R(),windowEndMs:E(),timelineMaxMs:e(fe)}),J(_)}tt(()=>{e(u)&&F&&e(V)>0&&$(e(u))}),tt(()=>{e(q)>0&&e(xe)>0&&Ve()}),Wt(()=>(console.log("[progress] Component mounted with props:",{encodedChunks:r().length,isRecordingComplete:f(),durationMs:a(),windowStartMs:R(),windowEndMs:E(),showTimeline:l(),totalFramesAll:b(),windowStartIndex:h()}),Je(),ee(),tt(()=>{console.log("[progress] Props changed:",{durationMs:a(),windowStartMs:R(),windowEndMs:E(),showTimeline:l(),totalFramesAll:b(),windowStartIndex:h(),encodedChunksLength:r().length,isRecordingComplete:f(),shouldContinuePlayback:e(de)})}),tt(()=>{e(V),l(),c(),g(),s(),e(q)>0&&e(xe)>0&&Ve()}),()=>{F&&(F.terminate(),F=null)}));function Qe(){return{play:ke,pause:ve,stop:K,seekToFrame:j,seekToTime:ie,seekToGlobalFrame:he,seekToGlobalTime:J,updateBackgroundConfig:$,getCurrentFrame:()=>e(ue),getCurrentTime:()=>e(G),getTotalFrames:()=>e(V),getGlobalFrame:()=>h()+e(ue),getDuration:()=>e(Y),isPlaying:()=>e(D)}}var Ae=xa(),De=n(Ae),et=n(De),lt=n(et);Ct(lt,{class:"w-4 h-4 text-gray-400"}),Fe(2),i(et);var at=v(et,2),dt=n(at,!0);i(at),i(De);var Ue=v(De,2),Ye=n(Ue),je=n(Ye);let ct;Tt(je,o=>B=o,()=>B);var Mt=v(je,2);{var Xt=o=>{var _=ha(),x=n(_);St(x,{class:"w-8 h-8 text-blue-500 animate-spin mb-2"}),Fe(2),i(_),I(o,_)};Le(Mt,o=>{e(L)&&o(Xt)})}i(Ye),i(Ue);var Nt=v(Ue,2);{var At=o=>{var _=ba(),x=n(_);Ze(x),x.__input=[wa,Me];var P=v(x,2),T=n(P),ae=n(T);ae.__click=function(...qe){(e(D)?ve:ke)?.apply(this,qe)};var k=n(ae);{var we=qe=>{ea(qe,{class:"w-4 h-4"})},be=qe=>{ta(qe,{class:"w-4 h-4"})};Le(k,qe=>{e(D)?qe(we):qe(be,!1)})}i(ae);var Oe=v(ae,2),rt=n(Oe);i(Oe),i(T);var kt=v(T,2),ot=n(kt),Pe=n(ot);i(ot);var He=v(ot,2),it=n(He);i(He);var pt=v(He,2),Yt=n(pt);i(pt);var Rt=v(pt,2),Ot=n(Rt);i(Rt),i(kt),i(P),i(_),ze((qe,Lt,Gt,Dt)=>{ft(x,"max",e(fe)),$t(x,qe),x.disabled=e(L),ae.disabled=e(L),Q(rt,`${Lt??""} / ${Gt??""}`),Q(Pe,`Frame: ${h()+e(ue)+1}/${(b()>0?b():e(V)>0?e(V):r().length)??""}`),Q(it,`Window: ${h()+1}-${h()+e(V)}/${b()??""}`),Q(Yt,`Resolution: ${e(q)??""}×${e(xe)??""}`),Q(Ot,`Duration: ${Dt??""}s`)},[()=>Math.min(e(fe),Math.floor((h()+e(ue))/z*1e3)),()=>d((h()+e(ue))/z),()=>d(e(Ne)),()=>Math.floor(e(fe)/1e3)]),I(o,_)};Le(Nt,o=>{l()&&e(fe)>0&&o(At)})}return i(Ae),ze(o=>{Ke(Ae,1,`flex flex-col h-full bg-gray-900 rounded-lg overflow-hidden ${A()??""}`,"svelte-1w9wlfj"),Q(dt,e(u).outputRatio==="custom"?`${e(q)}×${e(xe)}`:e(u).outputRatio),nt(Ye,`width: ${e(ye)??""}px; height: ${e(Ie)??""}px;`),ct=Ke(je,1,"block rounded transition-opacity duration-300",null,ct,o),nt(je,`width: ${e(ye)??""}px; height: ${e(Ie)??""}px;`)},[()=>({"opacity-50":e(L)})]),I(w,Ae),se({getControls:Qe})}st(["input","click"]);class _a{constructor(){Pt(this,"currentExportWorker",null);Pt(this,"progressCallback",null)}async exportEditedVideo(t,r,f){this.progressCallback=f||null;try{if(console.log(`🎬 [ExportManager] Starting ${r.format.toUpperCase()} export`),console.log("📊 [ExportManager] Export options:",r),console.log("📦 [ExportManager] Input chunks:",t.length),!t||t.length===0)throw new Error("No encoded chunks provided");const g=this.prepareExportData(t,r);if(r.format==="webm")return await this.exportWebM(g,r);if(r.format==="mp4")return await this.exportMP4(g,r);throw new Error(`Unsupported format: ${r.format}`)}catch(g){throw console.error(`❌ [ExportManager] ${r.format.toUpperCase()} export failed:`,g),g}finally{this.cleanup()}}prepareExportData(t,r){return{chunks:t.map(s=>({data:s.data instanceof Uint8Array?s.data:new Uint8Array(s.data),timestamp:s.timestamp||0,type:s.type==="key"?"key":"delta",size:s.size||s.data.byteLength,codedWidth:s.codedWidth||1920,codedHeight:s.codedHeight||1080,codec:s.codec||"vp8"})),options:{...{resolution:{width:1920,height:1080},bitrate:8e6,framerate:30},...r}}}async exportWebM(t,r){return console.log("🎬 [ExportManager] Starting WebM export process"),new Promise((f,g)=>{this.currentExportWorker=new Worker(new URL(""+new URL("../workers/index-Ci66d-U8.js",import.meta.url).href,import.meta.url),{type:"module"}),this.currentExportWorker.onmessage=s=>{const{type:c,data:l}=s.data;switch(c){case"progress":this.updateProgress({type:"webm",stage:l.stage,progress:l.progress,currentFrame:l.currentFrame,totalFrames:l.totalFrames,estimatedTimeRemaining:l.estimatedTimeRemaining||0,fileSize:l.fileSize});break;case"complete":console.log("✅ [ExportManager] WebM export completed"),l&&l.savedToOpfs?f({savedToOpfs:l.savedToOpfs}):f(l.blob);break;case"error":console.error("❌ [ExportManager] WebM export error:",l.error),g(new Error(l.error));break;default:console.warn("⚠️ [ExportManager] Unknown WebM worker message:",c)}},this.currentExportWorker.onerror=s=>{console.error("❌ [ExportManager] WebM worker error:",s),g(new Error("WebM export worker failed"))},this.currentExportWorker.postMessage({type:"export",data:t})})}async exportMP4(t,r){return console.log("🎬 [ExportManager] Starting MP4 export process with Mediabunny"),new Promise((f,g)=>{this.currentExportWorker=new Worker(new URL(""+new URL("../workers/index-Ci66d-U8.js",import.meta.url).href,import.meta.url),{type:"module"}),this.currentExportWorker.onmessage=s=>{const{type:c,data:l}=s.data;switch(c){case"progress":this.updateProgress({type:"mp4",stage:l.stage,progress:l.progress,currentFrame:l.currentFrame,totalFrames:l.totalFrames,estimatedTimeRemaining:l.estimatedTimeRemaining||0,fileSize:l.fileSize});break;case"complete":console.log("✅ [ExportManager] MP4 export completed"),f(l.blob);break;case"error":console.error("❌ [ExportManager] MP4 export error:",l.error),g(new Error(l.error));break;default:console.warn("⚠️ [ExportManager] Unknown MP4 worker message:",c)}},this.currentExportWorker.onerror=s=>{console.error("❌ [ExportManager] MP4 worker error:",s),g(new Error("MP4 export worker failed"))},this.currentExportWorker.postMessage({type:"export",data:t})})}updateProgress(t){this.progressCallback&&this.progressCallback(t)}cancelExport(){this.currentExportWorker&&(this.currentExportWorker.postMessage({type:"cancel"}),this.cleanup())}cleanup(){this.currentExportWorker&&(this.currentExportWorker.terminate(),this.currentExportWorker=null),this.progressCallback=null}}var Ma=Z('<span class="bg-emerald-500 text-white px-2 py-1 rounded">With Background</span>'),ka=Z('<span class="bg-blue-500 text-white px-2 py-1 rounded"> </span> <!>',1),Pa=Z('<span class="text-slate-500">No recording data</span>'),Fa=(w,t,r)=>{t(),r()},Sa=Z("<!> Exporting WebM...",1),$a=Z("<!> Export WebM",1),Ia=(w,t,r)=>{t(),r()},Ra=Z("<!> Exporting MP4...",1),Ea=Z("<!> Export MP4",1),Wa=Z('<span class="flex items-center gap-1"><!> </span>'),Ta=Z('<div class="bg-white border border-slate-200 rounded-md p-3"><div class="flex justify-between items-center mb-2"><span class="text-sm font-medium text-gray-700"> </span> <span class="text-sm font-semibold text-gray-900"> </span></div> <div class="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden mb-2"><div></div></div> <div class="flex justify-between text-xs text-slate-600"><span class="flex items-center gap-1"><!> </span> <!></div></div>'),Ca=Z('<div class="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-md text-sm text-amber-800"><!> Please complete recording before exporting video</div>'),Ba=Z('<div class="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-md text-sm text-amber-800"><!> No video data available for export</div>'),Va=Z('<div><div class="flex justify-between items-center"><div class="flex items-center gap-2"><!> <h3 class="text-base font-semibold text-slate-800 m-0">Export Video</h3></div> <div class="flex gap-2 text-xs"><!></div></div> <div class="flex gap-3"><button class="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-blue-500 text-white text-sm font-medium rounded-md cursor-pointer transition-all duration-200 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 disabled:opacity-50 disabled:cursor-not-allowed"><!></button> <button><!></button></div> <!> <!></div>');function za(w,t){ne(t,!0);let r=Se(t,"encodedChunks",19,()=>[]),f=Se(t,"isRecordingComplete",3,!1),g=Se(t,"totalFramesAll",3,0),s=Se(t,"opfsDirId",3,""),c=Se(t,"className",3,"");const l=ge(()=>g()>0?g():r().length),a=ge(()=>Ge.config);let R=X(!1),E=X(!1),b=X(null),h=X(0),A=X(0),C=null;function M(){C&&(cancelAnimationFrame(C),C=null),m(h,0),m(A,0)}function le(){if(C)return;const d=()=>{const p=e(A)-e(h);if(Math.abs(p)<.5){m(h,e(A),!0),C=null;return}m(h,e(h)+p*.25),C=requestAnimationFrame(d)};C=requestAnimationFrame(d)}function H(d){const p=Math.max(0,Math.min(100,d));p>=e(A)&&(m(A,p,!0),le())}let O=null,ce=!1,oe=0;const pe=80;function u(){ce||(ce=!0,requestAnimationFrame(()=>{ce=!1;const d=performance.now();d-oe<pe||(oe=d,e(b)&&O&&(e(b).stage=O.stage,e(b).currentFrame=O.currentFrame,e(b).totalFrames=O.totalFrames,e(b).estimatedTimeRemaining=O.estimatedTimeRemaining||0))}))}const B=new _a,W=ge(()=>f()&&r().length>0&&!e(R)&&!e(E));async function U(){if(e(W))try{m(R,!0),m(b,{type:"webm",stage:"preparing",progress:0,currentFrame:0,totalFrames:r().length,estimatedTimeRemaining:0},!0),console.log("🎬 [Export] Starting WebM export with",r().length,"chunks");const d=e(a)?{type:e(a).type,color:e(a).color,padding:e(a).padding,outputRatio:e(a).outputRatio,videoPosition:e(a).videoPosition,borderRadius:e(a).borderRadius,inset:e(a).inset,gradient:e(a).gradient?{type:e(a).gradient.type,...e(a).gradient.type==="linear"&&"angle"in e(a).gradient?{angle:e(a).gradient.angle}:{},...e(a).gradient.type==="radial"&&"centerX"in e(a).gradient?{centerX:e(a).gradient.centerX,centerY:e(a).gradient.centerY,radius:e(a).gradient.radius}:{},...e(a).gradient.type==="conic"&&"centerX"in e(a).gradient?{centerX:e(a).gradient.centerX,centerY:e(a).gradient.centerY,angle:"angle"in e(a).gradient?e(a).gradient.angle:0}:{},stops:e(a).gradient.stops.map(y=>({color:y.color,position:y.position}))}:void 0,shadow:e(a).shadow?{offsetX:e(a).shadow.offsetX,offsetY:e(a).shadow.offsetY,blur:e(a).shadow.blur,color:e(a).shadow.color}:void 0,image:e(a).image?{imageId:e(a).image.imageId,imageBitmap:e(a).image.imageBitmap,fit:e(a).image.fit,position:e(a).image.position,opacity:e(a).image.opacity,blur:e(a).image.blur,scale:e(a).image.scale,offsetX:e(a).image.offsetX,offsetY:e(a).image.offsetY}:void 0,wallpaper:e(a).wallpaper?{imageId:e(a).wallpaper.imageId,imageBitmap:e(a).wallpaper.imageBitmap,fit:e(a).wallpaper.fit,position:e(a).wallpaper.position,opacity:e(a).wallpaper.opacity,blur:e(a).wallpaper.blur,scale:e(a).wallpaper.scale,offsetX:e(a).wallpaper.offsetX,offsetY:e(a).wallpaper.offsetY}:void 0}:void 0,p=await B.exportEditedVideo(r(),{format:"webm",includeBackground:!!d,backgroundConfig:d,quality:"medium",source:s()?"opfs":"chunks",opfsDirId:s()||void 0,saveToOpfs:!!s(),opfsFileName:s()?`edited-video-${new Date().toISOString().replace(/[:.]/g,"-")}.webm`:void 0},y=>{O={stage:y.stage,currentFrame:y.currentFrame,totalFrames:y.totalFrames,estimatedTimeRemaining:y.estimatedTimeRemaining||0};const N=e(l)||y.totalFrames||0,he=N>0?y.currentFrame/N*100:y.progress;H(he),u()});H(100);const S=`edited-video-${new Date().toISOString().replace(/[:.]/g,"-")}.webm`;if(p&&p.savedToOpfs){const y=p.savedToOpfs;console.log("✅ [Export] WebM saved to OPFS:",y);try{const Me=await(await(await(await navigator.storage.getDirectory()).getDirectoryHandle(y.dirId,{create:!1})).getFileHandle(y.fileName,{create:!1})).getFile(),Qe=Me.slice(0,Me.size,"video/webm");await me(Qe,y.fileName),console.log("⬇️ [Export] Downloaded WebM from OPFS:",y.fileName)}catch(N){console.warn("⚠️ [Export] Failed to read WebM from OPFS, falling back to no-op:",N)}}else await me(p,S),console.log("✅ [Export] WebM export completed:",S)}catch(d){console.error("❌ [Export] WebM export failed:",d)}finally{m(R,!1),M(),m(b,null)}}async function L(){if(e(W))try{m(E,!0),m(b,{type:"mp4",stage:"preparing",progress:0,currentFrame:0,totalFrames:r().length,estimatedTimeRemaining:0},!0),console.log("🎬 [Export] Starting MP4 export with",r().length,"chunks");const d=e(a)?{type:e(a).type,color:e(a).color,padding:e(a).padding,outputRatio:e(a).outputRatio,videoPosition:e(a).videoPosition,borderRadius:e(a).borderRadius,inset:e(a).inset,gradient:e(a).gradient?{type:e(a).gradient.type,...e(a).gradient.type==="linear"&&"angle"in e(a).gradient?{angle:e(a).gradient.angle}:{},...e(a).gradient.type==="radial"&&"centerX"in e(a).gradient?{centerX:e(a).gradient.centerX,centerY:e(a).gradient.centerY,radius:e(a).gradient.radius}:{},...e(a).gradient.type==="conic"&&"centerX"in e(a).gradient?{centerX:e(a).gradient.centerX,centerY:e(a).gradient.centerY,angle:"angle"in e(a).gradient?e(a).gradient.angle:0}:{},stops:e(a).gradient.stops.map(y=>({color:y.color,position:y.position}))}:void 0,shadow:e(a).shadow?{offsetX:e(a).shadow.offsetX,offsetY:e(a).shadow.offsetY,blur:e(a).shadow.blur,color:e(a).shadow.color}:void 0,image:e(a).image?{imageId:e(a).image.imageId,imageBitmap:e(a).image.imageBitmap,fit:e(a).image.fit,position:e(a).image.position,opacity:e(a).image.opacity,blur:e(a).image.blur,scale:e(a).image.scale,offsetX:e(a).image.offsetX,offsetY:e(a).image.offsetY}:void 0,wallpaper:e(a).wallpaper?{imageId:e(a).wallpaper.imageId,imageBitmap:e(a).wallpaper.imageBitmap,fit:e(a).wallpaper.fit,position:e(a).wallpaper.position,opacity:e(a).wallpaper.opacity,blur:e(a).wallpaper.blur,scale:e(a).wallpaper.scale,offsetX:e(a).wallpaper.offsetX,offsetY:e(a).wallpaper.offsetY}:void 0}:void 0,p=await B.exportEditedVideo(r(),{format:"mp4",includeBackground:!!d,backgroundConfig:d,quality:"medium",source:s()?"opfs":"chunks",opfsDirId:s()||void 0},y=>{O={stage:y.stage,currentFrame:y.currentFrame,totalFrames:y.totalFrames,estimatedTimeRemaining:y.estimatedTimeRemaining||0};const N=e(l)||y.totalFrames||0,he=N>0?y.currentFrame/N*100:y.progress;H(he),u()}),S=`edited-video-${new Date().toISOString().replace(/[:.]/g,"-")}.mp4`;H(100),await me(p,S),console.log("✅ [Export] MP4 export completed:",S)}catch(d){console.error("❌ [Export] MP4 export failed:",d)}finally{m(E,!1),M(),m(b,null)}}async function me(d,p){try{if(typeof chrome<"u"&&chrome.runtime){const $=URL.createObjectURL(d);chrome.runtime.sendMessage({action:"saveRecording",filename:p,url:$},S=>{URL.revokeObjectURL($),S?.success||F(d,p)})}else F(d,p)}catch($){console.error("Download failed:",$),F(d,p)}}function F(d,p){const $=URL.createObjectURL(d),S=document.createElement("a");S.href=$,S.download=p,S.style.display="none",document.body.appendChild(S),S.click(),document.body.removeChild(S),setTimeout(()=>URL.revokeObjectURL($),1e3)}function ue(d){return{preparing:"Preparing",compositing:"Compositing Background",encoding:"Encoding",muxing:"Muxing Container",finalizing:"Finalizing"}[d]||d}function V(d){if(d<60)return`${Math.round(d)}s`;const p=Math.floor(d/60),$=Math.round(d%60);return`${p}m ${$}s`}var G=Va(),Y=n(G),z=n(Y),D=n(z);la(D,{class:"w-4 h-4 text-gray-600"}),Fe(2),i(z);var de=v(z,2),Be=n(de);{var Xe=d=>{var p=ka(),$=re(p),S=n($);i($);var y=v($,2);{var N=he=>{var J=Ma();I(he,J)};Le(y,he=>{e(a)&&he(N)})}ze(()=>Q(S,`${e(l)??""} frames`)),I(d,p)},Ne=d=>{var p=Pa();I(d,p)};Le(Be,d=>{r().length>0?d(Xe):d(Ne,!1)})}i(de),i(Y);var fe=v(Y,2),q=n(fe);q.__click=[Fa,M,U];var xe=n(q);{var ye=d=>{var p=Sa(),$=re(p);St($,{class:"w-4 h-4 animate-spin"}),Fe(),I(d,p)},Ie=d=>{var p=$a(),$=re(p);zt($,{class:"w-4 h-4"}),Fe(),I(d,p)};Le(xe,d=>{e(R)?d(ye):d(Ie,!1)})}i(q);var Ve=v(q,2);let Je;Ve.__click=[Ia,M,L];var ee=n(Ve);{var _e=d=>{var p=Ra(),$=re(p);St($,{class:"w-4 h-4 animate-spin"}),Fe(),I(d,p)},te=d=>{var p=Ea(),$=re(p);da($,{class:"w-4 h-4"}),Fe(),I(d,p)};Le(ee,d=>{e(E)?d(_e):d(te,!1)})}i(Ve),i(fe);var ke=v(fe,2);{var ve=d=>{var p=Ta(),$=n(p),S=n($),y=n(S);i(S);var N=v(S,2),he=n(N);i(N),i($);var J=v($,2),Me=n(J);let Qe;i(J);var Ae=v(J,2),De=n(Ae),et=n(De);Zt(et,{class:"w-3 h-3"});var lt=v(et);i(De);var at=v(De,2);{var dt=Ue=>{var Ye=Wa(),je=n(Ye);Jt(je,{class:"w-3 h-3"});var ct=v(je);i(Ye),ze(Mt=>Q(ct,` Remaining ${Mt??""}`),[()=>V(e(b).estimatedTimeRemaining)]),I(Ue,Ye)};Le(at,Ue=>{e(b).estimatedTimeRemaining>0&&Ue(dt)})}i(Ae),i(p),ze((Ue,Ye,je,ct)=>{Q(y,`Exporting ${Ue??""} - ${Ye??""}`),Q(he,`${je??""}%`),Qe=Ke(Me,1,"h-full origin-left transition-transform duration-300 rounded-full will-change-transform",null,Qe,ct),nt(Me,`transform: scaleX(${e(h)/100})`),Q(lt,` ${e(b).currentFrame??""} / ${e(l)??""} frames`)},[()=>e(b).type.toUpperCase(),()=>ue(e(b).stage),()=>Math.round(e(h)),()=>({"bg-blue-500":e(b).type==="webm","bg-emerald-500":e(b).type==="mp4"})]),I(d,p)};Le(ke,d=>{e(b)&&d(ve)})}var K=v(ke,2);{var j=d=>{var p=Ca(),$=n(p);aa($,{class:"w-4 h-4 text-amber-600"}),Fe(),i(p),I(d,p)},ie=d=>{var p=$e(),$=re(p);{var S=y=>{var N=Ba(),he=n(N);ra(he,{class:"w-4 h-4 text-amber-600"}),Fe(),i(N),I(y,N)};Le($,y=>{r().length===0&&y(S)},!0)}I(d,p)};Le(K,d=>{f()?d(ie,!1):d(j)})}i(G),ze(d=>{Ke(G,1,`flex flex-col gap-4 p-4 bg-slate-50 border border-slate-200 rounded-lg ${c()??""}`),q.disabled=!e(W),Je=Ke(Ve,1,"flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-emerald-500 text-white text-sm font-medium rounded-md cursor-pointer transition-all duration-200 hover:bg-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-opacity-50 disabled:opacity-50 disabled:cursor-not-allowed",null,Je,d),Ve.disabled=!e(W)},[()=>({"opacity-80":e(E)})]),I(w,G),se()}st(["click"]);function Xa(w){const t=w.target,r=parseInt(t.value);Ge.updateBorderRadius(r)}var Na=(w,t,r)=>t(e(r)),Aa=Z("<button><!> <span> </span></button>"),Ya=Z('<div class="p-4 border border-gray-200 rounded-lg bg-white"><div class="flex items-center gap-2 mb-4"><!> <h3 class="text-sm font-semibold text-gray-700">Video Border Radius</h3></div> <div class="flex items-center gap-3 mb-4"><input type="range" class="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider-thumb svelte-1ppepvn" min="0" max="100" step="2"/> <div class="min-w-[50px] text-center text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-1 rounded"> </div></div> <div class="flex gap-2 mb-4 flex-wrap"></div> <div class="mt-4"><div class="flex items-center gap-2 mb-2"><!> <div class="text-xs text-gray-600 font-medium">Preview Effect:</div></div> <div class="flex items-center justify-center p-6 bg-gray-50 rounded-md"><div class="w-40 h-28 bg-gradient-to-br from-blue-100 to-purple-100 border-2 border-gray-300 flex items-center justify-center transition-all duration-300 overflow-hidden shadow-sm"><div class="text-sm text-gray-700 text-center font-medium">Video Area<br/> <span class="text-xs text-gray-500"> </span></div></div></div></div></div>');function Oa(w,t){ne(t,!0);const r=ge(()=>Ge.config.borderRadius||0),f=[{name:"No Radius",value:0,icon:Bt},{name:"Small Radius",value:20,icon:wt},{name:"Medium Radius",value:40,icon:wt},{name:"Large Radius",value:60,icon:wt},{name:"Extra Large Radius",value:80,icon:wt}];function g(u){console.log("🎨 [BorderRadiusControl] Preset selected:",u),Ge.updateBorderRadius(u.value)}function s(u){return e(r)===u}var c=Ya(),l=n(c),a=n(l);Vt(a,{class:"w-4 h-4 text-gray-600"}),Fe(2),i(l);var R=v(l,2),E=n(R);Ze(E),E.__input=[Xa];var b=v(E,2),h=n(b);i(b),i(R);var A=v(R,2);xt(A,21,()=>f,yt,(u,B)=>{const W=ge(()=>e(B).icon);var U=Aa();let L;U.__click=[Na,g,B];var me=n(U);_t(me,()=>e(W),(V,G)=>{G(V,{class:"w-3 h-3"})});var F=v(me,2),ue=n(F,!0);i(F),i(U),ze(V=>{L=Ke(U,1,"flex items-center gap-1.5 px-3 py-2 text-xs border rounded-md cursor-pointer transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50",null,L,V),ft(U,"title",`${e(B).name??""} (${e(B).value??""}px)`),Q(ue,e(B).name)},[()=>({"border-blue-500":s(e(B).value),"bg-blue-500":s(e(B).value),"text-white":s(e(B).value),"border-gray-300":!s(e(B).value),"bg-white":!s(e(B).value),"text-gray-700":!s(e(B).value),"hover:border-blue-400":!s(e(B).value),"hover:bg-blue-50":!s(e(B).value)})]),I(u,U)}),i(A);var C=v(A,2),M=n(C),le=n(M);It(le,{class:"w-3 h-3 text-gray-600"}),Fe(2),i(M);var H=v(M,2),O=n(H),ce=n(O),oe=v(n(ce),3),pe=n(oe);i(oe),i(ce),i(O),i(H),i(C),i(c),ze(()=>{$t(E,e(r)),Q(h,`${e(r)??""}px`),nt(O,`border-radius: ${e(r)??""}px`),Q(pe,`${e(r)??""}px radius`)}),I(w,c),se()}st(["input","click"]);function La(w){const t=w.target,r=parseInt(t.value);Ge.updatePadding(r)}var Ga=(w,t,r)=>t(e(r)),Da=Z("<button><!> <span> </span></button>"),Ua=Z('<br/> <span class="text-xs opacity-90"> </span>',1),ja=Z('<div class="p-4 border border-gray-200 rounded-lg bg-white"><div class="flex items-center gap-2 mb-4"><!> <h3 class="text-sm font-semibold text-gray-700">Video Padding</h3></div> <div class="flex items-center gap-3 mb-4"><input type="range" class="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider-thumb svelte-1m35wr6" min="0" max="200" step="5"/> <div class="min-w-[60px] text-center text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-1 rounded"> </div></div> <div class="flex gap-2 mb-4 flex-wrap"></div> <div class="mt-4"><div class="flex items-center gap-2 mb-2"><!> <div class="text-xs text-gray-600 font-medium">Preview Effect:</div></div> <div class="flex flex-col gap-2"><div class="flex items-center justify-center p-6 bg-gray-50 rounded-md"><div class="w-48 h-32 bg-gray-200 border-2 border-gray-300 rounded flex items-center justify-center transition-all duration-300"><div><span class="text-center leading-tight overflow-hidden"> <!></span></div></div></div> <div class="text-xs text-gray-600 text-center font-medium"> </div></div></div></div>');function Ha(w,t){ne(t,!0);const r=ge(()=>Ge.config.padding||60),f=[{name:"No Padding",value:0,icon:pa},{name:"Small Padding",value:30,icon:mt},{name:"Medium Padding",value:60,icon:mt},{name:"Large Padding",value:120,icon:mt},{name:"Extra Large Padding",value:200,icon:ca}];function g(G){console.log("🎨 [PaddingControl] Preset selected:",G),Ge.updatePadding(G.value)}function s(G){return e(r)===G}const c=ge(()=>Math.min(Math.round(e(r)*.2),40)),l=ge(()=>e(r)>150?"Video":"Video Area"),a=ge(()=>e(r)<=120);var R=ja(),E=n(R),b=n(E);Vt(b,{class:"w-4 h-4 text-gray-600"}),Fe(2),i(E);var h=v(E,2),A=n(h);Ze(A),A.__input=[La];var C=v(A,2),M=n(C);i(C),i(h);var le=v(h,2);xt(le,21,()=>f,yt,(G,Y)=>{const z=ge(()=>e(Y).icon);var D=Da();let de;D.__click=[Ga,g,Y];var Be=n(D);_t(Be,()=>e(z),(fe,q)=>{q(fe,{class:"w-3 h-3"})});var Xe=v(Be,2),Ne=n(Xe,!0);i(Xe),i(D),ze(fe=>{de=Ke(D,1,"flex items-center gap-1.5 px-3 py-2 text-xs border rounded-md cursor-pointer transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-opacity-50",null,de,fe),ft(D,"title",`${e(Y).name??""} (${e(Y).value??""}px)`),Q(Ne,e(Y).name)},[()=>({"border-emerald-500":s(e(Y).value),"bg-emerald-500":s(e(Y).value),"text-white":s(e(Y).value),"border-gray-300":!s(e(Y).value),"bg-white":!s(e(Y).value),"text-gray-700":!s(e(Y).value),"hover:border-emerald-400":!s(e(Y).value),"hover:bg-emerald-50":!s(e(Y).value)})]),I(G,D)}),i(le);var H=v(le,2),O=n(H),ce=n(O);It(ce,{class:"w-3 h-3 text-gray-600"}),Fe(2),i(O);var oe=v(O,2),pe=n(oe),u=n(pe),B=n(u);let W;var U=n(B),L=n(U),me=v(L);{var F=G=>{var Y=Ua(),z=v(re(Y),2),D=n(z);i(z),ze(()=>Q(D,`${e(r)??""}px`)),I(G,Y)};Le(me,G=>{e(a)&&G(F)})}i(U),i(B),i(u),i(pe);var ue=v(pe,2),V=n(ue);i(ue),i(oe),i(H),i(R),ze(G=>{$t(A,e(r)),Q(M,`${e(r)??""}px`),nt(u,`padding: ${e(c)??""}px`),W=Ke(B,1,"bg-emerald-500 text-white font-medium rounded flex items-center justify-center w-full h-full min-w-[60px] min-h-[40px]",null,W,G),Q(L,`${e(l)??""} `),Q(V,`Padding: ${e(r)??""}px`)},[()=>({"text-xs":e(r)>150,"text-sm":e(r)<=150,"p-1":e(r)>150,"p-2":e(r)>100&&e(r)<=150,"p-3":e(r)<=100})]),I(w,R),se()}st(["input","click"]);var qa=(w,t,r)=>t(e(r)),Ka=Z('<button><div class="flex-shrink-0"><!></div> <div class="flex-1 text-left"><div class="text-xs font-semibold leading-tight"> </div> <div class="text-xs opacity-80 font-medium leading-tight"> </div></div></button>'),Za=Z('<div class="flex justify-center"><div class="flex gap-3"></div></div>');function Ja(w,t){ne(t,!0);const r=ge(()=>Ge.config.outputRatio),f=[{name:"YouTube Landscape",ratio:"16:9",description:"YouTube, Bilibili, iQiyi, etc.",icon:Ct,dimensions:"1920×1080"},{name:"Instagram Square",ratio:"1:1",description:"Instagram posts, WeChat Moments",icon:Bt,dimensions:"1080×1080"},{name:"TikTok Portrait",ratio:"9:16",description:"TikTok, Douyin, Kuaishou",icon:ga,dimensions:"1080×1920"},{name:"Instagram Story",ratio:"4:5",description:"Instagram Stories, Xiaohongshu",icon:sa,dimensions:"1080×1350"}];function g(a){console.log("📐 [AspectRatioControl] Ratio selected:",a),Ge.updateOutputRatio(a.ratio)}function s(a){return e(r)===a}var c=Za(),l=n(c);xt(l,21,()=>f,yt,(a,R)=>{const E=ge(()=>e(R).icon);var b=Ka();let h;b.__click=[qa,g,R];var A=n(b),C=n(A);_t(C,()=>e(E),(oe,pe)=>{pe(oe,{class:"w-5 h-5"})}),i(A);var M=v(A,2),le=n(M),H=n(le,!0);i(le);var O=v(le,2),ce=n(O,!0);i(O),i(M),i(b),ze(oe=>{h=Ke(b,1,"flex items-center gap-3 px-3 py-2 border-2 rounded-lg cursor-pointer transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-opacity-50 min-w-[140px]",null,h,oe),ft(b,"title",e(R).description),Q(H,e(R).name),Q(ce,e(R).ratio)},[()=>({"border-purple-500":s(e(R).ratio),"bg-purple-500":s(e(R).ratio),"text-white":s(e(R).ratio),"shadow-lg":s(e(R).ratio),"border-gray-200":!s(e(R).ratio),"bg-white":!s(e(R).ratio),"text-gray-700":!s(e(R).ratio),"hover:border-purple-400":!s(e(R).ratio),"hover:bg-purple-50":!s(e(R).ratio),"hover:shadow-md":!s(e(R).ratio)})]),I(a,b)}),i(l),i(c),I(w,c),se()}st(["click"]);function Qa(w,t,r){e(t)?Ge.updateShadow(void 0):r()}function gt(w,t,r){e(t)&&r()}var er=(w,t,r)=>t(e(r)),tr=Z('<button class="flex flex-col items-center gap-2 p-3 border border-gray-300 rounded-md bg-white cursor-pointer transition-all duration-200 hover:border-amber-400 hover:bg-amber-50 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-opacity-50"><div class="w-10 h-6 bg-gray-100 rounded flex items-center justify-center"><div class="w-6 h-4 bg-amber-500 rounded-sm"></div></div> <div class="flex items-center gap-1"><!> <span class="text-xs text-gray-700 font-medium"> </span></div></button>'),ar=Z('<div class="mb-4"><h4 class="text-xs font-semibold text-gray-600 mb-3">Preset Effects</h4> <div class="grid grid-cols-2 gap-2"></div></div> <div class="mb-4"><h4 class="text-xs font-semibold text-gray-600 mb-3">Custom parameters</h4> <div class="mb-3"><div class="flex items-center gap-2 mb-1"><!> <label class="text-xs text-gray-700 font-medium" for="shadow-offset-x"> </label></div> <input id="shadow-offset-x" type="range" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider-thumb svelte-vutr7d" min="-20" max="20" step="1"/></div> <div class="mb-3"><div class="flex items-center gap-2 mb-1"><!> <label class="text-xs text-gray-700 font-medium" for="shadow-offset-y"> </label></div> <input id="shadow-offset-y" type="range" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider-thumb svelte-vutr7d" min="-20" max="20" step="1"/></div> <div class="mb-3"><div class="flex items-center gap-2 mb-1"><!> <label class="text-xs text-gray-700 font-medium" for="shadow-blur"> </label></div> <input id="shadow-blur" type="range" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider-thumb svelte-vutr7d" min="0" max="40" step="1"/></div> <div class="flex gap-3"><div class="flex-1"><div class="flex items-center gap-2 mb-1"><!> <label class="text-xs text-gray-700 font-medium" for="shadow-color">Color</label></div> <input id="shadow-color" type="color" class="w-full h-8 border border-gray-300 rounded cursor-pointer"/></div> <div class="flex-2"><label class="text-xs text-gray-700 font-medium block mb-1" for="shadow-opacity"> </label> <input id="shadow-opacity" type="range" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider-thumb svelte-vutr7d" min="0" max="1" step="0.05"/></div></div></div> <div class="mt-4"><div class="flex items-center gap-2 mb-2"><!> <h4 class="text-xs font-semibold text-gray-600">Preview Effect</h4></div> <div class="flex justify-center p-4 bg-gray-50 rounded-md"><div class="w-20 h-12 bg-amber-500 rounded flex items-center justify-center text-white text-xs font-semibold">Video Area</div></div></div>',1),rr=Z('<div class="text-center text-gray-600 text-xs p-6 bg-gray-50 rounded-md">Turn on shadow switch to configure shadow effects</div>'),or=Z('<div class="p-4 border border-gray-200 rounded-lg bg-white"><div class="flex justify-between items-center mb-4"><div class="flex items-center gap-2"><!> <h3 class="text-sm font-semibold text-gray-700">Video Shadow</h3></div> <label class="relative inline-block w-11 h-6"><input type="checkbox" class="opacity-0 w-0 h-0"/> <span></span></label></div> <!></div>');function ir(w,t){ne(t,!0);const r=ge(()=>Ge.config.shadow),f=ge(()=>!!e(r));let g=X(8),s=X(8),c=X(16),l=X("#000000"),a=X(.3);const R=[{name:"Light Shadow",offsetX:4,offsetY:4,blur:8,color:"#000000",opacity:.2,icon:fa},{name:"Standard Shadow",offsetX:8,offsetY:8,blur:16,color:"#000000",opacity:.3,icon:ua},{name:"Deep Shadow",offsetX:12,offsetY:12,blur:24,color:"#000000",opacity:.4,icon:Et},{name:"Distant Shadow",offsetX:16,offsetY:16,blur:32,color:"#000000",opacity:.25,icon:ma}];function E(){const W={offsetX:e(g),offsetY:e(s),blur:e(c),color:h(e(l),e(a))};Ge.updateShadow(W)}function b(W){console.log("🎨 [ShadowControl] Applying preset:",W.name),m(g,W.offsetX,!0),m(s,W.offsetY,!0),m(c,W.blur,!0),m(l,W.color,!0),m(a,W.opacity,!0),e(f)&&E()}function h(W,U){const L=parseInt(W.slice(1,3),16),me=parseInt(W.slice(3,5),16),F=parseInt(W.slice(5,7),16);return`rgba(${L}, ${me}, ${F}, ${U})`}tt(()=>{if(e(r)){m(g,e(r).offsetX,!0),m(s,e(r).offsetY,!0),m(c,e(r).blur,!0);const W=e(r).color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);if(W){const[,U,L,me,F]=W;m(l,`#${parseInt(U).toString(16).padStart(2,"0")}${parseInt(L).toString(16).padStart(2,"0")}${parseInt(me).toString(16).padStart(2,"0")}`),m(a,F?parseFloat(F):1,!0)}}});var A=or(),C=n(A),M=n(C),le=n(M);va(le,{class:"w-4 h-4 text-gray-600"}),Fe(2),i(M);var H=v(M,2),O=n(H);Ze(O),O.__change=[Qa,f,E];var ce=v(O,2);let oe;i(H),i(C);var pe=v(C,2);{var u=W=>{var U=ar(),L=re(U),me=v(n(L),2);xt(me,21,()=>R,yt,(J,Me)=>{const Qe=ge(()=>e(Me).icon);var Ae=tr();Ae.__click=[er,b,Me];var De=n(Ae),et=n(De);i(De);var lt=v(De,2),at=n(lt);_t(at,()=>e(Qe),(Ye,je)=>{je(Ye,{class:"w-3 h-3 text-gray-600"})});var dt=v(at,2),Ue=n(dt,!0);i(dt),i(lt),i(Ae),ze(Ye=>{ft(Ae,"title",e(Me).name),nt(et,`
                  box-shadow: ${e(Me).offsetX??""}px ${e(Me).offsetY??""}px ${e(Me).blur??""}px ${Ye??""};
                `),Q(Ue,e(Me).name)},[()=>h(e(Me).color,e(Me).opacity)]),I(J,Ae)}),i(me),i(L);var F=v(L,2),ue=v(n(F),2),V=n(ue),G=n(V);mt(G,{class:"w-3 h-3 text-gray-600"});var Y=v(G,2),z=n(Y);i(Y),i(V);var D=v(V,2);Ze(D),D.__input=[gt,f,E],i(ue);var de=v(ue,2),Be=n(de),Xe=n(Be);mt(Xe,{class:"w-3 h-3 text-gray-600 rotate-90"});var Ne=v(Xe,2),fe=n(Ne);i(Ne),i(Be);var q=v(Be,2);Ze(q),q.__input=[gt,f,E],i(de);var xe=v(de,2),ye=n(xe),Ie=n(ye);Et(Ie,{class:"w-3 h-3 text-gray-600"});var Ve=v(Ie,2),Je=n(Ve);i(Ve),i(ye);var ee=v(ye,2);Ze(ee),ee.__input=[gt,f,E],i(xe);var _e=v(xe,2),te=n(_e),ke=n(te),ve=n(ke);oa(ve,{class:"w-3 h-3 text-gray-600"}),Fe(2),i(ke);var K=v(ke,2);Ze(K),K.__input=[gt,f,E],i(te);var j=v(te,2),ie=n(j),d=n(ie);i(ie);var p=v(ie,2);Ze(p),p.__input=[gt,f,E],i(j),i(_e),i(F);var $=v(F,2),S=n($),y=n(S);It(y,{class:"w-3 h-3 text-gray-600"}),Fe(2),i(S);var N=v(S,2),he=n(N);i(N),i($),ze((J,Me)=>{Q(z,`X offset: ${e(g)??""}px`),Q(fe,`Y offset: ${e(s)??""}px`),Q(Je,`Blur: ${e(c)??""}px`),Q(d,`Opacity: ${J??""}%`),nt(he,`
            box-shadow: ${e(g)??""}px ${e(s)??""}px ${e(c)??""}px ${Me??""};
          `)},[()=>Math.round(e(a)*100),()=>h(e(l),e(a))]),ut(D,()=>e(g),J=>m(g,J)),ut(q,()=>e(s),J=>m(s,J)),ut(ee,()=>e(c),J=>m(c,J)),ut(K,()=>e(l),J=>m(l,J)),ut(p,()=>e(a),J=>m(a,J)),I(W,U)},B=W=>{var U=rr();I(W,U)};Le(pe,W=>{e(f)?W(u):W(B,!1)})}i(A),ze(W=>{Qt(O,e(f)),oe=Ke(ce,1,"absolute cursor-pointer top-0 left-0 right-0 bottom-0 bg-gray-300 transition-all duration-300 rounded-full before:absolute before:content-[''] before:h-4 before:w-4 before:left-1 before:bottom-1 before:bg-white before:transition-all before:duration-300 before:rounded-full",null,oe,W)},[()=>({"bg-amber-500":e(f),"before:translate-x-5":e(f)})]),I(w,A),se()}st(["change","click","input"]);var nr=()=>window.open("/drive.html","_blank"),sr=Z('<div class="flex h-screen bg-gray-50"><div class="flex-1 min-h-0 flex flex-col h-full overflow-hidden"><div class="flex-shrink-0 p-6 border-b border-gray-200 bg-white"><div class="flex items-center justify-between relative"><div class="flex items-center gap-3"><div class="flex items-center gap-2"><!> <h1 class="text-xl font-bold text-gray-800">Screen Recorder Studio</h1></div> <span class="px-2 py-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold rounded-full shadow-sm">PRO TRIAL</span></div> <div class="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2"><!></div> <button class="p-2 rounded-lg border border-gray-300 hover:border-blue-400 hover:bg-white/70 hover:shadow-sm transition-all duration-200 group" title="Open Recording File Manager"><!></button></div></div> <div class="flex-1 min-h-0 flex flex-col p-6 relative"><div class="flex-1 min-h-0 flex items-stretch justify-center"><!></div></div></div> <div class="w-100 bg-white border-l border-gray-200 flex flex-col h-full"><div class="flex-shrink-0 p-6 border-b border-gray-200"><!></div> <div class="flex-1 overflow-y-auto"><div class="p-6 space-y-6"><div class="col-span-2 lg:col-span-1"><!></div> <div><!></div> <div><!></div> <div class="col-span-2 lg:col-span-1"></div> <div class="col-span-2 lg:col-span-1"><!></div></div></div></div></div>');function Er(w,t){ne(t,!0);let r=X(""),f=X(bt([])),g=null,s=!1,c=null,l=X(0),a=X(0),R=X(0),E=X(0),b=X(0),h=X(null),A=null,C=X(0),M=X(0),le=null;const H=ge(()=>Ft.state.status);Wt(()=>{console.log("📱 Sidepanel mounted with Worker system");try{const _e=new URLSearchParams(location.search).get("id")||"";if(m(r,_e,!0),_e&&e(f).length===0){console.log("� [Studio] Opening OPFS recording by dirId:",_e);const te=new Worker(new URL(""+new URL("../workers/opfs-reader-worker-BDbac1fo.js",import.meta.url).href,import.meta.url),{type:"module"});g=te,te.onmessage=ke=>{const{type:ve,summary:K,meta:j,start:ie,count:d,chunks:p,code:$,message:S,keyframeInfo:y}=ke.data||{};if(s&&ve==="range"){console.log("[prefetch] Reader returned range (prefetch):",{start:ie,count:d,chunks:p?.length}),s=!1,c?.({start:ie,chunks:p}),c=null;return}if(ve==="ready"){console.log("✅ [OPFSReader] Ready:",{summary:K,meta:j,keyframeInfo:y}),K?.durationMs&&m(l,K.durationMs,!0),K?.totalChunks&&m(E,K.totalChunks,!0),y&&m(h,y,!0),console.log("[progress] Parent component - OPFS data loaded:",{durationMs:e(l),globalTotalFrames:e(E),summary:K,meta:j,keyframeInfo:e(h)});const N=Math.min(90,e(E));console.log("[progress] Parent component - requesting initial frames:",{start:0,count:N,totalFrames:e(E)}),te.postMessage({type:"getRange",start:0,count:N})}else if(ve==="range")if(console.log("📦 [OPFSReader] Received range:",{start:ie,count:d}),Array.isArray(p)&&p.length>0){m(f,p,!0),m(b,typeof ie=="number"?ie:0,!0);const N=K?.firstTimestamp||p[0]?.timestamp||0,he=p[0]?.timestamp||0,J=p[p.length-1]?.timestamp||0;m(a,Math.floor((he-N)/1e3),!0),m(R,Math.floor((J-N)/1e3),!0),console.log("[progress] Parent component - window data updated:",{chunksLength:p.length,windowStartIndex:e(b),windowStartMs:e(a),windowEndMs:e(R),firstGlobalTimestamp:N,windowStartTimestamp:he,windowEndTimestamp:J,relativeStartMs:e(a),relativeEndMs:e(R)}),Ft.updateStatus("completed"),Ft.setEngine("webcodecs"),console.log("🎬 [Studio] Prepared",p.length,"chunks from OPFS for preview")}else console.warn("⚠️ [OPFSReader] Empty range received");else ve==="error"&&console.error("❌ [OPFSReader] Error:",$,S)},te.postMessage({type:"open",dirId:_e})}}catch(ee){console.error("❌ [Studio] Failed to open OPFS recording:",ee)}try{if(A){const ee=A.getBoundingClientRect();m(C,Math.floor(ee.width),!0),m(M,Math.floor(ee.height),!0),le=new ResizeObserver(_e=>{const te=_e[0]?.contentRect;te&&(m(C,Math.floor(te.width),!0),m(M,Math.floor(te.height),!0))}),le.observe(A)}}catch(ee){console.warn("[layout] ResizeObserver setup failed:",ee)}return()=>{try{g?.postMessage({type:"close"})}catch{}g?.terminate?.(),g=null;try{le?.disconnect?.()}catch{}le=null}});async function O(ee){const{centerMs:_e,beforeMs:te,afterMs:ke}=ee;return g?s?(console.warn("[prefetch] Already building; skip duplicate prefetch request"),{chunks:[],windowStartIndex:0}):new Promise(ve=>{s=!0;let K=!1;c=({start:S,chunks:y})=>{K||(K=!0,ve({chunks:y||[],windowStartIndex:S??0}))};const j=30,ie=Math.floor(_e/1e3*j);let d,p;if(e(h)&&e(h).indices.length>0){let S=e(h).indices[0];for(let y=0;y<e(h).indices.length;y++){const N=e(h).indices[y];if(N<=ie)S=N;else break}d=Math.max(0,S)}else d=Math.max(0,ie);const $=Math.max(1,Math.floor(ke/1e3*j));p=Math.min($,Math.max(1,e(E)-d));try{g.postMessage({type:"getRange",start:d,count:p})}catch(S){console.warn("[prefetch] Failed to post prefetch request:",S),s=!1,c=null,ve({chunks:[],windowStartIndex:0});return}setTimeout(()=>{K||(console.warn("[prefetch] Prefetch timeout, returning empty"),K=!0,s=!1,c=null,ve({chunks:[],windowStartIndex:0}))},4e3)}):(console.warn("[prefetch] No reader worker; returning empty prefetch result"),{chunks:[],windowStartIndex:0})}Ht(()=>{console.log("📱 Sidepanel unmounted, cleaning up...")});var ce=sr();qt(ee=>{Kt.title="Screen Recording Studio"});var oe=n(ce),pe=n(oe),u=n(pe),B=n(u),W=n(B),U=n(W);zt(U,{class:"w-6 h-6 text-blue-600"}),Fe(2),i(W),Fe(2),i(B);var L=v(B,2),me=n(L);Ja(me,{}),i(L);var F=v(L,2);F.__click=[nr];var ue=n(F);na(ue,{class:"w-5 h-5 text-gray-600 group-hover:text-blue-600 transition-colors duration-200"}),i(F),i(u),i(pe);var V=v(pe,2),G=n(V),Y=n(G);{let ee=ge(()=>e(H)==="completed"||e(H)==="idle");ya(Y,{get encodedChunks(){return e(f)},get isRecordingComplete(){return e(ee)},get displayWidth(){return e(C)},get displayHeight(){return e(M)},showControls:!0,showTimeline:!0,get durationMs(){return e(l)},get windowStartMs(){return e(a)},get windowEndMs(){return e(R)},get totalFramesAll(){return e(E)},get windowStartIndex(){return e(b)},onRequestWindow:({centerMs:_e,beforeMs:te,afterMs:ke})=>{if(console.log("[progress] Parent component - window request:",{centerMs:_e,beforeMs:te,afterMs:ke}),!g){console.warn("[progress] No worker available for window request");return}const ve=30,K=Math.floor(_e/1e3*ve);let j,ie;if(e(h)&&e(h).indices.length>0){let d=e(h).indices[0];for(let S=0;S<e(h).indices.length;S++){const y=e(h).indices[S];if(y<=K)d=y;else break}const p=e(h).avgInterval||30,$=Math.min(120,Math.max(60,p*2));j=Math.max(0,d),ie=Math.min($,e(E)-j),console.log("[progress] Parent component - keyframe-based window (prev):",{targetFrameIndex:K,prevKeyframeIndex:d,avgKeyframeInterval:p,windowSize:$,startFrame:j,frameCount:ie,totalKeyframes:e(h).indices.length,firstKeyframes:e(h).indices.slice(0,5),lastKeyframes:e(h).indices.slice(-5),keyframesAroundTarget:e(h).indices.filter(S=>Math.abs(S-K)<=100)})}else{const d=Math.floor(te/1e3*ve),p=Math.floor(ke/1e3*ve);j=Math.max(0,K-d),ie=Math.min(e(E)-1,K+p)-j+1,console.log("[progress] Parent component - time-based window:",{targetFrameIndex:K,framesBefore:d,framesAfter:p,startFrame:j,frameCount:ie})}if(te===0&&j<=e(b)){console.log("[progress] Ignoring non-forward window request (startFrame<=current):",{startFrame:j,windowStartIndex:e(b),beforeMs:te});return}ie>0&&j<e(E)?(console.log("[progress] Using optimized frame range request"),g.postMessage({type:"getRange",start:j,count:ie})):(console.log("[progress] Falling back to time range request"),g.postMessage({type:"getWindowByTime",centerMs:_e,beforeMs:te,afterMs:ke}))},fetchWindowData:O,className:"worker-video-preview w-full h-full"})}i(G),Tt(G,ee=>A=ee,()=>A),i(V),i(oe);var z=v(oe,2),D=n(z),de=n(D);{let ee=ge(()=>e(H)==="completed"||e(H)==="idle");za(de,{get encodedChunks(){return e(f)},get isRecordingComplete(){return e(ee)},get totalFramesAll(){return e(E)},get opfsDirId(){return e(r)},className:"export-panel"})}i(D);var Be=v(D,2),Xe=n(Be),Ne=n(Xe),fe=n(Ne);ia(fe,{}),i(Ne);var q=v(Ne,2),xe=n(q);Oa(xe,{}),i(q);var ye=v(q,2),Ie=n(ye);Ha(Ie,{}),i(ye);var Ve=v(ye,4),Je=n(Ve);ir(Je,{}),i(Ve),i(Xe),i(Be),i(z),i(ce),I(w,ce),se()}st(["click"]);export{Er as component};
