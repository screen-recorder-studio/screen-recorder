const OFFSCREEN_JUSTIFICATIONS = {
  TESTING: "Used for testing extension functionality in development environment",
  AUDIO_PLAYBACK: "Play audio notifications and sounds in the background without user interaction",
  IFRAME_SCRIPTING: "Embed and script iframes to modify their content for data processing",
  DOM_SCRAPING: "Embed iframes and extract information from their DOM structure",
  BLOBS: "Process and manipulate binary data using Blob objects and URL.createObjectURL()",
  DOM_PARSER: "Parse HTML and XML content using the DOMParser API for data extraction",
  USER_MEDIA: "Access and process user media streams from camera and microphone",
  DISPLAY_MEDIA: "Capture and process screen sharing and display media streams",
  WEB_RTC: "Establish peer-to-peer connections and handle real-time communication",
  CLIPBOARD: "Read from and write to the system clipboard for data transfer",
  LOCAL_STORAGE: "Access browser localStorage for persistent data storage",
  WORKERS: "Spawn Web Workers for intensive background data processing",
  BATTERY_STATUS: "Monitor device battery status for power management features",
  MATCH_MEDIA: "Query media features and respond to viewport changes",
  GEOLOCATION: "Access user location information for location-based features"
};
function getRecommendedJustification(reason) {
  return OFFSCREEN_JUSTIFICATIONS[reason];
}
function getRecommendedJustificationForReasons(reasons) {
  if (reasons.length === 0) {
    return "Background processing for extension functionality";
  }
  if (reasons.length === 1) {
    return getRecommendedJustification(reasons[0]);
  }
  const capabilities = reasons.map((reason) => {
    switch (reason) {
      case "TESTING":
        return "testing";
      case "AUDIO_PLAYBACK":
        return "audio playback";
      case "IFRAME_SCRIPTING":
        return "iframe scripting";
      case "DOM_SCRAPING":
        return "DOM scraping";
      case "BLOBS":
        return "blob processing";
      case "DOM_PARSER":
        return "HTML/XML parsing";
      case "USER_MEDIA":
        return "user media access";
      case "DISPLAY_MEDIA":
        return "screen capture";
      case "WEB_RTC":
        return "WebRTC communication";
      case "CLIPBOARD":
        return "clipboard operations";
      case "LOCAL_STORAGE":
        return "local storage access";
      case "WORKERS":
        return "background processing";
      case "BATTERY_STATUS":
        return "battery monitoring";
      case "MATCH_MEDIA":
        return "media queries";
      case "GEOLOCATION":
        return "location services";
      default:
        return reason.toLowerCase();
    }
  });
  return `Extension requires ${capabilities.join(", ")} capabilities for core functionality`;
}
function isOffscreenSupported() {
  return typeof chrome !== "undefined" && "offscreen" in chrome && typeof chrome.offscreen === "object";
}
async function hasOffscreenDocument() {
  if (!isOffscreenSupported()) {
    return false;
  }
  try {
    if ("hasDocument" in chrome.offscreen && typeof chrome.offscreen.hasDocument === "function") {
      return await chrome.offscreen.hasDocument();
    }
    if ("getContexts" in chrome.runtime && typeof chrome.runtime.getContexts === "function") {
      const contexts = await chrome.runtime.getContexts({
        contextTypes: ["OFFSCREEN_DOCUMENT"]
      });
      return contexts.length > 0;
    }
    if (typeof globalThis !== "undefined" && "clients" in globalThis) {
      const clientsAPI = globalThis.clients;
      if (clientsAPI && typeof clientsAPI.matchAll === "function") {
        const matchedClients = await clientsAPI.matchAll();
        return matchedClients.some(
          (client) => client.url && client.url.includes(chrome.runtime.id)
        );
      }
    }
    return false;
  } catch (error) {
    console.warn("[OffscreenManager] Error checking document existence:", error);
    return false;
  }
}
async function createOffscreenDocument(options) {
  if (!isOffscreenSupported()) {
    return {
      success: false,
      error: "Offscreen API not supported"
    };
  }
  try {
    const url = chrome.runtime.getURL(options.url || "offscreen.html");
    await chrome.offscreen.createDocument({
      url,
      reasons: options.reasons,
      justification: options.justification
    });
    console.log("[OffscreenManager] Document created successfully:", url);
    return { success: true };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("[OffscreenManager] Failed to create document:", errorMessage);
    return {
      success: false,
      error: errorMessage
    };
  }
}
async function closeOffscreenDocument() {
  if (!isOffscreenSupported()) {
    return {
      success: false,
      error: "Offscreen API not supported"
    };
  }
  try {
    const exists = await hasOffscreenDocument();
    if (!exists) {
      return { success: true };
    }
    await chrome.offscreen.closeDocument();
    console.log("[OffscreenManager] Document closed successfully");
    return { success: true };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("[OffscreenManager] Failed to close document:", errorMessage);
    return {
      success: false,
      error: errorMessage
    };
  }
}
async function ensureOffscreenDocument(options = {}) {
  if (!isOffscreenSupported()) {
    return {
      success: false,
      error: "Offscreen API not supported"
    };
  }
  try {
    const exists = await hasOffscreenDocument();
    if (exists && !options.forceRecreate) {
      return { success: true };
    }
    if (exists && options.forceRecreate) {
      const closeResult = await closeOffscreenDocument();
      if (!closeResult.success) {
        return closeResult;
      }
    }
    const reasons = options.reasons || ["BLOBS"];
    const createOptions = {
      url: options.url || "offscreen.html",
      reasons,
      justification: options.justification || getRecommendedJustificationForReasons(reasons)
    };
    return await createOffscreenDocument(createOptions);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("[OffscreenManager] Failed to ensure document:", errorMessage);
    return {
      success: false,
      error: errorMessage
    };
  }
}
async function sendToOffscreen(message, options = {}) {
  const reasons = options.reasons || ["BLOBS"];
  const ensureOptions = {
    ...options,
    reasons,
    justification: options.justification || getRecommendedJustificationForReasons(reasons)
  };
  const ensureResult = await ensureOffscreenDocument(ensureOptions);
  if (!ensureResult.success) {
    throw new Error(`Failed to ensure offscreen document: ${ensureResult.error}`);
  }
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}
console.log("Screen Recorder Extension Service Worker loaded");
const tabStates = /* @__PURE__ */ new Map();
async function computeCapabilities(tabId) {
  let url = "";
  try {
    const tab = await chrome.tabs.get(tabId);
    url = tab?.url || "";
  } catch (e) {
  }
  const result = {
    contentScriptAvailable: false,
    reason: "unknown",
    url
  };
  if (!url) {
    return result;
  }
  const lower = url.toLowerCase();
  const isForbiddenScheme = lower.startsWith("chrome://") || lower.startsWith("chrome-extension://") || lower.startsWith("edge://") || lower.startsWith("about:");
  const isWebStore = lower.startsWith("https://chrome.google.com/webstore") || lower.includes("chrome.google.com/webstore");
  if (isForbiddenScheme || isWebStore) {
    result.reason = "forbidden_url";
    return result;
  }
  if (lower.startsWith("file://")) {
    const allowed = await new Promise((resolve) => {
      try {
        if (chrome.extension?.isAllowedFileSchemeAccess) {
          chrome.extension.isAllowedFileSchemeAccess(resolve);
        } else {
          resolve(false);
        }
      } catch {
        resolve(false);
      }
    });
    if (!allowed) {
      result.reason = "no_file_access";
      return result;
    }
  }
  try {
    await chrome.scripting.executeScript({ target: { tabId }, func: () => true });
    return { contentScriptAvailable: true, url };
  } catch (e) {
    result.reason = "runtime_denied";
    return result;
  }
}
async function broadcastStateWithCapabilities(tabId) {
  if (!tabStates.has(tabId)) tabStates.set(tabId, { mode: "element", selecting: false, recording: false, uiSelectedMode: "area" });
  const state = tabStates.get(tabId);
  const capabilities = await computeCapabilities(tabId);
  broadcastToTab(tabId, { type: "STATE_UPDATE", state: { ...state, capabilities } });
}
chrome.runtime.onInstalled.addListener((details) => {
  console.log("Extension installed:", details.reason);
  if (details.reason === "install") {
    chrome.tabs.create({ url: "/welcome.html" });
  }
  chrome.storage.local.set({
    settings: {
      videoQuality: "medium",
      audioEnabled: true,
      autoDownload: true,
      filenameTemplate: "screen-recording-{timestamp}",
      maxDuration: 3600,
      // 1小时
      preferredSources: ["screen", "window", "tab"]
    }
  });
  try {
    if (chrome.sidePanel?.setPanelBehavior) {
      chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
    }
  } catch (e) {
    console.warn("setPanelBehavior(false) failed", e);
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Received message:", message.action || message.type, message);
  if (message?.target === "offscreen-doc") {
    return false;
  }
  if (message.type) {
    const tabId = sender.tab?.id ?? message.tabId;
    const globalTypes = /* @__PURE__ */ new Set(["REQUEST_START_RECORDING", "REQUEST_STOP_RECORDING", "REQUEST_RECORDING_STATE", "REQUEST_TOGGLE_PAUSE", "OFFSCREEN_START_RECORDING", "OFFSCREEN_STOP_RECORDING", "REQUEST_OFFSCREEN_PING", "GET_RECORDING_STATE", "RECORDING_COMPLETE", "OPFS_RECORDING_READY", "STREAM_START", "STREAM_META", "STREAM_END", "STREAM_ERROR"]);
    let state;
    if (!globalTypes.has(message.type)) {
      if (!tabId) return;
      if (!tabStates.has(tabId)) tabStates.set(tabId, { mode: "element", selecting: false, recording: false, uiSelectedMode: "area" });
      state = tabStates.get(tabId);
    }
    switch (message.type) {
      case "GET_STATE":
        (async () => {
          const capabilities = await computeCapabilities(tabId);
          try {
            sendResponse({ ok: true, state: { ...state, capabilities } });
          } catch (e) {
          }
        })();
        return true;
      case "SET_MODE":
        state.mode = message.mode === "region" ? "region" : "element";
        broadcastStateWithCapabilities(tabId);
        try {
          sendResponse({ ok: true, state });
        } catch (e) {
        }
        return true;
      case "SET_SELECTED_MODE": {
        state.uiSelectedMode = message.uiMode === "element" || message.uiMode === "area" || message.uiMode === "camera" || message.uiMode === "tab" || message.uiMode === "window" || message.uiMode === "screen" ? message.uiMode : state.uiSelectedMode || "area";
        if (message.uiMode === "area") state.mode = "region";
        if (message.uiMode === "element") state.mode = "element";
        broadcastStateWithCapabilities(tabId);
        try {
          sendResponse({ ok: true, state });
        } catch (e) {
        }
        return true;
      }
      case "ENTER_SELECTION":
        state.selecting = true;
        ensureContentInjected(tabId).then(() => {
          chrome.tabs.sendMessage(tabId, { type: "ENTER_SELECTION", mode: state.mode });
        });
        broadcastStateWithCapabilities(tabId);
        try {
          sendResponse({ ok: true, state });
        } catch (e) {
        }
        return true;
      case "EXIT_SELECTION":
        state.selecting = false;
        chrome.tabs.sendMessage(tabId, { type: "EXIT_SELECTION" });
        broadcastStateWithCapabilities(tabId);
        try {
          sendResponse({ ok: true, state });
        } catch (e) {
        }
        return true;
      case "START_CAPTURE":
        state.recording = true;
        ensureContentInjected(tabId).then(() => {
          chrome.tabs.sendMessage(tabId, { type: "START_CAPTURE" });
        });
        broadcastStateWithCapabilities(tabId);
        try {
          sendResponse({ ok: true, state });
        } catch (e) {
        }
        return true;
      case "STOP_CAPTURE":
        state.recording = false;
        chrome.tabs.sendMessage(tabId, { type: "STOP_CAPTURE" });
        broadcastStateWithCapabilities(tabId);
        try {
          sendResponse({ ok: true, state });
        } catch (e) {
        }
        return true;
      case "CLEAR_SELECTION":
        chrome.tabs.sendMessage(tabId, { type: "CLEAR_SELECTION" });
        broadcastStateWithCapabilities(tabId);
        try {
          sendResponse({ ok: true, state });
        } catch (e) {
        }
        return true;
      case "DOWNLOAD_VIDEO":
        chrome.tabs.sendMessage(tabId, { type: "DOWNLOAD_VIDEO" });
        try {
          sendResponse({ ok: true });
        } catch (e) {
        }
        return true;
      case "CONTENT_REPORT": {
        (async () => {
          try {
            const partial = message.partial || {};
            let mergedCaps = void 0;
            if (partial.capabilities) {
              const base = await computeCapabilities(tabId);
              mergedCaps = { ...base, ...partial.capabilities };
            }
            const nextState = mergedCaps ? { ...state, ...partial, capabilities: mergedCaps } : { ...state, ...partial };
            broadcastToTab(tabId, { type: "STATE_UPDATE", state: nextState });
            try {
              sendResponse({ ok: true });
            } catch {
            }
          } catch (e) {
            console.warn("[Background] CONTENT_REPORT handling error", e);
            try {
              sendResponse({ ok: false });
            } catch {
            }
          }
        })();
        return true;
      }
      case "ELEMENT_RECORDING_COMPLETE":
        handleElementRecordingComplete(message, sendResponse);
        return true;
      case "RECORDING_COMPLETE": {
        console.log("[stop-share] background: RECORDING_COMPLETE → mark stopped");
        try {
          currentRecording.isRecording = false;
          currentRecording.isPaused = false;
        } catch {
        }
        try {
          void stopBadgeTimer();
        } catch {
        }
        try {
          const p = chrome.runtime.sendMessage({ type: "STATE_UPDATE", state: { recording: false } });
          if (p && typeof p.catch === "function") p.catch(() => {
          });
        } catch (e) {
          console.warn("[stop-share] background: failed to broadcast STATE_UPDATE for RECORDING_COMPLETE", e);
        }
        try {
          sendResponse({ ok: true });
        } catch (e) {
        }
        return true;
      }
      case "OPFS_RECORDING_READY": {
        try {
          const id = message?.id;
          const doOpen = () => {
            console.log("[stop-share] background: OPFS_RECORDING_READY → mark stopped");
            try {
              currentRecording.isRecording = false;
              currentRecording.isPaused = false;
            } catch {
            }
            try {
              void stopBadgeTimer();
            } catch {
            }
            try {
              const p = chrome.runtime.sendMessage({ type: "STATE_UPDATE", state: { recording: false } });
              if (p && typeof p.catch === "function") p.catch(() => {
              });
            } catch {
            }
            const targetUrl = chrome.runtime.getURL(`studio.html?id=${encodeURIComponent(id)}`);
            chrome.tabs.create({ url: targetUrl }, () => {
              const err = chrome.runtime.lastError;
              if (err) console.error("[Background] Failed to open Studio tab:", err.message);
            });
          };
          if (currentRecording && currentRecording.isRecording) {
            setTimeout(() => {
              try {
                if (currentRecording && currentRecording.isRecording) {
                  console.log("[Background] OPFS_RECORDING_READY delayed but recording still active; skipping Studio open", { id });
                  try {
                    sendResponse({ ok: true, skipped: true, reason: "active_recording" });
                  } catch {
                  }
                } else {
                  doOpen();
                  try {
                    sendResponse({ ok: true, delayed: true });
                  } catch {
                  }
                }
              } catch (e) {
                console.warn("[Background] delayed OPFS_RECORDING_READY handling error", e);
                try {
                  sendResponse({ ok: false, error: e && e.message || String(e) });
                } catch {
                }
              }
            }, 600);
            return true;
          }
          doOpen();
          try {
            sendResponse({ ok: true });
          } catch (e) {
          }
        } catch (e) {
          console.warn("[Background] OPFS_RECORDING_READY handling error", e);
          try {
            sendResponse({ ok: false, error: e && e.message || String(e) });
          } catch (_) {
          }
        }
        return true;
      }
      // Stream signaling from content via sendMessage (no Port)
      case "STREAM_START": {
        console.log("[stop-share] background: STREAM_START", { tabId, from: tabId ? "tab" : "offscreen" });
        try {
          currentRecording.isRecording = true;
          currentRecording.isPaused = false;
        } catch {
        }
        try {
          if (!badgeInterval) {
            void startBadgeTimer();
          } else {
            void resumeBadgeTimer();
          }
        } catch {
        }
        if (tabId) {
          try {
            state.recording = true;
          } catch {
          }
          broadcastToTab(tabId, { ...message, tabId });
          void broadcastStateWithCapabilities(tabId);
        } else {
          try {
            chrome.runtime.sendMessage({ type: "STATE_UPDATE", state: { recording: true } }).catch(() => {
            });
          } catch {
          }
        }
        try {
          sendResponse({ ok: true });
        } catch (e) {
        }
        return true;
      }
      case "STREAM_META": {
        const meta = message?.meta || {};
        if (meta && meta.preparing && typeof meta.countdown === "number") {
          try {
            chrome.action.setBadgeBackgroundColor({ color: "#fb8c00" });
          } catch {
          }
          try {
            chrome.action.setBadgeText({ text: String(Math.max(0, Math.floor(meta.countdown))) });
          } catch {
          }
          try {
            sendResponse({ ok: true });
          } catch {
          }
          return true;
        }
        if (meta && typeof meta.paused === "boolean") {
          try {
            currentRecording.isPaused = !!meta.paused;
          } catch {
          }
          try {
            meta.paused ? void pauseBadgeTimer() : void resumeBadgeTimer();
          } catch {
          }
        }
        if (tabId) {
          broadcastToTab(tabId, { ...message, tabId });
        } else {
          try {
            chrome.runtime.sendMessage({ ...message }).catch(() => {
            });
          } catch {
          }
        }
        try {
          sendResponse({ ok: true });
        } catch (e) {
        }
        return true;
      }
      case "STREAM_END_REQUEST": {
        broadcastToTab(tabId, { ...message, tabId });
        try {
          sendResponse({ ok: true });
        } catch (e) {
        }
        return true;
      }
      case "STREAM_END": {
        console.log("[stop-share] background: STREAM_END", { tabId, from: tabId ? "tab" : "offscreen" });
        try {
          currentRecording.isRecording = false;
          currentRecording.isPaused = false;
        } catch {
        }
        try {
          void stopBadgeTimer();
        } catch {
        }
        if (tabId) {
          try {
            state.recording = false;
          } catch {
          }
          broadcastToTab(tabId, { ...message, tabId });
          void broadcastStateWithCapabilities(tabId);
        } else {
          try {
            chrome.runtime.sendMessage({ type: "STATE_UPDATE", state: { recording: false } }).catch(() => {
            });
          } catch {
          }
        }
        try {
          sendResponse({ ok: true });
        } catch (e) {
        }
        return true;
      }
      case "STREAM_ERROR": {
        console.log("[stop-share] background: STREAM_ERROR", { tabId, from: tabId ? "tab" : "offscreen" });
        try {
          currentRecording.isRecording = false;
          currentRecording.isPaused = false;
        } catch {
        }
        try {
          void stopBadgeTimer();
        } catch {
        }
        if (tabId) {
          try {
            state.recording = false;
          } catch {
          }
          broadcastToTab(tabId, { ...message, tabId });
          void broadcastStateWithCapabilities(tabId);
        } else {
          try {
            chrome.runtime.sendMessage({ type: "STATE_UPDATE", state: { recording: false } }).catch(() => {
            });
          } catch {
          }
        }
        try {
          sendResponse({ ok: true });
        } catch (e) {
        }
        return true;
      }
      case "REQUEST_START_RECORDING":
      case "OFFSCREEN_START_RECORDING": {
        (async () => {
          console.log("OFFSCREEN_START_RECORDING received:", message?.payload?.options ?? message?.payload);
          await startRecordingViaOffscreen(message?.payload?.options ?? message?.payload);
          try {
            sendResponse({ ok: true });
          } catch (e) {
          }
        })();
        return true;
      }
      case "REQUEST_STOP_RECORDING":
      case "OFFSCREEN_STOP_RECORDING": {
        (async () => {
          console.log("[stop-share] background: REQUEST_STOP_RECORDING received");
          await stopRecordingViaOffscreen();
          try {
            sendResponse({ ok: true });
          } catch (e) {
          }
        })();
        return true;
      }
      case "REQUEST_OFFSCREEN_PING": {
        (async () => {
          await ensureOffscreenDocument({ url: "offscreen.html", reasons: ["DISPLAY_MEDIA", "WORKERS", "BLOBS"] });
          sendToOffscreen({ target: "offscreen-doc", type: "OFFSCREEN_PING", when: Date.now() });
          try {
            sendResponse({ ok: true });
          } catch (e) {
          }
        })();
        return true;
      }
      case "REQUEST_RECORDING_STATE":
      case "GET_RECORDING_STATE": {
        try {
          sendResponse({ ok: true, state: currentRecording });
        } catch (e) {
        }
        return true;
      }
      case "REQUEST_TOGGLE_PAUSE": {
        (async () => {
          try {
            const tgtTabId = sender.tab?.id ?? message.tabId;
            const tabState = tgtTabId != null ? tabStates.get(tgtTabId) : void 0;
            const isElementOrRegion = !!tabState && (tabState.mode === "element" || tabState.mode === "region");
            if (tgtTabId != null && isElementOrRegion) {
              try {
                chrome.tabs.sendMessage(tgtTabId, { type: "TOGGLE_PAUSE" });
              } catch {
              }
              try {
                sendResponse({ ok: true });
              } catch {
              }
              return;
            }
            const newPaused = !currentRecording.isPaused;
            await ensureOffscreenDocument({ url: "offscreen.html", reasons: ["DISPLAY_MEDIA", "WORKERS", "BLOBS"] });
            await sendToOffscreen({ target: "offscreen-doc", type: "OFFSCREEN_TOGGLE_PAUSE", payload: { paused: newPaused } });
            currentRecording.isPaused = newPaused;
            try {
              newPaused ? await pauseBadgeTimer() : await resumeBadgeTimer();
            } catch {
            }
            try {
              sendResponse({ ok: true, paused: newPaused });
            } catch (e) {
            }
          } catch (e) {
            try {
              sendResponse({ ok: false, error: String(e) });
            } catch (_) {
            }
          }
        })();
        return true;
      }
    }
  }
  switch (message.action) {
    case "requestScreenCapture":
      handleScreenCaptureRequest(message, sendResponse);
      return true;
    // 保持消息通道开放
    case "startRecording":
      handleStartRecording(message, sendResponse);
      return true;
    case "stopRecording":
      handleStopRecording(message, sendResponse);
      return true;
    case "saveRecording":
      handleSaveRecording(message, sendResponse);
      return true;
    case "getSettings":
      handleGetSettings(sendResponse);
      return true;
    case "updateSettings":
      handleUpdateSettings(message, sendResponse);
      return true;
    case "openSidePanel":
      handleOpenSidePanel(message, sendResponse);
      return true;
    // 来自offscreen document的消息
    case "recordingComplete":
      console.log("Recording completed with", message.chunksCount, "chunks");
      break;
    case "recordingError":
      console.error("Recording error from offscreen:", message.error);
      break;
    default:
      console.warn("Unknown message action:", message.action);
      sendResponse({ error: "Unknown action" });
  }
});
function broadcastToTab(tabId, payload) {
  try {
    const p = chrome.runtime.sendMessage({ ...payload, tabId });
    if (p && typeof p.catch === "function") p.catch(() => {
    });
  } catch (_) {
  }
}
function handleElementRecordingComplete(message, sendResponse) {
  try {
    console.log("🎬 [Background] Element recording completed, transferring to main system...", {
      chunks: message.data?.encodedChunks?.length || 0,
      metadata: message.data?.metadata
    });
    if (!message.data?.encodedChunks || message.data.encodedChunks.length === 0) {
      console.error("❌ [Background] No encoded chunks received");
      sendResponse({ success: false, error: "No encoded chunks" });
      return;
    }
    const transferData = {
      type: "ELEMENT_RECORDING_DATA",
      encodedChunks: message.data.encodedChunks,
      metadata: {
        ...message.data.metadata,
        transferTime: Date.now(),
        source: "element-recording"
      }
    };
    chrome.runtime.sendMessage(transferData).catch((error) => {
      console.warn("❌ [Background] Failed to broadcast to sidepanel:", error);
    });
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        broadcastToTab(tabs[0].id, {
          type: "ELEMENT_RECORDING_READY",
          data: transferData
        });
      }
    });
    console.log("✅ [Background] Element recording data transferred successfully");
    sendResponse({ success: true, message: "Data transferred to main system" });
  } catch (error) {
    console.error("❌ [Background] Error handling element recording complete:", error);
    sendResponse({
      success: false,
      error: error.message || "Unknown error"
    });
  }
}
async function ensureContentInjected(tabId) {
  try {
    const injected = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => window.__mcp_injected === true
    });
    const already = injected?.[0]?.result === true;
    if (already) return;
  } catch (e) {
  }
  try {
    await chrome.scripting.insertCSS({
      target: { tabId },
      files: ["overlay.css"]
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
  } catch (e) {
    console.warn("ensureContentInjected error", e);
  }
}
async function handleScreenCaptureRequest(message, sendResponse) {
  try {
    const sources = message.sources || ["screen", "window", "tab"];
    console.log("Requesting desktop capture with sources:", sources);
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const currentTab = tabs[0];
    if (!currentTab) {
      console.error("No active tab found");
      sendResponse({
        success: false,
        error: "NO_ACTIVE_TAB"
      });
      return;
    }
    console.log("Current tab:", currentTab.id, currentTab.url);
    console.log("Calling chrome.desktopCapture.chooseDesktopMedia...");
    const requestId = chrome.desktopCapture.chooseDesktopMedia(
      sources,
      currentTab,
      // 添加目标标签页参数
      (streamId, options) => {
        console.log("Desktop capture callback called:", { streamId, options });
        if (streamId) {
          console.log("Desktop capture granted:", streamId);
          sendResponse({
            success: true,
            streamId,
            canRequestAudioTrack: options?.canRequestAudioTrack || false
          });
        } else {
          console.log("Desktop capture cancelled by user");
          sendResponse({
            success: false,
            error: "DESKTOP_CAPTURE_CANCELLED"
          });
        }
      }
    );
    console.log("chooseDesktopMedia returned requestId:", requestId);
    if (!requestId) {
      console.error("Failed to initiate desktop capture request");
      sendResponse({
        success: false,
        error: "DESKTOP_CAPTURE_FAILED"
      });
    }
  } catch (error) {
    console.error("Error in handleScreenCaptureRequest:", error);
    sendResponse({
      success: false,
      error: "DESKTOP_CAPTURE_ERROR",
      details: error.message
    });
  }
}
function handleSaveRecording(message, sendResponse) {
  try {
    const { filename, url } = message;
    chrome.downloads.download({
      url,
      filename,
      saveAs: false
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        console.error("Download failed:", chrome.runtime.lastError);
        sendResponse({
          success: false,
          error: "DOWNLOAD_FAILED",
          details: chrome.runtime.lastError.message
        });
      } else {
        console.log("Download started:", downloadId);
        sendResponse({
          success: true,
          downloadId
        });
      }
    });
  } catch (error) {
    console.error("Error in handleSaveRecording:", error);
    sendResponse({
      success: false,
      error: "SAVE_ERROR",
      details: error.message
    });
  }
}
function handleGetSettings(sendResponse) {
  chrome.storage.local.get(["settings"], (result) => {
    if (chrome.runtime.lastError) {
      console.error("Failed to get settings:", chrome.runtime.lastError);
      sendResponse({
        success: false,
        error: "STORAGE_ERROR"
      });
    } else {
      sendResponse({
        success: true,
        settings: result.settings || {}
      });
    }
  });
}
function handleUpdateSettings(message, sendResponse) {
  const { settings } = message;
  chrome.storage.local.set({ settings }, () => {
    if (chrome.runtime.lastError) {
      console.error("Failed to update settings:", chrome.runtime.lastError);
      sendResponse({
        success: false,
        error: "STORAGE_ERROR"
      });
    } else {
      console.log("Settings updated:", settings);
      sendResponse({
        success: true
      });
    }
  });
}
function handleOpenSidePanel(message, sendResponse) {
  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    try {
      if (tabs[0]?.id) {
        await chrome.sidePanel.open({ tabId: tabs[0].id });
        sendResponse({ success: true });
      } else {
        sendResponse({
          success: false,
          error: "NO_ACTIVE_TAB"
        });
      }
    } catch (error) {
      console.error("Failed to open sidepanel:", error);
      sendResponse({
        success: false,
        error: "SIDEPANEL_ERROR",
        details: error.message
      });
    }
  });
}
chrome.downloads.onChanged.addListener((downloadDelta) => {
  if (downloadDelta.state && downloadDelta.state.current === "complete") {
    console.log("Download completed:", downloadDelta.id);
    chrome.runtime.sendMessage({
      action: "downloadComplete",
      downloadId: downloadDelta.id
    }).catch(() => {
    });
  }
});
chrome.runtime.onStartup.addListener(async () => {
  console.log("Extension startup");
  try {
    if (chrome.sidePanel?.setPanelBehavior) {
      chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
    }
  } catch (e) {
    console.warn("setPanelBehavior(false) onStartup failed", e);
  }
});
let currentRecording = {
  isRecording: false,
  isPaused: false,
  streamId: null,
  startTime: null
};
let badgeInterval = null;
let badgeAccumMs = 0;
let badgeLastStart = null;
function formatElapsed(ms) {
  const totalSec = Math.max(0, Math.floor(ms / 1e3));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor(totalSec % 3600 / 60);
  const s = totalSec % 60;
  if (h >= 1) return `${h}h`;
  if (m >= 10) return `${m}m`;
  return `${m}:${s.toString().padStart(2, "0")}`;
}
async function updateBadgeText() {
  try {
    const extra = currentRecording.isRecording && !currentRecording.isPaused && badgeLastStart != null ? Date.now() - badgeLastStart : 0;
    const text = formatElapsed(badgeAccumMs + extra);
    await chrome.action.setBadgeText({ text });
  } catch {
  }
}
async function startBadgeTimer() {
  try {
    await chrome.action.setBadgeBackgroundColor({ color: "#d32f2f" });
  } catch {
  }
  badgeAccumMs = 0;
  badgeLastStart = Date.now();
  if (badgeInterval) clearInterval(badgeInterval);
  badgeInterval = setInterval(updateBadgeText, 1e3);
  await updateBadgeText();
}
async function pauseBadgeTimer() {
  if (badgeLastStart != null) {
    badgeAccumMs += Date.now() - badgeLastStart;
    badgeLastStart = null;
  }
  await updateBadgeText();
}
async function resumeBadgeTimer() {
  if (badgeLastStart == null) badgeLastStart = Date.now();
  await updateBadgeText();
}
async function stopBadgeTimer() {
  if (badgeInterval) {
    try {
      clearInterval(badgeInterval);
    } catch {
    }
    badgeInterval = null;
  }
  badgeAccumMs = 0;
  badgeLastStart = null;
  try {
    await chrome.action.setBadgeText({ text: "" });
  } catch {
  }
}
async function startRecordingViaOffscreen(options) {
  try {
    const mode = options?.mode === "tab" || options?.mode === "window" || options?.mode === "screen" ? options.mode : "screen";
    const normalizedOptions = {
      mode,
      video: options?.video ?? true,
      audio: options?.audio ?? false
    };
    await ensureOffscreenDocument({ url: "offscreen.html", reasons: ["DISPLAY_MEDIA", "WORKERS", "BLOBS"] });
    await sendToOffscreen({ target: "offscreen-doc", type: "OFFSCREEN_START_RECORDING", payload: { options: normalizedOptions } });
    currentRecording = { isRecording: false, isPaused: false, streamId: "offscreen", startTime: null };
    try {
      await chrome.action.setBadgeBackgroundColor({ color: "#fb8c00" });
    } catch {
    }
    try {
      await chrome.action.setBadgeText({ text: "" });
    } catch {
    }
  } catch (e) {
    throw e;
  }
}
async function stopRecordingViaOffscreen() {
  try {
    console.log("[stop-share] background: forwarding OFFSCREEN_STOP_RECORDING to offscreen");
    await ensureOffscreenDocument({ url: "offscreen.html", reasons: ["DISPLAY_MEDIA", "WORKERS", "BLOBS"] });
    sendToOffscreen({ target: "offscreen-doc", type: "OFFSCREEN_STOP_RECORDING" });
  } finally {
    currentRecording = { isRecording: false, isPaused: false, streamId: null, startTime: null };
    try {
      await stopBadgeTimer();
    } catch (e) {
    }
  }
}
async function handleStartRecording(message, sendResponse) {
  try {
    console.log("Starting recording with streamId:", message.streamId);
    currentRecording = {
      isRecording: true,
      isPaused: false,
      streamId: message.streamId,
      startTime: Date.now()
    };
    console.log("Recording state saved:", currentRecording);
    try {
      await ensureOffscreenDocument({ url: "offscreen.html", reasons: ["DISPLAY_MEDIA", "WORKERS", "BLOBS"] });
      sendToOffscreen({ target: "offscreen-doc", type: "OFFSCREEN_START_RECORDING", payload: { streamId: message.streamId } });
    } catch (e) {
      console.warn("Failed to ensure offscreen or send START to offscreen", e);
    }
    sendResponse({
      success: true,
      message: "Recording started",
      streamId: message.streamId
    });
  } catch (error) {
    console.error("Failed to start recording:", error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}
async function handleStopRecording(message, sendResponse) {
  try {
    console.log("Stopping recording");
    currentRecording = {
      isRecording: false,
      isPaused: false,
      streamId: null,
      startTime: null
    };
    console.log("Recording state reset");
    try {
      await ensureOffscreenDocument({ url: "offscreen.html", reasons: ["DISPLAY_MEDIA", "WORKERS", "BLOBS"] });
      sendToOffscreen({ target: "offscreen-doc", type: "OFFSCREEN_STOP_RECORDING" });
    } catch (e) {
      console.warn("Failed to ensure offscreen or send STOP to offscreen", e);
    }
    sendResponse({
      success: true,
      message: "Recording stopped"
    });
  } catch (error) {
    console.error("Failed to stop recording:", error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}
chrome.tabs.onRemoved.addListener((tabId) => {
  tabStates.delete(tabId);
});
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    if (activeInfo?.tabId != null) {
      await broadcastStateWithCapabilities(activeInfo.tabId);
    }
  } catch (e) {
  }
});
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === "loading") {
    const st = tabStates.get(tabId);
    if (st) {
      st.selecting = false;
      st.recording = false;
      broadcastStateWithCapabilities(tabId);
    }
  }
});
self.addEventListener("error", (event) => {
  console.error("Service Worker error:", event.error);
});
self.addEventListener("unhandledrejection", (event) => {
  try {
    const reason = event?.reason;
    const msg = reason && (reason.message || String(reason)) || "";
    if (typeof msg === "string" && msg.includes("Could not establish connection. Receiving end does not exist.")) {
      try {
        if (typeof event.preventDefault === "function") event.preventDefault();
      } catch {
      }
      return;
    }
  } catch {
  }
  console.error("Service Worker unhandled rejection:", event.reason);
});
